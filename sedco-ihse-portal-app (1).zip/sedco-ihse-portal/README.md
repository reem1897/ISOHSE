# SEDCO Integrated HSE Management System Portal

Elsewedy Cable Accessories: an integrated ISO 45001:2018 + Amd 1:2024 and ISO 14001:2026 system for two workspaces.

- **Egypt plant**: Elsewedy Cable Accessories (SEDCO).
- **KSA plant**: Elsewedy Industrial Limited, Riyadh, covering cable accessories and fiber poles.

The portal is organised as **Country → Clause → Subclause → documents and evidence**. Both countries use the same bilingual (Arabic/English) design and templates, but each keeps its own operations, legislation, responsibilities and records.

## Quick start

Requires Node.js 22. The database is **Postgres**: Supabase in production (`DATABASE_URL`), or an embedded Postgres (PGlite, stored in `data/pg`) when `DATABASE_URL` is not set. Stored files live in the database, so the app runs on serverless hosts. LibreOffice (`soffice`) is optional and is only needed for PDF preview and export.

**Hosting on Vercel + Supabase:** see [DEPLOY_VERCEL.md](DEPLOY_VERCEL.md).

```bash
npm ci
```

```bash
npm start
```

The first start creates the database (embedded Postgres in `data/pg`, or the Supabase database), seeds the content, generates about 100 Word/Excel documents and creates an `admin` user. The admin password is written to `data/INITIAL_ADMIN_PASSWORD.txt` (mode 600). Sign in at http://127.0.0.1:8080, change the password under **Change password**, then delete that file.

### Configuration (environment variables)

| Variable | Default | Purpose |
|---|---|---|
| `PORT` / `HOST` | `8080` / `127.0.0.1` | Listen address. Put a reverse proxy (IIS, nginx) with HTTPS in front for intranet use. |
| `DATABASE_URL` | unset | Postgres connection string (Supabase transaction pooler, port 6543). Unset = embedded PGlite. |
| `IHSE_DATA_DIR` | `./data` | Embedded database and PDF cache (local mode only). |
| `IHSE_SECURE_COOKIE` | unset | Set to `1` behind HTTPS so session cookies are marked `Secure`. |
| `IHSE_ADMIN_PASSWORD` | random locally; required on Vercel | Initial admin password for the first seed only. Never commit it. |
| `SOFFICE` | `soffice` | Path to the LibreOffice binary used for PDF conversion. |

No credentials are embedded in the code or the front end, and the portal needs no AI service to run.

### Windows server

Install Node 22 LTS, copy the folder, run `npm ci`, set `DATABASE_URL` (or leave it unset for the embedded database), and register `node --no-warnings src\server.js` as a service (for example with NSSM).

## Roles and access

| Role | Can do |
|---|---|
| Administrator | Everything: users, country access, audit log |
| Document controller | Register and upload documents, edit metadata, regenerate portal documents, mark documents obsolete, set subclause status and text |
| Contributor | Register and upload documents and records, submit for review, manage actions, resolve confirmation items |
| Reviewer / approver | Approve or return documents; cannot approve a version they uploaded themselves |
| Viewer / auditor | Read-only, including the audit log |

Each user is limited to Egypt, KSA or both. Pages, downloads, search, exports and the dashboard all apply that restriction.

The approval workflow is **Draft → In review → Approved → Obsolete**. Uploading a new version of an approved document returns it to Draft, and the approved version stays in the revision history. Every version is stored with a SHA-256 checksum. Logins, downloads, uploads, approvals, edits and exports are written to the append-only audit log.

## What is where

| Path | Content |
|---|---|
| `src/content/standards.js` | Paraphrased requirement catalogue: ISO 45001 (40 applicable subclauses plus clauses 1–3) and ISO 14001:2026 (35 plus clauses 1–3). No standard text is reproduced. |
| `src/content/nodes.js` | 31 integrated subclause pages. Each has the requirement summary (EN/AR), integrated method, roles, steps, audit checks, plus Egypt- and KSA-specific implementation text and gaps with source IDs. |
| `src/content/sources.js` | Source inventory: SharePoint location, size, date, access level, intended use, note. |
| `src/content/legal.js`, `ksa-poles.js`, `aspects-parser.js` | Register data transcribed from company files. Egypt FP-103-04, Egypt FP-103-05 (223 aspects), KSA fiber poles QA-08-F01 and SE-05-F01. |
| `src/gen/` | Bilingual DOCX builder, Excel register builder, blank forms. |
| `src/web/` | Layout and i18n (Arabic RTL / English LTR), dashboard metrics, ZIP and Excel exports. |
| `src/server.js` | Express routes, authentication, roles, workflow, uploads, search. |
| `tests/portal.test.js` | End-to-end tests (`npm test`). |

## Exports

- **Country package** (`/exports/EG.zip`, `/exports/SA.zip`): `Egypt|KSA/00_Index` (document and record index, clause coverage matrix, confirmation register, action register, source inventory, file list), then `NN_Clause/<subclause>/01_Procedures_Policies | 02_Blank_Forms | 03_Live_Registers | 04_Completed_Records | 05_Original_Sources`.
  - File names end in `_DRAFT` or `_REVIEW` until the document is approved.
  - Company originals are included as `.url` shortcuts to SharePoint. Binaries stay in SharePoint and are not copied out.
- **Individual exports**: single Excel exports for the matrix, confirmation register and document index; DOCX/XLSX download per document; PDF conversion per document (needs LibreOffice).

## Database migrations, backup and restore

- **Migrations**: these are ordered SQL blocks in `src/db.js` (`MIGRATIONS`), applied automatically at start-up and tracked in `schema_migrations`. To change the schema, append a new block; never edit one that has already been applied. `supabase/schema.sql` holds the same schema for review.

- **Backup**: dumps every table, including stored files, to one `.json.gz` file. Works locally and against Supabase (set `DATABASE_URL`).

  ```bash
  npm run backup -- <outdir>
  ```

- **Restore**: loads a backup into a new, empty database.

  ```bash
  npm run restore -- <file.json.gz>
  ```

- **Rebuild seeded content**: deletes documents, uploads, actions and confirmation items, while keeping users and the audit log. Take a backup first.

  ```bash
  npm run seed:force
  ```

## Migration path and integrations not configured

- **SharePoint/OneDrive**: originals are referenced by URL and were read through the Microsoft 365 connector during the build. There is no live sync. Next step: register an Entra ID app with `Sites.Read.All` and add a read-only import job; credentials go in environment variables only.
- **Single sign-on**: not configured; the portal uses local accounts. Entra ID (OIDC) can replace `/login` without changing roles.
- **Email notifications**: not configured.
- **Database**: Postgres (Supabase). All SQL goes through `src/db.js`.
- **Design**: the approved company bilingual templates (HSE-OP-103 design, Excel styles 07–10) were not found as design files. The generated documents use a **provisional** Elsewedy dark-red/black/white design, labelled as such on every file.

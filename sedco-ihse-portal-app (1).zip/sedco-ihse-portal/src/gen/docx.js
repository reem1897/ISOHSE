'use strict';
// Bilingual controlled-document builder (provisional design: Elsewedy dark red / black / white).
// The approved company bilingual templates were not supplied as design files; this design is marked PROVISIONAL.
const d = require('docx');
const { Document, Packer, Paragraph, TextRun, Table, TableRow, TableCell, WidthType, ShadingType, Header, Footer, PageNumber,
  AlignmentType, BorderStyle, VerticalAlign, PageOrientation } = d;

const RED = '8B1A1A', BLACK = '111111', GREY = '6B6B6B', YELLOW = 'FFF200', LIGHT = 'F3E9E9';
const FONT = 'Arial';
const COUNTRY = {
  EG: { en: 'Elsewedy Cable Accessories (SEDCO) — Egypt plant', ar: 'السويدي لإكسسوارات الكابلات (سيدكو) — مصنع مصر' },
  SA: { en: 'Elsewedy Electric — KSA plant, Riyadh (legal entity: confirmation required)', ar: 'السويدي إليكتريك — مصنع الرياض بالمملكة العربية السعودية (الكيان القانوني: يلزم التأكيد)' },
};
const STATUS = {
  draft: ['DRAFT — PENDING APPROVAL', 'مسودة — بانتظار الاعتماد'], review: ['IN REVIEW', 'قيد المراجعة'],
  approved: ['APPROVED', 'معتمد'], obsolete: ['OBSOLETE — DO NOT USE', 'ملغى — لا يستخدم'], blank: ['BLANK MASTER FORM', 'نموذج فارغ'],
};

const run = (text, o = {}) => new TextRun({ text: String(text ?? ''), font: FONT, size: o.size || 20, bold: o.bold, color: o.color || BLACK, italics: o.italics, rightToLeft: o.rtl, highlight: o.highlight });
const pEn = (text, o = {}) => new Paragraph({ children: [run(text, o)], spacing: { after: o.after ?? 80 }, alignment: o.align });
const pAr = (text, o = {}) => new Paragraph({ children: [run(text, { ...o, rtl: true })], bidirectional: true, alignment: AlignmentType.RIGHT, spacing: { after: o.after ?? 80 } });
const border = { style: BorderStyle.SINGLE, size: 4, color: '999999' };
const borders = { top: border, bottom: border, left: border, right: border };
function cell(children, o = {}) {
  const kids = (Array.isArray(children) ? children : [children]).map(c => typeof c === 'string' ? pEn(c, { size: o.size || 18, bold: o.bold, color: o.color, after: 0 }) : c);
  return new TableCell({ children: kids, borders, width: o.w ? { size: o.w, type: WidthType.PERCENTAGE } : undefined, columnSpan: o.span,
    shading: o.fill ? { type: ShadingType.CLEAR, color: 'auto', fill: o.fill } : undefined, verticalAlign: VerticalAlign.CENTER,
    margins: { top: 60, bottom: 60, left: 80, right: 80 } });
}
const arCell = (text, o = {}) => cell([pAr(text, { size: o.size || 18, bold: o.bold, color: o.color, after: 0 })], o);
const table = (rows, widths) => new Table({ rows, width: { size: 100, type: WidthType.PERCENTAGE }, columnWidths: widths });

function heading(en, ar) {
  return [
    new Paragraph({ children: [run(en, { bold: true, size: 26, color: RED })], spacing: { before: 240, after: 40 }, border: { bottom: { style: BorderStyle.SINGLE, size: 6, color: RED } } }),
    pAr(ar, { bold: true, size: 24, color: RED, after: 120 }),
  ];
}

// Yellow highlighted confirmation item with readable text label (colour is never the only signal).
function confirmPara(text) {
  return new Paragraph({ children: [run('CONFIRMATION REQUIRED / يلزم التأكيد: ', { bold: true, highlight: 'yellow' }), run(text, { highlight: 'yellow' })], spacing: { after: 80 } });
}

function headerBlock(m) {
  const st = STATUS[m.status] || STATUS.draft;
  return table([
    new TableRow({ children: [
      cell([pEn('ELSEWEDY ELECTRIC', { bold: true, color: 'FFFFFF', size: 22, after: 0 }), pEn(COUNTRY[m.country].en, { color: 'FFFFFF', size: 16, after: 0 })], { fill: RED, w: 35 }),
      cell([pEn(m.titleEn, { bold: true, size: 22, after: 0 }), pAr(m.titleAr || '', { bold: true, size: 22, after: 0 })], { w: 40 }),
      cell([pEn('Code: ' + m.code, { size: 16, after: 0 }), pEn('Rev: ' + (m.rev ?? '00'), { size: 16, after: 0 }), pEn('Issue date: ' + (m.issueDate || '—'), { size: 16, after: 0 })], { w: 25 }),
    ] }),
    new TableRow({ children: [
      cell([pEn('Status / الحالة: ' + st[0], { bold: true, size: 16, after: 0, highlight: m.status === 'approved' ? undefined : 'yellow' }), pAr(st[1], { size: 16, after: 0 })], { span: 2, fill: m.status === 'approved' ? 'E8F2E8' : 'FFFBCC' }),
      cell([pEn('Design: PROVISIONAL', { size: 14, color: GREY, after: 0 }), pEn('Confidentiality: Internal', { size: 14, color: GREY, after: 0 })]),
    ] }),
  ], [3500, 4000, 2500]);
}

function approvalBlock(m) {
  const blank = '—';
  const row = (role, roleAr, name) => new TableRow({ children: [cell(role, { bold: true, w: 22 }), arCell(roleAr, { w: 18 }), cell(name || blank, { w: 30 }), cell('Electronic approval record only — no signature reproduced', { size: 14, color: GREY, w: 30 })] });
  return [
    ...heading('Preparation, review and approval', 'الإعداد والمراجعة والاعتماد'),
    table([
      new TableRow({ children: [cell('Role', { bold: true, fill: LIGHT }), arCell('الدور', { bold: true, fill: LIGHT }), cell('Name / date', { bold: true, fill: LIGHT }), cell('Signature', { bold: true, fill: LIGHT })] }),
      row('Prepared by', 'أعد بواسطة', m.preparedBy),
      row('Reviewed by', 'روجع بواسطة', m.reviewedBy),
      row('Approved by', 'اعتمد بواسطة', m.approvedBy),
    ], [2200, 1800, 3000, 3000]),
    pEn(m.status === 'approved' ? 'Approval is recorded in the IHSE portal audit log.' : 'Not yet approved. This document must not be presented as approved evidence.', { size: 16, color: GREY, italics: true }),
  ];
}

function revisionBlock(m) {
  const revs = m.revisions && m.revisions.length ? m.revisions : [['00', m.issueDate || '—', 'First issue generated in IHSE portal from verified sources', 'IHSE portal']];
  return [
    ...heading('Revision history', 'سجل التعديلات'),
    table([new TableRow({ children: ['Rev', 'Date', 'Description', 'By'].map(h => cell(h, { bold: true, fill: LIGHT })) }),
      ...revs.map(r => new TableRow({ children: r.map(x => cell(String(x))) }))], [1000, 1500, 5500, 2000]),
  ];
}

function sectionBlocks(sections) {
  const out = [];
  for (const s of sections) {
    out.push(...heading(s.en, s.ar));
    (s.paras || []).forEach(t => out.push(pEn(t)));
    (s.parasAr || []).forEach(t => out.push(pAr(t)));
    (s.bullets || []).forEach(t => out.push(new Paragraph({ children: [run(t)], bullet: { level: 0 }, spacing: { after: 40 } })));
    (s.confirm || []).forEach(t => out.push(confirmPara(t)));
    if (s.table) {
      const { head, rows, widths } = s.table;
      out.push(table([
        new TableRow({ tableHeader: true, children: head.map(h => cell(h, { bold: true, fill: LIGHT })) }),
        ...rows.map(r => new TableRow({ children: r.map(c => (c && typeof c === 'object' && c.confirm) ? cell([new Paragraph({ children: [run('CONFIRMATION REQUIRED: ', { bold: true, highlight: 'yellow', size: 16 }), run(c.text, { highlight: 'yellow', size: 16 })] })], { fill: 'FFF59D' }) : cell(String(c ?? ''))) })),
      ], widths));
      out.push(pEn(''));
    }
  }
  return out;
}

async function build(m) {
  const footer = new Footer({ children: [new Paragraph({ alignment: AlignmentType.CENTER, children: [
    run(`${m.code} — ${m.titleEn} — Page `, { size: 14, color: GREY }), new TextRun({ children: [PageNumber.CURRENT], font: FONT, size: 14, color: GREY }),
    run(' of ', { size: 14, color: GREY }), new TextRun({ children: [PageNumber.TOTAL_PAGES], font: FONT, size: 14, color: GREY }),
    run('  |  Uncontrolled when printed — check the IHSE portal for the current revision', { size: 14, color: GREY }),
  ] })] });
  const header = new Header({ children: [new Paragraph({ alignment: AlignmentType.RIGHT, children: [run(`${m.code}  Rev ${m.rev ?? '00'}`, { size: 14, color: GREY })] })] });
  const doc = new Document({
    creator: 'IHSE Portal', title: `${m.code} ${m.titleEn}`, description: 'Generated by the SEDCO Integrated HSE portal',
    styles: { default: { document: { run: { font: FONT, size: 20 } } } },
    sections: [{
      properties: { page: { margin: { top: 900, bottom: 900, left: 900, right: 900 }, size: m.landscape ? { orientation: PageOrientation.LANDSCAPE } : undefined } },
      headers: { default: header }, footers: { default: footer },
      children: [headerBlock(m), pEn(''), ...sectionBlocks(m.sections || []), ...(m.form ? [] : approvalBlock(m)), ...(m.form ? [] : revisionBlock(m))],
    }],
  });
  return Packer.toBuffer(doc);
}

module.exports = { build, COUNTRY, STATUS };

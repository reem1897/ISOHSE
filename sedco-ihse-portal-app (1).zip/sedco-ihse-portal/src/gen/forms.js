'use strict';
// Blank master forms (bilingual) + subclause implementation documents.
const { build } = require('./docx');

const blank = n => Array.from({ length: n }, () => '');
const fieldTable = (pairs) => ({ head: ['Field', 'الحقل', 'Entry / الإدخال'], widths: [3000, 2500, 4500], rows: pairs.map(([en, ar]) => [en, ar, '']) });
const gridTable = (heads, n) => ({ head: heads, rows: Array.from({ length: n }, () => blank(heads.length)) });

const FORMS = {
  'F-MOM': { en: 'Minutes of meeting (HSE committee / management review)', ar: 'محضر اجتماع (لجنة السلامة / مراجعة الإدارة)', nodes: ['5.4', '9.3', '7.4', '4.1'], sections: [
    { en: 'Meeting details', ar: 'بيانات الاجتماع', table: fieldTable([['Meeting type (HSE committee / Management review / Other)', 'نوع الاجتماع'], ['Date and time', 'التاريخ والوقت'], ['Location / online', 'المكان'], ['Chair', 'رئيس الاجتماع'], ['Secretary', 'أمين السر'], ['Previous minutes reference', 'مرجع المحضر السابق']]) },
    { en: 'Attendance (include worker representatives)', ar: 'الحضور (بما في ذلك ممثلو العاملين)', table: gridTable(['Name / الاسم', 'Position / الوظيفة', 'Worker rep? / ممثل عمال', 'Present / حاضر'], 10) },
    { en: 'Agenda — management review must cover every required input', ar: 'جدول الأعمال — يجب أن تغطي مراجعة الإدارة جميع المدخلات المطلوبة', bullets: [
      'Status of actions from previous meetings / حالة الإجراءات السابقة',
      'Changes in internal/external issues, interested-party needs, compliance obligations, significant aspects, risks and opportunities',
      'Objectives achievement; HSE performance: incidents, NCs and corrective actions, monitoring results, compliance evaluation, audit results',
      'Consultation and participation of workers (ISO 45001); communications and complaints from interested parties',
      'Adequacy of resources; opportunities for continual improvement and integration with business processes',
    ] },
    { en: 'Discussion and decisions', ar: 'المناقشات والقرارات', table: gridTable(['#', 'Topic / الموضوع', 'Discussion / المناقشة', 'Decision / القرار'], 8) },
    { en: 'Actions (enter each in the portal action tracker)', ar: 'الإجراءات (تسجل في متتبع الإجراءات)', table: gridTable(['#', 'Action / الإجراء', 'Owner / المسؤول', 'Due / الموعد', 'Portal ref / المرجع'], 8) },
    { en: 'Communication of results to workers', ar: 'إبلاغ النتائج للعاملين', table: fieldTable([['How and when results were communicated', 'كيف ومتى تم الإبلاغ']]) },
  ] },
  'F-INC': { en: 'Incident / near-miss report and investigation', ar: 'تقرير حادث / حادث وشيك والتحقيق', nodes: ['10.2', '6.1.2H'], sections: [
    { en: 'Report (within the shift)', ar: 'البلاغ (خلال الوردية)', table: fieldTable([['Type: injury / ill health / near miss / environmental / property', 'النوع'], ['Date, time, location', 'التاريخ والوقت والمكان'], ['Persons involved (incl. contractors)', 'الأشخاص'], ['Description', 'الوصف'], ['Immediate actions taken / area made safe', 'الإجراءات الفورية'], ['Environmental release? quantity, containment', 'انبعاث بيئي؟'], ['Reported by / date', 'المبلغ']]) },
    { en: 'Investigation team (must include a worker)', ar: 'فريق التحقيق (يشمل أحد العاملين)', table: gridTable(['Name / الاسم', 'Role / الدور', 'Worker? / عامل'], 5) },
    { en: 'Root cause analysis (5-why / fishbone)', ar: 'تحليل السبب الجذري', table: gridTable(['Why / لماذا', 'Answer / الإجابة'], 5) },
    { en: 'Corrective actions and risk-assessment update', ar: 'الإجراءات التصحيحية وتحديث تقييم المخاطر', table: gridTable(['Action / الإجراء', 'Hierarchy level / مستوى الضابط', 'Owner', 'Due', 'HIRA/aspect row updated?'], 5) },
    { en: 'Effectiveness verification and lessons learned', ar: 'التحقق من الفعالية والدروس المستفادة', table: fieldTable([['Verified by / date', 'تم التحقق بواسطة'], ['Effective? evidence', 'فعال؟ الدليل'], ['Lesson shared via (TBT/alert)', 'نشر الدرس']]) },
  ] },
  'F-CAR': { en: 'Nonconformity & corrective action report', ar: 'تقرير عدم المطابقة والإجراء التصحيحي', nodes: ['10.2'], sections: [
    { en: 'Nonconformity', ar: 'عدم المطابقة', table: fieldTable([['Source: audit / inspection / incident / legal evaluation / complaint', 'المصدر'], ['Clause(s) — ISO 45001 / ISO 14001', 'البنود'], ['Description and objective evidence', 'الوصف والدليل'], ['Grade: major / minor / observation', 'الدرجة'], ['Correction and consequence control (incl. environmental impact)', 'التصحيح ومعالجة العواقب']]) },
    { en: 'Cause and extent', ar: 'السبب والامتداد', table: fieldTable([['Root cause', 'السبب الجذري'], ['Do similar NCs exist or could occur elsewhere?', 'هل توجد حالات مشابهة؟']]) },
    { en: 'Corrective action', ar: 'الإجراء التصحيحي', table: gridTable(['Action', 'Owner', 'Due', 'Done on', 'Evidence ref'], 5) },
    { en: 'Effectiveness review', ar: 'مراجعة الفعالية', table: fieldTable([['Reviewed by / date', 'المراجع / التاريخ'], ['Effective? (Yes/No — reopen)', 'فعال؟'], ['Changes needed to the management system?', 'تغييرات مطلوبة في النظام؟']]) },
  ] },
  'F-MOC': { en: 'Management of change request & pre-start review', ar: 'طلب إدارة التغيير ومراجعة ما قبل التشغيل', nodes: ['8.1.3', '6.3'], sections: [
    { en: 'Change request', ar: 'طلب التغيير', table: fieldTable([['Change type: process / equipment / material / layout / organisation / legal / management system', 'نوع التغيير'], ['Temporary or permanent (end date)', 'مؤقت أم دائم'], ['Description and reason', 'الوصف والسبب'], ['Requested by / department / date', 'مقدم الطلب']]) },
    { en: 'HSE screening', ar: 'الفحص البيئي والسلامة', table: gridTable(['Question / السؤال', 'Yes/No', 'Comment / ملاحظة'], 0) },
    { en: 'Screening checklist', ar: 'قائمة الفحص', bullets: ['New hazards or changed OH&S risks? (update HIRA)', 'New or changed environmental aspects, incl. life-cycle? (update aspects register)', 'Legal / permit impact? (update legal register; Civil Defense approval?)', 'Emergency plan, evacuation routes, firefighting affected?', 'Training / competence needed?', 'Documents to update (procedures, SWI, forms)?', 'Workers consulted? (ISO 45001 5.4)'] },
    { en: 'Approval and pre-start review', ar: 'الاعتماد ومراجعة ما قبل التشغيل', table: fieldTable([['HSE reviewer / date', 'مراجع السلامة'], ['Approver (Plant Director) / date', 'المعتمد'], ['Pre-start safety review done on / by', 'مراجعة ما قبل التشغيل'], ['Close-out: registers updated, training done', 'الإغلاق']]) },
  ] },
  'F-DRILL': { en: 'Emergency drill evaluation & lessons learned', ar: 'تقييم تجربة الطوارئ والدروس المستفادة', nodes: ['8.2'], sections: [
    { en: 'Drill details', ar: 'بيانات التجربة', table: fieldTable([['Scenario (fire / chemical spill / medical / evacuation / environmental release)', 'السيناريو'], ['Date, time, area, shift', 'التاريخ والوقت والمكان'], ['Announced / unannounced', 'معلنة / غير معلنة'], ['Participants count incl. contractors/visitors', 'عدد المشاركين'], ['External parties involved (Civil Defense, ambulance)', 'جهات خارجية']]) },
    { en: 'Performance', ar: 'الأداء', table: gridTable(['Criterion / المعيار', 'Target / المستهدف', 'Actual / الفعلي', 'OK?'], 6) },
    { en: 'Findings and actions', ar: 'الملاحظات والإجراءات', table: gridTable(['Finding', 'Action', 'Owner', 'Due', 'Portal ref'], 6) },
    { en: 'Plan review', ar: 'مراجعة الخطة', table: fieldTable([['Does the emergency plan need revision? What?', 'هل تحتاج الخطة لتعديل؟'], ['Evaluator / date', 'المقيم / التاريخ']]) },
  ] },
  'F-CONTR': { en: 'Contractor HSE pre-qualification & evaluation', ar: 'التأهيل المسبق وتقييم المقاولين للسلامة والبيئة', nodes: ['8.1.4'], sections: [
    { en: 'Contractor', ar: 'المقاول', table: fieldTable([['Company name / registration', 'اسم الشركة / السجل'], ['Scope of work and location', 'نطاق العمل'], ['High-risk activities (hot work, height, confined space, lifting, electrical)', 'الأنشطة عالية الخطورة']]) },
    { en: 'Pre-qualification criteria', ar: 'معايير التأهيل', table: gridTable(['Criterion / المعيار', 'Evidence / الدليل', 'Pass?'], 0) },
    { en: 'Criteria list', ar: 'قائمة المعايير', bullets: ['HSE plan / method statement and risk assessment', 'Valid worker insurance', 'Competence and licences of personnel', 'Commitment to permit-to-work and induction', 'Waste and chemical handling arrangements (SDS)', 'Incident history (last 3 years)'] },
    { en: 'Post-job evaluation', ar: 'التقييم بعد العمل', table: fieldTable([['Incidents / violations during job', 'الحوادث / المخالفات'], ['Score / recommendation (approve / conditional / reject)', 'التقييم / التوصية'], ['Evaluated by / date', 'المقيم / التاريخ']]) },
  ] },
  'F-TRAIN': { en: 'Training / induction / TBT attendance & effectiveness', ar: 'حضور التدريب / التعريف / حديث السلامة وتقييم الفعالية', nodes: ['7.2', '7.3', '5.2'], sections: [
    { en: 'Session', ar: 'الجلسة', table: fieldTable([['Topic (incl. policy, significant aspects, hazards, right to withdraw)', 'الموضوع'], ['Type: induction / TBT / formal training / policy communication', 'النوع'], ['Date, duration, trainer', 'التاريخ والمدة والمدرب'], ['Language(s) used', 'اللغة']]) },
    { en: 'Attendance', ar: 'الحضور', table: gridTable(['Name / الاسم', 'ID / الرقم', 'Department / القسم', 'Signature / التوقيع'], 15) },
    { en: 'Effectiveness check (after ~30 days)', ar: 'تقييم الفعالية (بعد ٣٠ يوماً تقريباً)', table: fieldTable([['Method: test / observation / interview', 'الطريقة'], ['Result and follow-up', 'النتيجة والمتابعة'], ['Checked by / date', 'المقيم / التاريخ']]) },
  ] },
  'F-HAZREP': { en: 'Hazard / unsafe condition report (worker)', ar: 'نموذج الإبلاغ عن خطر / حالة غير آمنة', nodes: ['5.4', '6.1.2H'], sections: [
    { en: 'Report — no blame; reporting is protected from reprisal', ar: 'البلاغ — بدون لوم؛ المبلغ محمي من أي إجراء انتقامي', table: fieldTable([['What did you see? / ماذا رأيت', 'الوصف'], ['Where and when', 'أين ومتى'], ['Suggested solution', 'الحل المقترح'], ['Name (optional)', 'الاسم (اختياري)']]) },
    { en: 'HSE follow-up', ar: 'متابعة السلامة', table: fieldTable([['Received by / date', 'استلم بواسطة'], ['Risk rating (L × S)', 'تقييم الخطر'], ['Action, owner, due', 'الإجراء والمسؤول والموعد'], ['Feedback given to reporter on', 'تاريخ الرد على المبلغ']]) },
  ] },
  'F-COMPEVAL': { en: 'Compliance evaluation record', ar: 'سجل تقييم الامتثال', nodes: ['9.1.2', '6.1.3'], sections: [
    { en: 'Evaluation', ar: 'التقييم', table: fieldTable([['Period covered', 'الفترة'], ['Evaluator(s)', 'المقيم'], ['Legal register revision used', 'إصدار السجل القانوني']]) },
    { en: 'Results by obligation', ar: 'النتائج لكل التزام', table: gridTable(['Register no. / رقم', 'Requirement / المتطلب', 'Evidence / الدليل', 'Result / النتيجة', 'Action / إجراء'], 12) },
    { en: 'Overall status reported to management', ar: 'الحالة العامة المرفوعة للإدارة', table: fieldTable([['Summary', 'الملخص'], ['Reported at (MR / date)', 'رفعت في']]) },
  ] },
};

async function buildForm(key, country, code, issueDate) {
  const f = FORMS[key];
  return build({ country, code, titleEn: f.en, titleAr: f.ar, status: 'blank', rev: '00', issueDate, form: true, sections: [
    { en: 'Instructions', ar: 'التعليمات', paras: ['Blank master form. A filled copy becomes a record only when completed, dated and filed against this form in the IHSE portal (Record → "Made from form"). A blank form is never evidence that an activity took place.'],
      parasAr: ['نموذج رئيسي فارغ. تصبح النسخة المعبأة سجلاً فقط عند استكمالها وتأريخها وحفظها في البوابة مرتبطة بهذا النموذج. النموذج الفارغ ليس دليلاً على تنفيذ النشاط.'] },
    ...f.sections,
  ] });
}

const STATUS_TXT = {
  'implemented-evidence': 'Implemented — evidence located in company sources (content verification pending where noted)',
  draft: 'Draft — pending approval', 'confirmation-required': 'Confirmation required', 'evidence-missing': 'Evidence missing', na: 'Not applicable',
};

async function buildImplementation({ node, country, code, impl, status, reqs, docs, records, gaps, issueDate }) {
  const r45 = reqs.filter(r => r.standard === 'ISO45001'), r14 = reqs.filter(r => r.standard === 'ISO14001');
  return build({ country, code, titleEn: `${node.code} ${node.title_en} — implementation`, titleAr: `${node.title_ar} — التطبيق`, status: 'draft', rev: '00', issueDate, sections: [
    { en: '1. Purpose and scope', ar: '١. الغرض والنطاق', paras: [`Describes how ${country === 'EG' ? 'the Egypt plant' : 'the KSA (Riyadh) plant'} meets the integrated requirement "${node.title_en}" of ISO 45001:2018 + Amd 1:2024 and ISO 14001:2026, and where the controlled procedures, blank forms, registers and completed records are kept.`], parasAr: [node.summary_ar] },
    { en: '2. Requirement summary (paraphrased)', ar: '٢. ملخص المتطلب', paras: [node.summary_en], table: { head: ['Standard', 'Clause', 'Title', 'Requirement (paraphrase — not the standard text)'], widths: [1400, 900, 2400, 5300], rows: [...r45, ...r14].map(r => [r.standard === 'ISO45001' ? 'ISO 45001' : 'ISO 14001', r.ref, r.title, r.paraphrase]) } },
    { en: '3. How SEDCO implements it (integrated method)', ar: '٣. طريقة التطبيق المتكاملة', paras: [node.method] },
    { en: `4. Site implementation — ${country === 'EG' ? 'Egypt' : 'KSA'}`, ar: '٤. التطبيق في الموقع', paras: [impl, `Implementation status: ${STATUS_TXT[status] || status}.`] },
    { en: '5. Responsibilities', ar: '٥. المسؤوليات', bullets: JSON.parse(node.roles || '[]') },
    { en: '6. Process steps', ar: '٦. خطوات العملية', bullets: JSON.parse(node.steps || '[]').map((s, i) => `${i + 1}. ${s}`) },
    { en: '7. Related procedures, forms and registers', ar: '٧. الإجراءات والنماذج والسجلات ذات الصلة', table: { head: ['Code', 'Title', 'Type', 'Relevance to this requirement'], widths: [2000, 3500, 1300, 3200], rows: docs.map(d => [d.code, d.title_en, d.doc_type, d.relevance || '']) } },
    { en: '8. Completed records and evidence (original sources)', ar: '٨. السجلات المكتملة والأدلة', paras: records.length ? [] : ['No completed records located for this site.'], table: records.length ? { head: ['Record', 'Date', 'Location'], widths: [3500, 1500, 5000], rows: records.map(r => [r.title_en, r.record_date || '—', r.location || '']) } : undefined },
    { en: '9. Gaps and required confirmations', ar: '٩. الفجوات والتأكيدات المطلوبة', paras: gaps.length ? [] : ['No open confirmation items for this subclause.'], confirm: gaps.map(g => `${g.id}: ${g.missing} — owner: ${g.source_person || '—'}`) },
    { en: '10. Audit checks', ar: '١٠. أسئلة التدقيق', bullets: JSON.parse(node.audit || '[]') },
  ] });
}

module.exports = { FORMS, buildForm, buildImplementation, STATUS_TXT };

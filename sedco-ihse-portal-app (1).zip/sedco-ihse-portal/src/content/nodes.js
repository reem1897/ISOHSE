'use strict';
// Integrated subclause pages (Country -> Clause -> Subclause). One node can map to several standard subclauses.
// Content rules: company facts only from sources (ids in brackets); unknowns become gaps -> Confirmation Register.
// gap tuple: [exact missing info, why needed, proposed draft or '', required source/person, priority H/M/L]

const CLAUSES = [
  { n: 4, en: 'Context of the organization', ar: 'سياق المنظمة', folder: '04_Context' },
  { n: 5, en: 'Leadership and worker participation', ar: 'القيادة ومشاركة العاملين', folder: '05_Leadership' },
  { n: 6, en: 'Planning', ar: 'التخطيط', folder: '06_Planning' },
  { n: 7, en: 'Support', ar: 'الدعم', folder: '07_Support' },
  { n: 8, en: 'Operation', ar: 'التشغيل', folder: '08_Operation' },
  { n: 9, en: 'Performance evaluation', ar: 'تقييم الأداء', folder: '09_Performance_Evaluation' },
  { n: 10, en: 'Improvement', ar: 'التحسين', folder: '10_Improvement' },
];

const N = [];
function node(o) { N.push(o); }

// ============================ CLAUSE 4 ============================
node({
  code: '4.1', clause: 4, folder: '4.1_Organization_Context',
  en: 'Understanding the organization and its context', ar: 'فهم المنظمة وسياقها',
  s45: ['4.1'], s14: ['4.1'],
  summary_en: 'Identify the internal and external issues that shape HSE outcomes. ISO 14001:2026 now names environmental conditions explicitly (pollution, natural resources, climate change, biodiversity, ecosystem health); ISO 45001 Amd 1:2024 requires a decision on whether climate change is relevant.',
  summary_ar: 'تحديد القضايا الداخلية والخارجية المؤثرة على نتائج السلامة والصحة والبيئة، مع إدراج الظروف البيئية صراحةً (التلوث، الموارد الطبيعية، تغير المناخ، التنوع الحيوي) وتحديد مدى صلة تغير المناخ وفق تعديل ISO 45001 لعام 2024.',
  method: 'One SWOT/PESTLE review (form FP-101-01) per plant covers both standards. Each issue is tagged OH&S, Environment or Both, and climate change carries an explicit relevant / not-relevant decision with its reason. Significant issues flow to the risks & opportunities register (6.1.1) and are reviewed at management review (9.3).',
  roles: ['Plant Director / General Manager: approves the context review', 'HSE Senior Manager: facilitates the review and records the climate-change determination', 'Department heads: provide issues from their processes'],
  steps: ['Collect inputs: legal changes, market, relocation/expansion projects, audit results, environmental conditions (heat, water availability, emissions)', 'Hold the context workshop and record minutes (bilingual MOM form)', 'Update FP-101-01 with the date, revision and the climate-change determination', 'Transfer each issue that needs action to the risks & opportunities register', 'Re-review at least annually and before major changes (MOC)'],
  docs: [['F-MOM', 'Minutes of the context review workshop'], ['R-RO', 'Issues needing action are carried into the risks & opportunities register']],
  audit: ['Is the latest context review dated within the last 12 months and approved?', 'Does it record a decision on whether climate change is a relevant issue (ISO 45001 Amd 1)?', 'Are environmental conditions (pollution, resources, climate, biodiversity) considered (ISO 14001:2026 4.1)?', 'Can the HSE manager show how a context issue became a risk, objective or action?'],
  EG: {
    impl: 'The Egypt plant (Elsewedy Cable Accessories) has a 2026 SWOT, FP-101-01 Rev 00 issue 02 dated 01/05/2026 [EG-R-ISSUES26]. It records production expansion and the relocation to a new factory (needing MOC), changing Egyptian OSH and Civil Defense requirements, a shortage of certified forklift and lifting operators, currency pressure on PPE and training budgets, and environmental conditions: heatwaves, water scarcity, resource availability, climate adaptation and biodiversity. Minutes of a SWOT meeting are filed [EG-R-SWOTMOM].',
    status: 'implemented-evidence',
    gaps: [
      ['Explicit statement that climate change was determined relevant or not, with rationale (ISO 45001 Amd 1:2024 4.1)', 'Auditors check that the determination is explicit, not only implied by listed climate issues', 'Draft: "Climate change is determined RELEVANT: heatwaves affect heat stress, cooling load and water availability (FP-101-01, 2026)."', 'HSE Senior Manager', 'M'],
      ['Approval signature/date and meeting date of the SWOT MOM', 'Shows that the review was performed and approved, not only drafted', '', 'HSE Senior Manager / Plant Director', 'M'],
    ],
  },
  SA: {
    impl: 'The latest KSA context record found is FP-101-01 Rev 02 dated 01/09/2024 for Elsewedy Industrial Limited [SA-R-ISSUES24]. It covers the cable accessories business (heat-shrink production on old technology, elbow demand from GIS switchgear, NEOM projects), a single approved supplier for EPDM and silicone oil, no space for expansion, heat stress from climate change, and sandstorms. The 2026 KSA folder for 4.1 is empty [SA-R-RECEMPTY].',
    status: 'evidence-missing',
    gaps: [
      ['2026 context review for the Riyadh plant using the integrated FP-101-01 form, including the climate-change determination and ISO 14001:2026 environmental conditions', 'Current KSA record is from 09/2024 and pre-dates ISO 14001:2026', 'Start from the 2024 SWOT issues; add water scarcity, extreme heat, sandstorms, Saudi regulatory updates', 'KSA Plant Manager + KSA HSE lead', 'H'],
    ],
  },
});

node({
  code: '4.2', clause: 4, folder: '4.2_Interested_Parties',
  en: 'Needs and expectations of workers and other interested parties', ar: 'احتياجات وتوقعات العاملين والأطراف المعنية',
  s45: ['4.2'], s14: ['4.2'],
  summary_en: 'List the interested parties (workers first under ISO 45001), their requirements, and decide which of them become compliance obligations. Note any climate-related expectations.',
  summary_ar: 'تحديد الأطراف المعنية (العاملين أولاً) ومتطلباتهم وتحديد ما يصبح منها التزامات امتثال، بما في ذلك التوقعات المتعلقة بالمناخ.',
  method: 'One stakeholder register (FP-101-05) per plant. Each row has the party, its need or expectation, how it is monitored, whether it is adopted as a compliance obligation (yes/no) and the link to the legal register (6.1.3). Workers and contractor workers are always listed and are fed from consultation (5.4).',
  roles: ['HSE Senior Manager: owns the register', 'HR: workers and representatives', 'Procurement: suppliers and contractors', 'Sales: customer HSE requirements'],
  steps: ['Identify the parties: workers, contractors, regulators, neighbours, customers, corporate (Elsewedy Electric), insurers, certification body', 'Record each party\'s needs, including any climate or resource expectations', 'Decide which become obligations and copy them to the legal & other requirements register', 'Review annually and whenever a new regulator, customer or site change appears'],
  docs: [['R-STAKE', 'Integrated interested-parties register with the obligation decision'], ['R-LEGAL', 'Adopted needs become "other requirements" rows']],
  audit: ['Are workers and contractor workers listed with their needs?', 'Is it clear which needs became compliance obligations?', 'Do adopted obligations appear in the legal & other requirements register?'],
  EG: {
    impl: 'Egypt holds a completed stakeholder register [EG-R-STAKE] and a needs-and-expectations document with PDF [EG-R-NEEDS] in the 2026 records folder. The blank masters FP-101-02 and FP-101-05 exist [EG-F-101-02, EG-F-101-05].',
    status: 'implemented-evidence',
    gaps: [['Content check: does the Egypt register flag which needs become compliance obligations and include climate-related expectations?', 'ISO 14001:2026 4.2 c) and its notes; ISO 45001 Amd 1 note', '', 'HSE Section Head', 'M']],
  },
  SA: {
    impl: 'No completed KSA stakeholder register was found in the 2026 tree; the 4.2 records folder is empty [SA-R-RECEMPTY]. The KSA 2024 SWOT names parties relevant to Riyadh: Saudi customers and authorities, NEOM, local community and suppliers [SA-R-ISSUES24].',
    status: 'evidence-missing',
    gaps: [['Completed KSA interested-parties register (workers, MHRSD, NCEC, MODON, Civil Defense, customers such as SEC, community)', 'Needed before the legal register can be finalised', 'Use portal master R-STAKE; candidate parties listed in the KSA register master as "Confirmation required"', 'KSA HSE lead', 'H']],
  },
});

node({
  code: '4.3', clause: 4, folder: '4.3_Scope',
  en: 'Determining the scope of the integrated HSE system', ar: 'تحديد نطاق النظام المتكامل',
  s45: ['4.3'], s14: ['4.3'],
  summary_en: 'Define and document the physical and organizational boundaries, activities, products and services covered, and the life-cycle stages the plant can control or influence. Make the scope available to interested parties.',
  summary_ar: 'تحديد وتوثيق الحدود المادية والتنظيمية والأنشطة والمنتجات المشمولة ومراحل دورة الحياة التي يمكن التحكم بها أو التأثير عليها، وإتاحته للأطراف المعنية.',
  method: 'Each country workspace keeps one scope statement. It names the legal entity, the site address, the activities, products and services, the life-cycle influence (raw-material purchasing, packaging, transport, end-of-life information), any exclusions with justification, and the date of the multi-site certificate. The scope is published in the manual and on the portal.',
  roles: ['General Manager: approves the scope', 'HSE Senior Manager: drafts it and keeps it aligned with the certificate'],
  steps: ['Confirm the legal entity, site address and certificate scope wording', 'List the activities and departments (from the aspects register inventory)', 'State the life-cycle stages controlled or influenced', 'Approve and publish; update after relocation or new product lines'],
  docs: [['DOC-IMPL', 'Scope statement section in this subclause document']],
  audit: ['Is the scope documented, approved and available to interested parties?', 'Does it match the certificate and the actual site and activities?', 'Does it address life-cycle control and influence (ISO 14001:2026 4.3 e)?'],
  EG: {
    impl: 'Egypt scope evidence is the HSE Manual OP 100 Rev 01 (issue 01/04/2023) filed under 4.3 [EG-R-MANUAL, EG-P-100]. Activities verified from the aspects register inventory [EG-R-ASPECTS]: warehouse, administration, clinic, Elastimould, chemical lab, CNC workshop, buffet, assembly, test lab, metal department, electroplating, injection, extrusion, silicone & raw material, maintenance & utilities, wastewater treatment plant, waste management, printing, packaging & dispatch, quality & HSE, facilities & external areas, contractors & projects.',
    status: 'draft',
    gaps: [
      ['Exact certified scope wording, site address and certificate number/expiry (SGS)', 'Scope must match the certificate and be available to interested parties', '', 'HSE Senior Manager (SGS folder 07-SGS/2026)', 'H'],
      ['Scope update for relocation to the new factory: which site(s) are covered during transition', 'The 2026 SWOT confirms relocation is in progress', '', 'Plant Director', 'H'],
    ],
  },
  SA: {
    impl: 'KSA workspace scope (per instruction 01/11/2026): the Riyadh plant of Elsewedy Industrial Limited covering cable accessories and the fiber poles department. The 2024 SWOT describes it as producing cable accessories since 1997, including heat-shrinkable products and elbows, with EPDM and silicone oil as key materials [SA-R-ISSUES24]. The fiber poles department has its own 2025 risk and environment assessments, SOP, work instruction, SDS and PPE list [SA-R-POLES, SA-R-POLES-RA, SA-R-POLES-ENV]. ISKRA KSA (smart meters) files are excluded. No approved KSA scope statement was found; a certification-body multisite form exists [SA-R-MULTISITE].',
    status: 'confirmation-required',
    gaps: [['Approved KSA scope statement: legal entity name, Riyadh site address, cable-accessory product lines and fiber poles, departments, certificate scope wording, exclusions', 'Every other KSA register depends on the scope', '', 'KSA Plant Director + Corporate HSE (Mohamed Tawfik)', 'H']],
  },
});

node({
  code: '4.4', clause: 4, folder: '4.4_Management_System_Processes',
  en: 'Integrated HSE management system and its processes', ar: 'نظام الإدارة المتكامل وعملياته',
  s45: ['4.4'], s14: ['4.4'],
  summary_en: 'Establish, implement, maintain and improve the system with defined processes, owners and interactions, using the knowledge from context and interested parties.',
  summary_ar: 'إنشاء النظام وتطبيقه وصيانته وتحسينه بعمليات محددة ومالكين وتفاعلات واضحة.',
  method: 'The process map lists each HSE process, its owner, inputs and outputs, controlling procedure and records. The portal mirrors that structure: every subclause page links to the procedure and records that run it. Shared procedures (HSE-OP-101…121) serve both standards; ISO 14001-only elements (life-cycle, compliance obligations) and ISO 45001-only elements (worker participation, hierarchy of controls) are called out on each page.',
  roles: ['HSE Senior Manager: system owner', 'Process owners per the process list'],
  steps: ['Maintain the process list with owners and controls', 'Maintain the process interaction chart', 'Check each process has a controlled procedure and a record trail in the portal'],
  docs: [['DOC-IMPL', 'Process overview in this subclause document'], ['R-DOCMASTER', 'Master list showing which document controls each process']],
  audit: ['Is there a current process list with owners?', 'Do process interactions match how work actually flows (e.g. procurement → contractor control → PTW)?'],
  EG: {
    impl: 'Egypt has a process list with owners and controls and a process interaction chart (FP-101-03) [EG-R-PROCLIST, EG-R-FLOW]. Procedures HSE-OP-102 to HSE-OP-121 are in the 2026 procedures folder. HSE-OP-107 and HSE-OP-120 each exist in two versions, one marked ISO 14001:2026 [EG-P-107E, EG-P-120E].',
    status: 'implemented-evidence',
    gaps: [['Which version of HSE-OP-107 and HSE-OP-120 is the controlled master', 'Two versions in the same folder create a document-control finding (7.5.3)', 'Proposed: keep the ISO 14001:2026 versions as masters after merging OH&S content, archive the other', 'HSE Section Head', 'M']],
  },
  SA: {
    impl: 'The KSA 2026 procedure folder holds copies of the Egypt procedures; most byte sizes are identical [SA-P-ALL]. No KSA process list or interaction chart was found in the 2026 tree.',
    status: 'confirmation-required',
    gaps: [['KSA process list with owners; decision on which Egypt procedures are adopted unchanged and which need Saudi adaptation', 'Copies of Egypt procedures may reference Egyptian law, departments and site A1', '', 'KSA HSE lead + document controller', 'H']],
  },
});

// ============================ CLAUSE 5 ============================
node({
  code: '5.1', clause: 5, folder: '5.1_Leadership_Commitment',
  en: 'Leadership and commitment', ar: 'القيادة والالتزام',
  s45: ['5.1'], s14: ['5.1'],
  summary_en: 'Top management is accountable for the system. They provide resources, integrate HSE into business processes, lead the culture, protect workers from reprisal and support safety committees.',
  summary_ar: 'تتحمل الإدارة العليا مسؤولية فعالية النظام وتوفر الموارد وتدمج متطلباته في العمليات وتحمي العاملين من الانتقام عند الإبلاغ.',
  method: 'Leadership is shown through records, not statements: an approved HSE budget (CAPEX/OPEX), scheduled leadership safety walks with tracked findings, monthly KPI reporting to the General Manager, attendance at HSE committee and management review, and a written no-reprisal commitment for hazard reporting.',
  roles: ['General Manager / CEO', 'Plant Director', 'HSE Senior Manager (reports performance)'],
  steps: ['Approve the annual HSE budget', 'Run leadership safety walks to a schedule and close the findings', 'Review monthly KPIs', 'Chair or attend the HSE committee and management review'],
  docs: [['R-MEETINGS', 'Leadership attendance at committee and review meetings'], ['R-CAPA', 'Walk findings tracked as actions']],
  audit: ['Can top management describe their HSE accountability and recent decisions?', 'Is there evidence of resources provided (budget lines, approvals)?', 'Are leadership walk findings tracked to closure?'],
  EG: {
    impl: 'Egypt record folders exist for the HSE budget, leadership safety walks (about 30 MB of records), KPI reporting, CAPEX/OPEX 2026 and PPE purchase orders [EG-R-BUDGET, EG-R-WALKS, EG-R-KPI, EG-R-CAPEX]. The PPE purchase order folder is empty.',
    status: 'implemented-evidence',
    gaps: [['Walk schedule and closure rate of leadership-walk findings for 2026', 'Shows leadership is effective, not just present', '', 'HSE Section Head', 'L']],
  },
  SA: {
    impl: 'The KSA 2026 folders for HSE budget and HSE committee exist and were modified on 28/10/2026, but their contents were not confirmed.',
    status: 'evidence-missing',
    gaps: [['KSA leadership evidence: approved 2026 HSE budget, leadership walk records, KPI reports', 'Needed for 5.1 conformity', '', 'KSA Plant Manager', 'M']],
  },
});

node({
  code: '5.2', clause: 5, folder: '5.2_HSE_Policy',
  en: 'Integrated HSE policy', ar: 'سياسة السلامة والصحة المهنية والبيئة',
  s45: ['5.2'], s14: ['5.2'],
  summary_en: 'One policy carrying all the commitments of both standards. OH&S: safe and healthy conditions, eliminating hazards, consultation and participation. Environment: protection including pollution prevention plus context-specific commitments. Both: compliance and continual improvement. It is documented, communicated and available.',
  summary_ar: 'سياسة واحدة تتضمن التزامات المعيارين: ظروف عمل آمنة، إزالة الأخطار، التشاور والمشاركة، حماية البيئة ومنع التلوث، الامتثال والتحسين المستمر.',
  method: 'The bilingual policy (HSE-PL-01) is approved by the General Manager. It is communicated at induction, on notice boards and in toolbox talks, and published for interested parties. It is reviewed at management review or after major change.',
  roles: ['General Manager: approves and signs', 'HSE Senior Manager: drafts and maintains', 'HR / HSE: communicates at induction'],
  steps: ['Check the policy against every commitment both standards require', 'Approve and sign', 'Communicate it and record attendance', 'Publish it to interested parties'],
  docs: [['F-TRAIN', 'Policy communication sessions recorded on the attendance form']],
  audit: ['Does the policy include commitments to consultation and participation (45001) and protection of the environment including pollution prevention (14001)?', 'Is it signed, dated and current?', 'Can workers explain it in their own words?'],
  EG: {
    impl: 'Egypt policy HSE-PL-01 is dated 01-07-2026 (issue 02, revision 00), bilingual, and references ISO 14001:2026 and ISO 45001:2018 [EG-R-POLICY26]. Its 11 commitments include worker involvement, eliminating hazards, compliance with Egyptian law, pollution prevention, and (commitment 11) sustainable resource use, climate-change mitigation and adaptation, and biodiversity protection. Policy communication records exist [EG-R-POLCOMM]. A draft "under approval" and a "final" version are also in the same folder [EG-R-POLICYDRAFT].',
    status: 'implemented-evidence',
    gaps: [['Confirm the signed 2026 policy (PDF) is the controlled copy, and archive the "under approval" draft and older finals', 'Avoids use of obsolete versions (7.5.3)', '', 'HSE Section Head', 'L']],
  },
  SA: {
    impl: 'No KSA-specific signed policy was found in the 2026 tree. The Egypt policy commits to Egyptian legislation, so it cannot be adopted unchanged in KSA.',
    status: 'evidence-missing',
    gaps: [['KSA policy signed by the KSA General Manager, committing to Saudi legal requirements, bilingual', 'The Egypt policy references Egyptian law', 'Proposed: adapt HSE-PL-01 and replace commitment 5 with "comply with applicable Saudi legal requirements and other requirements"', 'KSA General Manager', 'H']],
  },
});

node({
  code: '5.3', clause: 5, folder: '5.3_Roles_Responsibilities',
  en: 'Roles, responsibilities, accountabilities and authorities', ar: 'الأدوار والمسؤوليات والصلاحيات',
  s45: ['5.3'], s14: ['5.3'],
  summary_en: 'Assign and communicate HSE responsibilities and authorities, including who ensures conformity and who reports performance to top management.',
  summary_ar: 'تعيين المسؤوليات والصلاحيات وإبلاغها، بما في ذلك المسؤول عن مطابقة النظام وإعداد تقارير الأداء للإدارة العليا.',
  method: 'A RACI matrix covers each HSE process. Job descriptions include HSE duties, and a delegation of authority gives the factory manager HSE authority. The HSE organisation chart is posted.',
  roles: ['General Manager: assigns', 'HR: job descriptions', 'HSE Senior Manager: RACI'],
  steps: ['Maintain the RACI matrix', 'Include HSE duties in job descriptions', 'Issue the delegation of authority', 'Communicate the organisation chart'],
  docs: [['DOC-IMPL', 'RACI summary in this subclause document']],
  audit: ['Who reports HSE performance to top management, and how often?', 'Do supervisors know their authority to stop unsafe work?'],
  EG: {
    impl: 'Egypt record folders hold a roles/responsibilities/authorities matrix, HSE job descriptions, an HSE organisation chart, and a delegation of authority to the factory manager [EG-R-RACI, EG-R-JD, EG-R-ORG, EG-R-DOA]. Verified role holders from document approval blocks: Eng. Ahmed Fathy Elsewedy (CEO, approver), Mohamed Tawfik (HSE Senior Manager), Hussein Atif (HSE Section Head) [EG-P-100].',
    status: 'implemented-evidence', gaps: [],
  },
  SA: {
    impl: 'A KSA "5.3 HSE team organization chart" folder exists (2026). Role holders for KSA are not confirmed.',
    status: 'confirmation-required',
    gaps: [['KSA HSE organisation chart and named role holders (General Manager, HSE lead, emergency coordinator)', 'Approval workflow and responsibilities need real people', '', 'KSA HR', 'H']],
  },
});

node({
  code: '5.4', clause: 5, folder: '5.4_Consultation_Participation',
  en: 'Consultation and participation of workers', ar: 'التشاور مع العاملين ومشاركتهم',
  s45: ['5.4'], s14: [],
  summary_en: 'This is an ISO 45001-only requirement. Give non-managerial workers real mechanisms, time and training to be consulted (policy, roles, legal requirements, objectives, contractor controls) and to take part (hazard identification, incident investigation, controls), and remove barriers to doing so.',
  summary_ar: 'متطلب خاص بـ ISO 45001: توفير آليات ووقت وتدريب للعاملين غير الإداريين للتشاور والمشاركة في تحديد الأخطار والتحقيق في الحوادث وإزالة العوائق.',
  method: 'Workers take part through: a monthly HSE committee with worker representatives (bilingual minutes, actions tracked); a worker hazard report form (Arabic/English, no-blame); worker evaluation of new equipment before use; staff surveys; and workers on incident investigation teams. The meeting index links every set of minutes to its actions and to the requirements it supports.',
  roles: ['HSE committee chair (Plant Director)', 'Worker representatives', 'HSE Section Head: secretary, keeps minutes and actions'],
  steps: ['Schedule committee meetings and circulate the agenda', 'Record minutes on the bilingual MOM form with attendance', 'Log actions with owners and due dates', 'Report hazard-report and survey results back to workers'],
  docs: [['F-MOM', 'Committee minutes: editable bilingual template'], ['R-MEETINGS', 'Index of actual meetings, actions and owners'], ['F-HAZREP', 'Worker hazard report form']],
  audit: ['Are non-managerial workers on the committee and in investigations?', 'Show three consecutive committee minutes with action follow-up.', 'Ask a worker how they report a hazard and what happened to their last report.'],
  EG: {
    impl: 'Egypt evidence: HSE committee records [EG-R-COMM53, EG-R-COMM54, EG-R-COMM74] (one scan dated 29/08/2026 by its filename), worker hazard reports [EG-R-HAZREP54], a staff survey [EG-R-SURVEY], workers\' evaluation of new equipment [EG-R-NEWEQ], and procedure HSE-OP-102 [EG-P-102]. The "consultation and participation of workers" folder is empty [EG-R-CONSULT].',
    status: 'implemented-evidence',
    gaps: [['Meeting index: dates, attendees and actions of each HSE committee meeting in 2026 (taken from the scanned minutes)', 'Committee scans are images; actions are not traceable until indexed', '', 'HSE Section Head', 'M']],
  },
  SA: {
    impl: 'KSA 2026 folders "5.3 HSE Committe" and "5.4 HSE Committe" exist; no minutes were confirmed. The KSA 2024 SWOT reports clear communication channels and induction for new hires [SA-R-ISSUES24].',
    status: 'evidence-missing',
    gaps: [['KSA HSE committee minutes for 2026 (or the committee formation record) with worker representatives', 'ISO 45001 5.4 requires a functioning mechanism', '', 'KSA HSE lead', 'H']],
  },
});

// ============================ CLAUSE 6 ============================
node({
  code: '6.1.1', clause: 6, folder: '6.1.1_Risks_Opportunities',
  en: 'Risks and opportunities (general and system-level)', ar: 'المخاطر والفرص',
  s45: ['6.1.1', '6.1.2.3'], s14: ['6.1.1', '6.1.4'],
  summary_en: 'Using the context, interested-party requirements and scope, determine the risks and opportunities that must be addressed. Include the effect of external environmental conditions on the plant (ISO 14001:2026 6.1.4) and OH&S opportunities (45001 6.1.2.3).',
  summary_ar: 'تحديد المخاطر والفرص الواجب معالجتها بناءً على السياق والأطراف المعنية والنطاق، بما في ذلك أثر الظروف البيئية الخارجية على المصنع.',
  method: 'One register of business-level risks and opportunities (R-RO) is kept separate from the task-level hazard and aspect registers. Each row traces to its source (a 4.1 issue, a 4.2 need, a significant aspect or a compliance obligation) and is scored on the same 5×5 matrix. Each row has an owner and an action reference (6.1.4/6.1.5).',
  roles: ['HSE Senior Manager', 'Department heads (risk owners)'],
  steps: ['Import the issues from 4.1 and the needs from 4.2', 'Score likelihood × severity', 'Assign an action or accept the risk with a justification', 'Review quarterly and at management review'],
  docs: [['R-RO', 'Integrated risks & opportunities register']],
  audit: ['Does each risk or opportunity trace to a context issue or need?', 'Are external environmental conditions affecting the plant (heat, water shortage) assessed?'],
  EG: { impl: 'Egypt has a process risk register (6.1.1) [EG-R-PROCRISK] and a task-assignment matrix for planned actions [EG-R-TASKMAT].', status: 'implemented-evidence',
    gaps: [['Check that the process risk register includes the 2026 SWOT climate, water and relocation issues', 'Traceability from 4.1 to 6.1.4', '', 'HSE Section Head', 'M']] },
  SA: { impl: 'KSA has a 2024 business risk and opportunity register [SA-R-RO24] and a 2026 copy of the process risk register with the same byte size as Egypt\'s [SA-R-PLANNING].', status: 'confirmation-required',
    gaps: [['Confirm whether the KSA 6.1.1 risk register reflects KSA risks or is an Egypt copy; update it from the KSA 2024 R&O register', 'An Egypt copy would be invalid evidence for KSA', '', 'KSA HSE lead', 'H']] },
});

node({
  code: '6.1.2H', clause: 6, folder: '6.1.2_Hazard_Identification_OHS_Risk',
  en: 'Hazard identification and assessment of OH&S risks', ar: 'تحديد الأخطار وتقييم مخاطر السلامة والصحة المهنية',
  s45: ['6.1.2.1', '6.1.2.2'], s14: [],
  summary_en: 'Identify hazards proactively and on an ongoing basis. Cover routine and non-routine work, human factors, emergencies, changes, past incidents, contractors and visitors. Assess the risks with a defined method.',
  summary_ar: 'تحديد الأخطار بشكل استباقي ومستمر للأنشطة الروتينية وغير الروتينية والعوامل البشرية والطوارئ والتغييرات والحوادث السابقة، وتقييم المخاطر بمنهجية محددة.',
  method: 'Three tools feed one HIRA register (R-HIRA). Job hazard analysis (JHA) covers each task. A worker hazard-report and tracking log covers ongoing identification. COSHH assessments cover chemicals. Risk = likelihood (1–5) × severity (1–5). Bands follow the company matrix: ≤6 low, 7–12 medium (extra controls needed before work starts), >12 high. Controls are recorded by the hierarchy of controls and the risk is re-scored after controls.',
  roles: ['Department heads: identify hazards with workers', 'HSE Section Head: method and review', 'Workers: hazard reports and JHA participation'],
  steps: ['Break each department\'s work into tasks (routine and non-routine)', 'Identify hazards with workers, including human factors and ergonomics', 'Score the initial risk, then set controls by the hierarchy', 'Re-score the residual risk and assign an owner', 'Review after incidents, MOC, new chemicals or annually'],
  docs: [['R-HIRA', 'Integrated HIRA register master with matrix and validation'], ['F-HAZREP', 'Worker hazard report'], ['F-INC', 'Incident learnings feed back into the HIRA']],
  audit: ['Does the HIRA cover non-routine work (maintenance, cleaning, breakdowns) and contractors?', 'Were workers involved (names on the JHA)?', 'Was the HIRA reviewed after the last incident or change?', 'Are high risks controlled above PPE level?'],
  EG: { impl: 'Egypt holds a JHA register, an OH&S risk register and a hazard-report tracking log in 6.1.2 records [EG-R-JHA, EG-R-RISKREG, EG-R-HAZTRACK]. It also holds COSHH 2026 assessments [EG-R-COSHH]; a separate "DRAFT – DO NOT USE" COSHH folder must not be used as evidence. The aspects register "Matrix" sheet gives the 5×5 method with severity bands in EGP cost (<1,000 to >500,000 EGP) [EG-R-ASPECTS].', status: 'implemented-evidence',
    gaps: [['Confirm the OH&S risk register severity scale (injury-based) — the matrix found uses EGP cost bands', 'OH&S severity should be judged on harm to people', 'Proposed severity: 1 first aid, 2 medical treatment, 3 lost time <30 d, 4 permanent disability, 5 fatality', 'HSE Senior Manager', 'M']] },
  SA: { impl: 'The KSA 2026 planning folder holds a risk register, JHA and hazard tracking log. The JHA and tracking log have the same byte sizes as Egypt\'s; the risk register differs (505,184 vs 492,519 bytes) [SA-R-PLANNING]. The fiber poles department risk assessment (QA-08-F01, dated 1/1/2025) was read and imported: forklift drum transport, chemical mixing room, heating unit, rotating parts of the pole machine, saw cutting, cranes lifting the pole mould, painting chemicals, manual pole handling and storage, welfare areas and natural disasters [SA-R-POLES-RA].', status: 'confirmation-required',
    gaps: [['A KSA HIRA covering the actual Riyadh tasks (heat stress, heat-shrink and elbow production, EPDM/silicone handling; extend the fiber poles assessment with residual-risk scoring, which is blank in the source)', 'Files copied from Egypt cannot evidence KSA hazards', '', 'KSA HSE lead with department heads', 'H']] },
});

node({
  code: '6.1.2E', clause: 6, folder: '6.1.2_Environmental_Aspects',
  en: 'Environmental aspects and impacts (life-cycle perspective)', ar: 'الجوانب والآثار البيئية من منظور دورة الحياة',
  s45: [], s14: ['6.1.2'],
  summary_en: 'This is an ISO 14001 requirement. Determine the aspects of activities, products and services that the plant controls or influences, with a life-cycle perspective, under normal, abnormal, change and emergency conditions. Apply significance criteria and communicate the significant aspects.',
  summary_ar: 'متطلب ISO 14001: تحديد الجوانب البيئية للأنشطة والمنتجات من منظور دورة الحياة في الظروف العادية وغير العادية والطوارئ والتغيير، وتحديد الجوانب الهامة وإبلاغها.',
  method: 'Integrated register FP-103-05 (R-ASPECTS) is organised by department. Each aspect is scored probability × severity before and after controls (≤6 low, ≤12 medium, >12 high). Significance = legal requirement + environmental consequence + use of materials + corporate concerns (each 0/1); a total above 1 is significant. The 2026 revision adds rows for life-cycle and value chain, climate mitigation, climate adaptation, biodiversity and natural capital, and circularity.',
  roles: ['HSE Section Head: owns the register', 'Department heads: review their sheets', 'Procurement: life-cycle inputs'],
  steps: ['Review each department sheet annually and on change (6.3/8.1.3)', 'Add abnormal and emergency conditions explicitly', 'Re-evaluate significance', 'Communicate significant aspects (TBT, notice boards) and link them to objectives and operational controls'],
  docs: [['R-ASPECTS', 'Aspects & impacts register (Egypt populated from source FP-103-05)'], ['R-OBJ', 'Significant aspects drive objectives']],
  audit: ['Pick electroplating: are wastewater pH and metals significant, and is the WWTP control in place with monitoring?', 'Are life-cycle stages (raw material, transport, end of life) considered?', 'Are abnormal and emergency conditions included?', 'How are significant aspects communicated to workers?'],
  EG: { impl: 'Egypt register "FP-103-05 & 6.1.2.2 Integrated Environmental Aspects Impacts ISO 14001 2026" was read in full and imported into this portal with its source reference [EG-R-ASPECTS]. It has 28 sheets covering 22 areas. The original areas were issued 03-Jan-2021; Maintenance & Utilities, WWTP, Waste Management, Printing, Packaging & Dispatch, Quality & HSE, Facilities & External Areas and Contractors & Projects were added in 2026. Examples: electroplating wastewater is rated high (16) before controls and low (6) after WWTP neutralisation and analysis; electroplating VOCs are rated medium (12).', status: 'implemented-evidence',
    gaps: [['Approval record (who approved the 2026 revision and when) for FP-103-05', 'Imported rows are labelled "source – approval not confirmed"', '', 'HSE Senior Manager', 'M']] },
  SA: { impl: 'A KSA copy of the Egypt aspects register exists, with an identical byte size (189,442) [SA-R-PLANNING]. It lists Egyptian departments such as electroplating and WWTP that are not confirmed for Riyadh, so it is not used. The fiber poles environmental assessment (SE-05-F01, 1 Jan 2025) was read and imported: raw material dust in transport and unloading, mixing vapours of pole paint materials, oil spills under drums, and production noise. All are rated insignificant [SA-R-POLES-ENV].', status: 'evidence-missing',
    gaps: [['KSA aspects assessment for the cable accessories departments, life-cycle stages and Riyadh conditions (heat, water scarcity, dust); align the fiber poles method (1–12/15–25) with the integrated significance criteria', 'An Egypt copy cannot evidence KSA aspects; two significance methods in one system', '', 'KSA HSE lead', 'H']] },
});

node({
  code: '6.1.3', clause: 6, folder: '6.1.3_Legal_Other_Requirements',
  en: 'Legal requirements and other requirements (compliance obligations)', ar: 'المتطلبات القانونية والمتطلبات الأخرى (التزامات الامتثال)',
  s45: ['6.1.3'], s14: ['6.1.3'],
  summary_en: 'Determine and have access to the legal and other requirements for OH&S hazards and environmental aspects, determine how they apply, and keep them up to date.',
  summary_ar: 'تحديد المتطلبات القانونية والأخرى المتعلقة بالأخطار والجوانب البيئية والوصول إليها وتحديد كيفية تطبيقها وتحديثها.',
  method: 'Each country keeps its own register (R-LEGAL): law or requirement, issuing body, the clauses that apply, how they apply to the plant (department or aspect), the compliance evidence, the evaluation frequency and the last result (filled in 9.1.2). Legislation is never shared between countries.',
  roles: ['HSE Section Head: maintains the register', 'Legal / Admin: licences and permits', 'HSE Senior Manager: approves'],
  steps: ['Monitor new and amended legislation (quarterly)', 'Add or retire entries and record how each applies', 'Link each entry to its aspects, hazards and controls', 'Communicate relevant changes to the departments'],
  docs: [['R-LEGAL', 'Legal & other requirements register with compliance evaluation columns']],
  audit: ['Is the register current? Are superseded laws removed?', 'Does each entry state how it applies, not only its title?', 'Are permits and licences with expiry dates included?'],
  EG: { impl: 'Egypt list FP-103-04 Rev 01 (3/01/2025, author Hussein Atif, approved Mohamed Tawfik) [EG-R-LEGAL] includes Labour Law No. 14/2025, Environment Law No. 4/1994 as amended by Law 9/2009 and Law 105/2015, Waste Management Law No. 202/2020 with executive regulation 722/2022, Social Insurance Law No. 148/2019, the industrial licensing law No. 15/2017, and Minister of Manpower decrees on OSH. The list also keeps Labour Law 137/1981 labelled "new labour law" and several COVID-19 decrees from 2020–2021. The "how it applies" column is absent. A 210 MB legal folder is filed [EG-R-LEGALDIR].', status: 'implemented-evidence',
    gaps: [['Review FP-103-04: retire superseded entries (Law 137/1981, expired COVID decrees), add civil defense/fire code and environmental permits, add "how it applies" per entry', 'An outdated register is a common major finding', '', 'HSE Section Head + legal advisor', 'H']] },
  SA: { impl: 'The KSA compliance obligations register in the 2026 tree is a header-only copy of the Egypt form, with no Saudi entries [SA-R-LEGALREG]. The folder named "KSA" under legal registers 2024 holds SEDCO/A1 (Egypt) registers [SA-R-LEGALMISFILED]. MODON papers exist [SA-S-MODON].', status: 'evidence-missing',
    gaps: [['Saudi legal register: verified list of applicable Saudi laws, regulations, licences and permits with how each applies', 'No Saudi obligations are recorded; Egyptian law must not be carried over', 'The portal lists candidate Saudi instruments marked "Confirmation required — verify with legal counsel"', 'KSA legal / HSE lead', 'H']] },
});

node({
  code: '6.1.4', clause: 6, folder: '6.1.4_Planning_Action',
  en: 'Planning action', ar: 'التخطيط لاتخاذ الإجراءات',
  s45: ['6.1.4'], s14: ['6.1.5'],
  summary_en: 'Plan actions for significant risks, aspects, obligations and emergencies, integrate them into processes, and plan how their effectiveness will be checked.',
  summary_ar: 'التخطيط لإجراءات معالجة المخاطر والجوانب والالتزامات الهامة ودمجها في العمليات وتقييم فعاليتها.',
  method: 'Every high or significant row in the HIRA, aspects, legal or risk & opportunity register must point to an action. An action is either an objective (6.2), an operational control (8.1), a training need (7.2) or a monitoring point (9.1). The task-assignment matrix and the portal action tracker hold the owner, due date and effectiveness check.',
  roles: ['Risk owners', 'HSE Section Head: tracks actions'],
  steps: ['Filter high and significant rows', 'Choose the action route and record the reference', 'Plan the effectiveness check', 'Track to closure'],
  docs: [['R-CAPA', 'Action tracker (shared with corrective actions, source-tagged)']],
  audit: ['Pick a significant aspect and a high risk: show the action, its owner and the evidence that it worked.'],
  EG: { impl: 'Egypt has a task-assignment matrix [EG-R-TASKMAT] and a monitoring plan [EG-R-MONPLAN] in planning records.', status: 'implemented-evidence', gaps: [] },
  SA: { impl: 'The KSA copies of these files have the same byte sizes as Egypt\'s [SA-R-PLANNING].', status: 'confirmation-required',
    gaps: [['KSA action plan derived from the KSA HIRA and aspects', 'Depends on 6.1.2 KSA gaps', '', 'KSA HSE lead', 'M']] },
});

node({
  code: '6.2', clause: 6, folder: '6.2_Objectives_Planning',
  en: 'HSE objectives and planning to achieve them', ar: 'أهداف السلامة والصحة والبيئة والتخطيط لتحقيقها',
  s45: ['6.2.1', '6.2.2'], s14: ['6.2.1', '6.2.2'],
  summary_en: 'Set measurable, monitored and communicated objectives at relevant functions. Take account of significant aspects, obligations, risks and consultation. For each, plan what, resources, who, when and the indicator.',
  summary_ar: 'وضع أهداف قابلة للقياس ومراقبتها وإبلاغها، والتخطيط لكل هدف: ماذا، الموارد، المسؤول، الموعد، ومؤشر القياس.',
  method: 'The objectives register (R-OBJ) records for each objective: the source (aspect, risk, obligation or consultation), the baseline with its date and source, the target, the indicator and its formula, the owner, the resources, the due date, the monthly result and the status. Targets entered as proposals stay labelled "Proposed" until management approves them. Achievements are only shown from measured results.',
  roles: ['General Manager: approves objectives', 'Department heads: own departmental objectives', 'HSE Senior Manager: monitors monthly'],
  steps: ['Propose objectives from the planning inputs', 'Approve them at management review', 'Cascade to departments and communicate', 'Report progress monthly and act on shortfalls'],
  docs: [['R-OBJ', 'Objectives & programme register (proposed vs approved vs achieved kept separate)']],
  audit: ['Are the objectives measurable, with baselines and indicators?', 'Do environmental objectives relate to significant aspects?', 'Is monthly monitoring evident?'],
  EG: { impl: 'Egypt has "6.2 objectives Action Plan 2026" [EG-R-OBJ26] and a monthly report folder [EG-R-MONTHLY]. The targets were not extracted, so no figures are shown in the portal.', status: 'implemented-evidence',
    gaps: [['Import the 2026 objectives (target, baseline, indicator, owner) from the objectives action plan into R-OBJ', 'Allows dashboard tracking without retyping', '', 'HSE Section Head', 'M']] },
  SA: { impl: 'The KSA 2026 "6.2 objectives" and "6.2 Monthly Report" folders are empty [SA-R-PLANNING].', status: 'evidence-missing',
    gaps: [['KSA 2026 HSE objectives with baselines and owners', 'No KSA objectives found', '', 'KSA Plant Manager', 'H']] },
});

node({
  code: '6.3', clause: 6, folder: '6.3_Planning_of_Changes',
  en: 'Planning of changes to the management system', ar: 'التخطيط للتغييرات في نظام الإدارة',
  s45: [], s14: ['6.3'],
  summary_en: 'This clause is new in ISO 14001:2026. Changes to the management system itself (structure, scope, processes, resources, a new site) are planned and managed so that the intended outcomes are still achieved. Operational changes are handled in 8.1.3.',
  summary_ar: 'بند جديد في ISO 14001:2026: التخطيط للتغييرات في النظام نفسه (النطاق، العمليات، الموارد، الموقع الجديد) وإدارتها لضمان تحقيق النتائج المرجوة.',
  method: 'System-level changes use the same MOC request (F-MOC) with change type "Management system". Examples: the transition to ISO 14001:2026, relocation to a new factory, integrating KSA into the portal, merging procedure versions. Each change records its purpose, consequences, the affected documents, resources, responsibilities and timing, and gets a post-change review.',
  roles: ['HSE Senior Manager: change owner', 'General Manager: approves resources'],
  steps: ['Raise the MOC with type "Management system"', 'List the affected documents and registers', 'Approve the plan and resources', 'Implement and review the outcome'],
  docs: [['F-MOC', 'MOC request with a management-system change type']],
  audit: ['How was the transition to ISO 14001:2026 planned?', 'How is the relocation managed in terms of documents, scope and aspects?'],
  EG: { impl: 'Egypt evidence of system change: procedures revised for ISO 14001:2026 (HSE-OP-107, HSE-OP-120 "FINAL") [EG-P-107E, EG-P-120E], aspects register 2026 additions [EG-R-ASPECTS], and the new factory relocation [EG-S-NEWFAC]. No planned-change record for the transition itself was found.', status: 'evidence-missing',
    gaps: [['Transition plan record for ISO 14001:2026 (gap analysis, owners, dates, certification-body transition audit date)', 'ISO 14001:2026 6.3 and certification transition', '', 'HSE Senior Manager', 'M']] },
  SA: { impl: 'No KSA planned-change record was found.', status: 'evidence-missing',
    gaps: [['KSA plan for the ISO 14001:2026 transition and for building the KSA system', 'ISO 14001:2026 6.3', '', 'KSA HSE lead', 'M']] },
});

// ============================ CLAUSE 7 ============================
node({
  code: '7.1', clause: 7, folder: '7.1_Resources',
  en: 'Resources', ar: 'الموارد',
  s45: ['7.1'], s14: ['7.1'],
  summary_en: 'Determine and provide the people, infrastructure, equipment and budget the system needs.',
  summary_ar: 'تحديد وتوفير الموارد اللازمة للنظام من أفراد وبنية تحتية ومعدات وميزانية.',
  method: 'Resources are planned through the annual CAPEX/OPEX HSE budget, the PPE management register and firefighting equipment distribution, and are reviewed at management review (adequacy of resources is a required review input).',
  roles: ['General Manager', 'HSE Senior Manager', 'Finance'],
  steps: ['Prepare the CAPEX/OPEX request', 'Approve it', 'Track PPE issue and stock', 'Report adequacy at management review'],
  docs: [['DOC-IMPL', 'Resource summary']],
  audit: ['Were requested HSE resources approved? Any shortfalls (e.g. certified operators)?'],
  EG: { impl: 'Egypt: CAPEX/OPEX 2026 and PPE management registers, PPE issue records, and a fire-fighting distribution record [EG-R-CAPEX, EG-R-PPEMGT]. The 2026 SWOT flags a shortage of certified forklift and lifting operators [EG-R-ISSUES26].', status: 'implemented-evidence', gaps: [] },
  SA: { impl: 'KSA: a 2026 copy of the PPE management register with the same byte size as Egypt\'s; the CAPEX/OPEX folder is empty [SA-R-C7].', status: 'evidence-missing',
    gaps: [['KSA 2026 HSE budget/CAPEX-OPEX and PPE stock records', '7.1 evidence', '', 'KSA Plant Manager', 'M']] },
});

node({
  code: '7.2', clause: 7, folder: '7.2_Competence',
  en: 'Competence', ar: 'الكفاءة',
  s45: ['7.2'], s14: ['7.2'],
  summary_en: 'Define the competence needed for work affecting HSE performance and compliance (including the ability to identify hazards), ensure it, close gaps and check that training worked.',
  summary_ar: 'تحديد الكفاءات المطلوبة للأعمال المؤثرة على الأداء والامتثال، وضمان توفرها وسد الفجوات وتقييم فعالية التدريب.',
  method: 'The qualification matrix (R-TRAIN) records per job the required training, licences (forklift, crane, PTW issuer, first aider, fire team) and expiry. Training is recorded on the bilingual attendance form with an effectiveness check (test or observation after 30 days).',
  roles: ['HR', 'HSE Section Head: HSE training plan', 'Department heads'],
  steps: ['Define requirements per job', 'Find gaps from the matrix', 'Train or license', 'Check effectiveness and update the matrix'],
  docs: [['R-TRAIN', 'Competence/qualification matrix master'], ['F-TRAIN', 'Training attendance & effectiveness form']],
  audit: ['Pick a forklift driver: show their valid licence and training.', 'How is training effectiveness checked?'],
  EG: { impl: 'Egypt has a qualification matrix, forklift licences, a training records folder and environmental support forms [EG-R-QUALMAT, EG-R-FORKLIC, EG-R-TRAIN, EG-F-ENVSUP]. Procedure: HSE-OP-104 [EG-P-104].', status: 'implemented-evidence', gaps: [] },
  SA: { impl: 'The KSA 2026 folders for qualification matrix, forklift licence and training are empty [SA-R-C7].', status: 'evidence-missing',
    gaps: [['KSA qualification matrix and training records for 2026', '7.2 evidence', '', 'KSA HR + HSE', 'H']] },
});

node({
  code: '7.3', clause: 7, folder: '7.3_Awareness',
  en: 'Awareness', ar: 'الوعي',
  s45: ['7.3'], s14: ['7.3'],
  summary_en: 'Workers know the policy and objectives, the hazards, risks and significant aspects of their work, incident learnings, their contribution, the implications of nonconformity, and (ISO 45001) their right to remove themselves from imminent and serious danger.',
  summary_ar: 'وعي العاملين بالسياسة والأهداف والأخطار والجوانب الهامة المتعلقة بعملهم ونتائج الحوادث وحقهم في الابتعاد عن الخطر الوشيك.',
  method: 'Awareness is delivered through safety induction for every new employee and contractor, toolbox talks, policy communication, and awareness interviews that sample workers\' understanding. The induction content explicitly includes the right to stop work under imminent danger.',
  roles: ['HSE team', 'Supervisors (TBT)'],
  steps: ['Induct before starting work', 'Run TBTs on current hazards and aspects', 'Sample awareness by interview', 'Act on weak results'],
  docs: [['F-TRAIN', 'Induction and TBT attendance']],
  audit: ['Ask a worker: what are the significant aspects of your area, and what would you do in imminent danger?'],
  EG: { impl: 'Egypt holds safety induction, employee awareness interview and policy communication records, plus the awareness interview form [EG-R-INDUCT, EG-R-AWAREINT, EG-R-POLCOMM, EG-F-AWARE].', status: 'implemented-evidence',
    gaps: [['Confirm the induction content covers the right to withdraw from imminent danger and the significant environmental aspects', 'Explicit ISO 45001 7.3 f) and ISO 14001 7.3 b)', '', 'HSE Section Head', 'L']] },
  SA: { impl: 'The KSA 2026 folders for induction, awareness interview and policy communication are empty [SA-R-C7].', status: 'evidence-missing',
    gaps: [['KSA induction and awareness records 2026', '7.3 evidence', '', 'KSA HSE lead', 'H']] },
});

node({
  code: '7.4', clause: 7, folder: '7.4_Communication',
  en: 'Internal and external communication', ar: 'الاتصال الداخلي والخارجي',
  s45: ['7.4.1', '7.4.2', '7.4.3'], s14: ['7.4.1', '7.4.2', '7.4.3'],
  summary_en: 'Define what, when, with whom and how to communicate internally and externally. Take account of language and literacy diversity and of compliance obligations, make sure the information is reliable, and respond to relevant communications.',
  summary_ar: 'تحديد ماذا ومتى ومع من وكيف يتم الاتصال داخلياً وخارجياً، مع مراعاة اللغة والالتزامات القانونية والرد على الاتصالات ذات الصلة.',
  method: 'A communication matrix sets out the topic, audience, channel, language (Arabic, English, or others for foreign contractors), frequency and owner. The internal channels are TBTs, the HSE committee, notice boards and email. The external communication log records communications with regulators, the certification body, neighbours and corporate, together with the responses.',
  roles: ['HSE Senior Manager (external)', 'HSE Section Head (internal)'],
  steps: ['Maintain the communication matrix', 'Log external communications and responses', 'Keep evidence of internal communications'],
  docs: [['R-MEETINGS', 'Meeting and communication index'], ['F-MOM', 'Minutes template']],
  audit: ['Show the last external communication with a regulator and its response.', 'Are communications in languages workers understand?'],
  EG: { impl: 'Egypt holds internal communication records, an external communication record, TBTs, an emergency contact list and HSE committee communications [EG-R-INTCOMM, EG-R-EXTCOMM, EG-R-TBT, EG-R-COMM74]. The 7.4 "External communication" folder is empty, but the external log exists as an Excel file.', status: 'implemented-evidence', gaps: [] },
  SA: { impl: 'KSA holds a 2026 external communication record that differs slightly from Egypt\'s (592,804 vs 595,775 bytes); its origin is to be confirmed. The internal communication, TBT and emergency contact folders are empty [SA-R-C7].', status: 'confirmation-required',
    gaps: [['Confirm that the KSA external communication log contains KSA entries (Saudi authorities), not Egypt entries', 'Evidence validity', '', 'KSA HSE lead', 'M']] },
});

node({
  code: '7.5', clause: 7, folder: '7.5_Documented_Information',
  en: 'Documented information', ar: 'المعلومات الموثقة',
  s45: ['7.5.1', '7.5.2', '7.5.3'], s14: ['7.5.1', '7.5.2', '7.5.3'],
  summary_en: 'Create and update documents with identification, format, review and approval. Control their distribution, access, version, retention and disposal, including documents of external origin.',
  summary_ar: 'إعداد الوثائق وتحديثها مع التعريف والمراجعة والاعتماد، وضبط التوزيع والوصول والإصدارات والحفظ والوثائق الخارجية.',
  method: 'This portal is the integrated document control system. Each document has a code, title (EN/AR), revision, status (Draft, In review, Approved, Obsolete) and owner. Every upload is versioned with a SHA-256 checksum. Only approvers can approve, and every change is recorded in the audit log. Blank forms, live registers and completed records are separate types, and a record links to the form it was made from. The master list (R-DOCMASTER) is exported from the portal.',
  roles: ['Document controller', 'Reviewers/approvers', 'Administrator'],
  steps: ['Register the document with its code and owner', 'Upload the draft', 'Send it for review', 'Approve (approver role)', 'Publish; the previous version is kept as history', 'Retain per the retention period; mark obsolete'],
  docs: [['R-DOCMASTER', 'Master list of documents (live export)']],
  audit: ['Are obsolete versions prevented from use?', 'Show the revision history of a procedure.', 'How are external documents (laws, SDS, standards) controlled?'],
  EG: { impl: 'Egypt keeps a master list of documents folder and a legacy filing-system index [EG-R-MASTERLIST, EG-S-FILING]. Several procedures exist in duplicate versions, and policy drafts and "DRAFT – DO NOT USE" COSHH files sit next to the controlled copies.', status: 'implemented-evidence',
    gaps: [['Clean-up of duplicate and draft files in the SharePoint "ISO 2026" tree, or a clear "Obsolete" marking', 'Uncontrolled copies are a common finding', '', 'Document controller', 'M']] },
  SA: { impl: 'The KSA 2026 master list folder is empty [SA-R-C7].', status: 'evidence-missing',
    gaps: [['KSA master list (can be generated from this portal once KSA documents are registered and approved)', '7.5 evidence', '', 'KSA document controller', 'M']] },
});

// ============================ CLAUSE 8 ============================
node({
  code: '8.1.1', clause: 8, folder: '8.1.1_Operational_Planning_Control',
  en: 'Operational planning and control', ar: 'التخطيط والضبط التشغيلي',
  s45: ['8.1.1'], s14: ['8.1'],
  summary_en: 'Set operating criteria and controls for the processes linked to significant risks and aspects, including maintenance, waste, wastewater, chemicals, loading and transport. Adapt work to workers. Keep enough documentation to have confidence that the controls work.',
  summary_ar: 'وضع معايير وضوابط تشغيلية للعمليات المرتبطة بالمخاطر والجوانب الهامة (الصيانة، المخلفات، الصرف، الكيماويات، التحميل والنقل).',
  method: 'Controls are documented in HSE-OP-105 and in topic procedures: waste (117), loading and offloading (109), journey management (112). Safe work instructions are posted at machines. Controls are checked by daily HSE rounds with action plans, monthly inspections and preventive maintenance. The 2026 clause 8 register links each control to the aspect or risk it addresses.',
  roles: ['Department heads: apply the controls', 'Maintenance: preventive maintenance', 'HSE: daily rounds and monthly inspections'],
  steps: ['Define the operating criteria for each significant aspect or high risk', 'Issue the SWIs', 'Inspect (daily and monthly)', 'Raise actions for deviations'],
  docs: [['DOC-IMPL', 'Control map in this subclause document'], ['R-CAPA', 'Inspection findings tracked']],
  audit: ['At electroplating: is wastewater neutralised and analysed as the aspects register requires?', 'Are daily round findings closed?'],
  EG: { impl: 'Egypt holds daily HSE reports (dated folders 11–29 Sep 2026 seen), daily round action plans (monthly), monthly inspections (June and September 2026 folders seen), preventive maintenance, SWIs (about 1.4 GB) and the clause 8 operational control and emergency registers (2026) [EG-R-DAILY, EG-R-DAILYAP, EG-R-MONINSP, EG-R-PM, EG-I-SWI, EG-R-C8REG]. Procedures: HSE-OP-105, 109, 112, 117 [EG-P-105, EG-P-109, EG-P-112, EG-P-117].', status: 'implemented-evidence', gaps: [] },
  SA: { impl: 'The KSA 2026 folders for daily reports, round action plans, monthly inspection, preventive maintenance and SWI are empty. A copy of the clause 8 register exists [SA-R-C8].', status: 'evidence-missing',
    gaps: [['KSA operational control evidence: inspections, PM and SWIs for the Riyadh processes', '8.1 evidence', '', 'KSA HSE lead + Maintenance', 'H']] },
});

node({
  code: '8.1.2', clause: 8, folder: '8.1.2_Hierarchy_of_Controls',
  en: 'Eliminating hazards and reducing OH&S risks (hierarchy of controls)', ar: 'إزالة الأخطار وتقليل المخاطر (تسلسل الضوابط)',
  s45: ['8.1.2'], s14: [],
  summary_en: 'This is an ISO 45001-specific requirement. Apply the hierarchy of controls: elimination, substitution, engineering, administrative (permits, LOTO, training) and PPE as the last line.',
  summary_ar: 'متطلب ISO 45001: تطبيق تسلسل الضوابط: الإزالة، الاستبدال، الضوابط الهندسية، الإدارية (التصاريح، العزل، التدريب)، ثم معدات الوقاية الشخصية.',
  method: 'The HIRA records the control type for every control. High-risk activities have dedicated procedures: permit to work (HSE-OP-110), LOTO (111), confined space (114), forklift (116) and ergonomics (119). Chemicals are assessed by COSHH, and PPE follows the PPE matrix.',
  roles: ['HSE Section Head', 'Permit issuers', 'Maintenance (LOTO)'],
  steps: ['Check the highest-level feasible control for each high risk', 'Issue permits for non-routine high-risk work', 'Audit LOTO and permits', 'Review the PPE matrix'],
  docs: [['R-HIRA', 'Control type column'], ['DOC-IMPL', 'High-risk procedure list']],
  audit: ['Pick a high risk: why was no higher-level control feasible?', 'Inspect a live PTW and a LOTO application.'],
  EG: { impl: 'Egypt holds a PTW & TBT log (from Oct 2024) and PTW records, a PPE matrix, COSHH 2026, and procedures HSE-OP-110, 111, 114, 116 and 119 [EG-R-PTWTBT, EG-R-PTW, EG-R-PPE, EG-R-COSHH].', status: 'implemented-evidence', gaps: [] },
  SA: { impl: 'KSA: a copy of the PPE matrix (same byte size as Egypt\'s); the PTW & TBT folder is empty [SA-R-C8]. The 2025 KSA set has procedure folders for PTW (110), LOTO (111) and confined space (114) [SA-S-2025SET].', status: 'evidence-missing',
    gaps: [['KSA permit-to-work and LOTO records 2026', '8.1.2 evidence', '', 'KSA HSE lead', 'H']] },
});

node({
  code: '8.1.3', clause: 8, folder: '8.1.3_Management_of_Change',
  en: 'Management of change (operational)', ar: 'إدارة التغيير',
  s45: ['8.1.3'], s14: ['8.1'],
  summary_en: 'Control planned changes to products, processes, equipment, workplace, organisation, legal requirements and knowledge before they are implemented. Review unintended changes. ISO 14001 8.1 also requires control of planned changes and mitigation of unintended ones.',
  summary_ar: 'ضبط التغييرات المخطط لها (منتجات، عمليات، معدات، موقع، تنظيم، قوانين) قبل التنفيذ ومراجعة التغييرات غير المقصودة.',
  method: 'Every change goes through the MOC request (F-MOC) per HSE-OP-113. The request covers hazard and aspect screening, legal impact, training, documents to update and a pre-start review, with approval before implementation. The MOC log tracks status. Major projects such as the new factory have a dedicated MOC file.',
  roles: ['Change owner (requesting department)', 'HSE review', 'Plant Director approval'],
  steps: ['Raise the MOC', 'Run the HSE screening (HIRA/aspects)', 'Approve', 'Carry out the pre-start safety review', 'Close and update the registers'],
  docs: [['F-MOC', 'MOC request & pre-start review form']],
  audit: ['Pick the last new machine: show the MOC, the updated HIRA, training and the pre-start review.'],
  EG: { impl: 'Egypt holds MOC records including a LOG folder modified 14/10/2026 [EG-R-MOC], procedure HSE-OP-113 [EG-P-113], and the new factory documents [EG-S-NEWFAC].', status: 'implemented-evidence',
    gaps: [['Confirm that a MOC record covers the factory relocation (HSE screening, Civil Defense approval, updated emergency plan and circulation plan)', 'Major change; the circulation plan on file is dated 10/2020', '', 'HSE Senior Manager', 'H']] },
  SA: { impl: 'The KSA 2026 MOC folder is empty. The 2025 KSA set includes an HSE-OP-113 MOC procedure folder [SA-S-2025SET].', status: 'evidence-missing',
    gaps: [['KSA MOC log 2026', '8.1.3 evidence', '', 'KSA HSE lead', 'M']] },
});

node({
  code: '8.1.4', clause: 8, folder: '8.1.4_Procurement_Contractors_Outsourcing',
  en: 'Procurement, contractors and outsourcing (life-cycle controls)', ar: 'المشتريات والمقاولون والإسناد الخارجي',
  s45: ['8.1.4.1', '8.1.4.2', '8.1.4.3'], s14: ['8.1'],
  summary_en: 'Control the HSE impact of purchased products and services. Pre-qualify and coordinate contractors, and control outsourced processes. ISO 14001 8.1 adds life-cycle requirements: environmental criteria in procurement, requirements communicated to providers and contractors, and information on transport, use and end of life.',
  summary_ar: 'ضبط أثر المشتريات على السلامة والبيئة، وتأهيل المقاولين وتنسيق أعمالهم وضبط العمليات المسندة خارجياً، مع متطلبات دورة الحياة في ISO 14001.',
  method: 'Procurement (HSE-OP-121) requires HSE approval of SDS before buying any chemical, PPE to recognised standards, and machine guarding and noise criteria. Contractors are pre-qualified under HSE-OP-115 (HSE plan, insurance, trained personnel, PTW compliance) and evaluated after the job. Outsourced processes (waste haulage and treatment, calibration, environmental measurements) are listed with their control method.',
  roles: ['Procurement', 'HSE (SDS approval, contractor pre-qualification)', 'Requesting departments'],
  steps: ['Include HSE criteria in purchase requests', 'Get HSE sign-off on chemicals', 'Pre-qualify contractors', 'Induct contractors and issue permits', 'Evaluate contractor performance'],
  docs: [['F-CONTR', 'Contractor HSE pre-qualification form']],
  audit: ['Show the SDS approval for the last new chemical purchased.', 'Show the pre-qualification and evaluation of a contractor working on site today.', 'Which processes are outsourced, and how are they controlled?'],
  EG: { impl: 'Egypt holds procurement records, contractor criteria records (about 270 MB), HSE-OP-115 and HSE-OP-121, and work instruction WI-105-13 [EG-R-PROC, EG-R-CONTR, EG-P-115, EG-P-121, EG-I-105-13].', status: 'implemented-evidence',
    gaps: [['List of outsourced processes (e.g. hazardous waste contractor, environmental measurement lab, calibration) with the control method', 'ISO 45001 8.1.4.3 and ISO 14001 8.1', '', 'HSE Section Head + Procurement', 'M']] },
  SA: { impl: 'KSA has procurement records and contractor-criteria forms, instructions and a procedure in the 2026 tree [SA-R-C8]. The KSA procedure set is a copy of the Egypt procedures HSE-OP-115 and HSE-OP-121 [SA-P-ALL].', status: 'confirmation-required',
    gaps: [['KSA adoption of HSE-OP-115 / HSE-OP-121 with Saudi requirements (e.g. SASO-certified PPE) and a KSA list of outsourced processes', 'The Egypt copies reflect Egyptian practice', '', 'KSA HSE lead + Procurement', 'H']] },
});

node({
  code: '8.2', clause: 8, folder: '8.2_Emergency_Preparedness_Response',
  en: 'Emergency preparedness and response', ar: 'الاستعداد والاستجابة للطوارئ',
  s45: ['8.2'], s14: ['8.2'],
  summary_en: 'Plan the response to the potential emergencies identified (fire, chemical spill, medical case, natural events, environmental releases), including first aid. Train, test with drills, review after drills and real events, and inform workers, contractors, visitors and authorities.',
  summary_ar: 'التخطيط للاستجابة لحالات الطوارئ المحتملة (حريق، انسكاب كيميائي، حالات طبية، انبعاثات بيئية) والتدريب والتجارب الدورية والمراجعة بعدها.',
  method: 'The emergency response plan (HSE-OP-106) and environmental emergency procedure apply. Emergency teams (evacuation, firefighting, first aid) are named per year. The annual drill plan (FP-106-02) covers each scenario. Each drill is evaluated on F-DRILL, and lessons learned become actions. The circulation and evacuation plans are kept current with the layout.',
  roles: ['Emergency coordinator', 'Team leaders', 'HSE: drill evaluation'],
  steps: ['Identify the scenarios (from HIRA and aspects)', 'Appoint and train the teams', 'Run drills per the plan', 'Evaluate and raise actions', 'Review the plan after drills or real events'],
  docs: [['F-DRILL', 'Drill evaluation & lessons-learned form'], ['R-CAPA', 'Drill actions']],
  audit: ['Show the drill plan versus the drills performed in 2026.', 'Did the last drill produce actions, and were they closed?', 'Is the evacuation plan current for the present layout?'],
  EG: { impl: 'Egypt holds drill plan 2026 (FP-106-02), emergency drill records, 2026 evacuation, firefighting and first-aid team lists, firefighting certificates, fire box instructions, circulation plans (A1, dated 10-2020) and a pandemic contingency plan [EG-R-DRILLPLAN, EG-R-DRILLS, EG-R-ETEAMS, EG-R-FFCERT, EG-I-FIREBOX, EG-R-CIRC, EG-P-106, EG-P-106E, EG-P-118].', status: 'implemented-evidence',
    gaps: [['Updated circulation/evacuation plan for the current or new factory layout (file on record dated 10-2020)', 'Relocation changes the escape routes', '', 'HSE Section Head', 'H']] },
  SA: { impl: 'The KSA 2026 emergency and drill folders are empty [SA-R-C7, SA-R-C8]. The KSA 2025 set has an HSE-OP-106 emergency response plan folder with drill records for 2025 (about 2.1 GB) [SA-S-2025SET].', status: 'evidence-missing',
    gaps: [['KSA 2026 drill plan, emergency teams, and Civil Defense requirements for the Riyadh site', '8.2 evidence and Saudi Civil Defense compliance', '', 'KSA HSE lead', 'H']] },
});

// ============================ CLAUSE 9 ============================
node({
  code: '9.1.1', clause: 9, folder: '9.1.1_Monitoring_Measurement',
  en: 'Monitoring, measurement, analysis and evaluation (incl. calibration)', ar: 'المراقبة والقياس والتحليل والتقييم',
  s45: ['9.1.1'], s14: ['9.1.1'],
  summary_en: 'Decide what to monitor (performance, controls, objectives, legal limits), the methods, criteria, indicators and timing. Use calibrated or verified equipment and evaluate the results.',
  summary_ar: 'تحديد ما يجب مراقبته وطرق القياس والمعايير والمؤشرات والتوقيت، واستخدام أجهزة معايرة، وتقييم النتائج.',
  method: 'The monitoring plan (R-MONITOR) records each parameter: noise, illumination, heat stress, air quality, stack emissions, wastewater (pH, BOD, COD, TSS, metals), energy, water, waste quantities, plus the leading and lagging OH&S KPIs. For each it gives the method, frequency, limit, responsible person and the equipment calibration due date. Monthly reports evaluate trends.',
  roles: ['HSE Section Head', 'External accredited laboratory (environmental measurements)', 'Maintenance (calibration)'],
  steps: ['Maintain the plan', 'Measure or commission measurements', 'Compare with limits and targets', 'Report monthly', 'Act on exceedances'],
  docs: [['R-MONITOR', 'Monitoring & calibration plan master']],
  audit: ['Show the latest wastewater analysis against the legal limits.', 'Is the noise meter calibrated?', 'How are KPI trends evaluated?'],
  EG: { impl: 'Egypt holds an HSE monitoring plan, KPI reporting, monthly reports, calibration certificates (about 5.3 GB) and the clause 9 performance evaluation records 2026 [EG-R-MONPLAN, EG-R-KPI, EG-R-MONTHLY, EG-R-CALIB, EG-R-C9REG]. Procedure HSE-OP-107 [EG-P-107].', status: 'implemented-evidence', gaps: [] },
  SA: { impl: 'KSA has lifting equipment calibration certificates (2026 tree) [SA-R-CALIBLIFT]. The 2025 set has a performance monitoring folder of about 145 MB [SA-S-2025SET].', status: 'evidence-missing',
    gaps: [['KSA monitoring plan and 2026 measurement results (work environment, emissions/wastewater if applicable)', '9.1.1 evidence', '', 'KSA HSE lead', 'H']] },
});

node({
  code: '9.1.2', clause: 9, folder: '9.1.2_Evaluation_of_Compliance',
  en: 'Evaluation of compliance', ar: 'تقييم الامتثال',
  s45: ['9.1.2'], s14: ['9.1.2'],
  summary_en: 'Evaluate compliance with each legal and other requirement at a defined frequency, act on gaps and keep knowledge of compliance status.',
  summary_ar: 'تقييم الامتثال لكل متطلب قانوني وآخر بتكرار محدد ومعالجة الفجوات ومعرفة حالة الامتثال.',
  method: 'The compliance evaluation columns of R-LEGAL record, for each obligation: the date evaluated, the evidence (permit, measurement report, inspection), the result (Compliant, Partially, Not compliant, Not evaluated) and the action reference. The result is recorded on F-COMPEVAL and reported to management review.',
  roles: ['HSE Section Head', 'HSE Senior Manager'],
  steps: ['Set the frequency per obligation', 'Collect evidence', 'Record the result', 'Raise actions', 'Report the status'],
  docs: [['R-LEGAL', 'Evaluation columns'], ['F-COMPEVAL', 'Compliance evaluation record']],
  audit: ['Pick three obligations: show the evaluation result and evidence for each.', 'What is the overall compliance status reported to management?'],
  EG: { impl: 'Egypt has a "6.1.3 Compliance Evaluation" record [EG-R-COMPEVAL] and procedure HSE-OP-107 (ISO 14001:2026 version) [EG-P-107E]. The evaluation results were not extracted, so no compliance status is claimed.', status: 'confirmation-required',
    gaps: [['2026 compliance evaluation results per obligation (date, evidence, result)', 'Dashboard shows "not evaluated" until entered', '', 'HSE Section Head', 'H']] },
  SA: { impl: 'No KSA compliance evaluation exists, because no Saudi obligations are registered [SA-R-LEGALREG].', status: 'evidence-missing',
    gaps: [['KSA compliance evaluation after the Saudi legal register is completed', '9.1.2', '', 'KSA HSE lead', 'H']] },
});

node({
  code: '9.2', clause: 9, folder: '9.2_Internal_Audit',
  en: 'Internal audit', ar: 'التدقيق الداخلي',
  s45: ['9.2.1', '9.2.2'], s14: ['9.2.1', '9.2.2'],
  summary_en: 'Plan and run an audit programme covering both standards, weighted by the importance of each process, changes and previous results. Use objective auditors, report the results (to workers too under ISO 45001) and follow up the findings.',
  summary_ar: 'تخطيط وتنفيذ برنامج تدقيق يغطي المعيارين حسب أهمية العمليات والتغييرات والنتائج السابقة، مع حيادية المدققين ومتابعة النتائج.',
  method: 'The audit programme (R-AUDIT) schedules each process at least annually, and more often for high-importance processes (electroplating, chemical handling, contractors). The checklist is generated from this portal\'s audit checks per subclause. Findings are logged as actions with source "Internal audit" and an effectiveness check.',
  roles: ['Audit programme manager (HSE Senior Manager)', 'Trained internal auditors independent of the area'],
  steps: ['Approve the programme', 'Plan each audit (objectives, criteria, scope)', 'Audit with the checklist', 'Report', 'Log findings as actions', 'Verify closure'],
  docs: [['R-AUDIT', 'Audit programme & checklist (generated from requirements)'], ['R-CAPA', 'Audit findings']],
  audit: ['Is every clause of both standards covered in the 12-month cycle?', 'Are auditors independent of the area they audit?', 'Are results reported to workers (45001 9.2.2)?'],
  EG: { impl: 'Egypt holds an internal audit programme (Audit program.xlsx) and a scanned audit record (File0008.PDF) [EG-R-AUDITPRG, EG-R-AUDITRPT]. The "Internal audit objectives" folder is empty [EG-R-AUDITOBJ]. External audit records from SGS 2026 are in a separate folder [EG-S-SGS].', status: 'implemented-evidence',
    gaps: [['2026 internal audit findings list (to load into the action tracker)', 'Dashboard audit-finding metrics are empty until loaded', '', 'HSE Senior Manager', 'M']] },
  SA: { impl: 'No KSA 2026 internal audit programme or report was found.', status: 'evidence-missing',
    gaps: [['KSA internal audit programme 2026 and reports', '9.2 evidence', '', 'KSA HSE lead', 'H']] },
});

node({
  code: '9.3', clause: 9, folder: '9.3_Management_Review',
  en: 'Management review', ar: 'مراجعة الإدارة',
  s45: ['9.3'], s14: ['9.3.1', '9.3.2', '9.3.3'],
  summary_en: 'Top management reviews the system at planned intervals. Required inputs include previous actions, changes, objectives, performance trends, compliance, audits, incidents, consultation results, risks, resources and communications. Results are documented decisions and actions, communicated to workers under ISO 45001.',
  summary_ar: 'مراجعة الإدارة العليا للنظام على فترات مخططة بمدخلات محددة، ومخرجات موثقة من قرارات وإجراءات تُبلغ للعاملين.',
  method: 'The review uses the bilingual MOM template with a fixed agenda covering every required input of both standards. Its outputs (decisions, resources, actions with owners and dates) are entered in the action tracker with source "Management review". The meeting index records the date, attendees and minutes file for each review.',
  roles: ['General Manager (chair)', 'HSE Senior Manager (secretary)', 'Department heads'],
  steps: ['Prepare the inputs report', 'Hold the review', 'Record minutes', 'Log the actions', 'Communicate the results to workers'],
  docs: [['F-MOM', 'MR agenda and minutes template (all required inputs)'], ['R-MEETINGS', 'Index of actual reviews'], ['R-CAPA', 'MR actions']],
  audit: ['Do the minutes cover every required input of both standards?', 'Were last year\'s MR actions completed?', 'Were results communicated to workers?'],
  EG: { impl: 'Egypt holds the "Managment Review 2026" presentation and "MR Mintues of meeting.pdf" [EG-R-MRPPT, EG-R-MR]. The same PDF (identical size) is also filed under 6.2 objectives [EG-R-OBJMOM].', status: 'implemented-evidence',
    gaps: [['MR 2026 date, attendees and list of decisions and actions (from the minutes PDF)', 'Needed for the meeting index and action follow-up', '', 'HSE Senior Manager', 'M']] },
  SA: { impl: 'No KSA management review record was found.', status: 'evidence-missing',
    gaps: [['KSA management review 2026 minutes', '9.3 evidence', '', 'KSA General Manager', 'H']] },
});

// ============================ CLAUSE 10 ============================
node({
  code: '10.2', clause: 10, folder: '10.2_Incident_NC_Corrective_Action',
  en: 'Incident, nonconformity and corrective action', ar: 'الحوادث وعدم المطابقة والإجراءات التصحيحية',
  s45: ['10.1', '10.2'], s14: ['10.2'],
  summary_en: 'Report and investigate incidents and nonconformities promptly, with workers taking part. Control them and deal with the consequences, including environmental impacts. Find the root causes, check for similar cases elsewhere, act, review effectiveness and update risk assessments.',
  summary_ar: 'الإبلاغ عن الحوادث وحالات عدم المطابقة والتحقيق فيها بمشاركة العاملين، ومعالجة الأسباب الجذرية والتحقق من فعالية الإجراءات وتحديث تقييمات المخاطر.',
  method: 'Incidents are reported on F-INC and investigated per HSE-OP-108 by a team that includes a worker. Nonconformities are raised on F-CAR per HSE-OP-120 (environmental NC form HSE-FP-120-01). All actions sit in the CAR log or portal action tracker with owner, due date, evidence and effectiveness verification (HSE-FP-120-04). The related HIRA and aspects rows are updated.',
  roles: ['Supervisor: immediate report', 'Investigation team (incl. worker)', 'Action owners', 'HSE: verification'],
  steps: ['Report and make safe', 'Investigate (5-why or fishbone)', 'Define corrective actions', 'Implement', 'Verify effectiveness', 'Share lessons learned'],
  docs: [['F-INC', 'Incident / near-miss report'], ['F-CAR', 'Nonconformity & corrective action report'], ['R-CAPA', 'Action tracker / CAR register']],
  audit: ['Pick an incident: was a worker on the investigation team? Root cause? Was the HIRA updated?', 'Are corrective actions verified for effectiveness before closure?'],
  EG: { impl: 'Egypt holds the CAR Log (22 MB, not imported), incident records, procedures HSE-OP-108 and HSE-OP-120, and forms HSE-FP-120-01/02/04 [EG-R-CARLOG, EG-R-INCID, EG-P-108, EG-P-120, EG-F-120-01, EG-F-120-02, EG-F-120-04].', status: 'implemented-evidence',
    gaps: [['Export open items of the CAR Log (ID, finding, owner, due date, status) for import into the portal tracker', 'Dashboard overdue-action metrics cover only items entered in the portal', '', 'HSE Section Head', 'M']] },
  SA: { impl: 'A KSA 2026 "10.2 CAR Log" folder of about 11.7 MB exists; its origin is to be confirmed [SA-R-C10]. The KSA 2026 incident folder is empty.', status: 'confirmation-required',
    gaps: [['Confirm that the KSA CAR log holds KSA findings and supply its open items', 'Evidence validity', '', 'KSA HSE lead', 'M']] },
});

node({
  code: '10.3', clause: 10, folder: '10.3_Continual_Improvement',
  en: 'Continual improvement', ar: 'التحسين المستمر',
  s45: ['10.3'], s14: ['10.1'],
  summary_en: 'Continually improve the suitability, adequacy and effectiveness of the system to enhance HSE performance. Promote a supportive culture and worker participation, and communicate the results.',
  summary_ar: 'التحسين المستمر لملاءمة النظام وكفايته وفعاليته لتعزيز الأداء، وتعزيز ثقافة داعمة ومشاركة العاملين.',
  method: 'Improvement opportunities from audits, MR, suggestions, KPIs and lessons learned go into the continual improvement register (HSE-FP-120-03). They are prioritised, resourced and tracked, and the results are shared at the HSE committee.',
  roles: ['HSE Senior Manager', 'All departments'],
  steps: ['Collect opportunities', 'Prioritise', 'Implement', 'Measure the benefit', 'Communicate'],
  docs: [['R-CAPA', 'Improvement actions (source "Improvement")']],
  audit: ['Show improvement trends over three years (incidents, waste, energy).', 'How are workers involved in improvement?'],
  EG: { impl: 'Egypt holds the continual improvement register form (HSE-FP-120-03) and Improvement Records ISO14001-2026 [EG-F-120-03, EG-R-IMPREC]. Procedure HSE-OP-120 revised for 2026 [EG-P-120E].', status: 'implemented-evidence', gaps: [] },
  SA: { impl: 'KSA has a copy of the Improvement Records file (same byte size as Egypt\'s) [SA-R-C10].', status: 'evidence-missing',
    gaps: [['KSA improvement records', '10.3 evidence', '', 'KSA HSE lead', 'L']] },
});

function nodes() { return N; }
module.exports = { CLAUSES, nodes };

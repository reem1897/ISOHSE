'use strict';
// Parses the text extraction of Egypt register FP-103-05 (saved under sources/raw) into structured rows.
// Each department sheet holds an English block followed by an Arabic duplicate block in the same row order.
const fs = require('fs');

const SKIP_SHEETS = new Set(['Inventory', 'Matrix', 'Aspect and impact &metigation', 'EMS 2026 Method', 'SIPOC LCP ETO', 'Env Aspects 2026']);
const isArabic = s => /[؀-ۿ]/.test(s || '');
const num = v => { const n = Number(String(v).trim()); return Number.isFinite(n) ? n : null; };
const band = r => r == null ? '' : r <= 6 ? 'Low' : r <= 12 ? 'Medium' : 'High';

function parseAspects(files) {
  const text = [].concat(files).map(f => fs.readFileSync(f, 'utf8')).join('\n');
  const sheets = text.split(/\n## Sheet: /).slice(1);
  const rows = [];
  for (const block of sheets) {
    const name = block.split(' — ')[0].trim();
    if (SKIP_SHEETS.has(name)) continue;
    const body = block.split('\nFormulas:')[0];
    const lines = body.split('\n').slice(1);
    const en = [], ar = [];
    let target = null;
    for (const line of lines) {
      const c = line.split('\t');
      if (c.length < 12) continue;
      if (c[0] === 'Place' || c[2] === 'Probability' || c[3] === 'Probability') continue;
      if (c[1] === '' && c[2] === '' && (c[0] && c[0] !== '')) { target = isArabic(c[0]) ? ar : en; continue; } // title row
      if (/Inventory!A1/.test(line)) { target = isArabic(c[0]) ? ar : en; continue; }
      if (!c[1] || !c[1].trim()) continue;
      if (!target) target = en;
      (isArabic(c[1]) ? ar : en).push(c);
    }
    en.forEach((c, i) => {
      const p1 = num(c[3]), s1 = num(c[4]), p2 = num(c[8]), s2 = num(c[9]);
      const r1 = p1 != null && s1 != null ? p1 * s1 : null, r2 = p2 != null && s2 != null ? p2 * s2 : null;
      const crit = [num(c[12]), num(c[13]), num(c[14]), num(c[15])].map(v => v || 0);
      const total = crit.reduce((a, b) => a + b, 0);
      const a = ar[i];
      rows.push({
        department: name,
        aspect_en: c[1].replace(/^\*\s*/, '').trim(), impact_en: (c[2] || '').trim(),
        aspect_ar: a ? a[1].replace(/^\*\s*/, '').trim() : '', impact_ar: a ? (a[2] || '').trim() : '',
        p1, s1, r1, band1: band(r1), controls_en: (c[7] || '').trim(), controls_ar: a ? (a[7] || '').trim() : '',
        p2, s2, r2, band2: band(r2),
        legal: crit[0], consequence: crit[1], materials: crit[2], corporate: crit[3], total,
        significant: total > 1 ? 'Significant' : 'Not significant',
        lifecycle: /lifecycle|life-cycle|life cycle|value chain|climate|biodiversity|circular/i.test(c[1]) ? 'Yes' : '',
      });
    });
  }
  return rows;
}

module.exports = { parseAspects };

if (require.main === module) {
  const rows = parseAspects(process.argv.slice(2));
  const byDept = {};
  rows.forEach(r => byDept[r.department] = (byDept[r.department] || 0) + 1);
  console.log(rows.length, byDept);
  console.log(rows.find(r => r.department === 'Electroplating' && /Wastewater/.test(r.aspect_en)));
}

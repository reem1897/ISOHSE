'use strict';
const { t } = require('./i18n');

const esc = (s) => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const pill = (cls, text) => `<span class="pill s-${esc(cls)}">${esc(text)}</span>`;
const prio = (p) => `<span class="pill p-${esc(p)}">${esc({ H: 'High', M: 'Medium', L: 'Low' }[p] || p)}</span>`;
const cname = (c, lang) => t(lang)(c);

function qs(obj) { return Object.entries(obj).filter(([, v]) => v !== undefined && v !== '' && v !== null).map(([k, v]) => `${encodeURIComponent(k)}=${encodeURIComponent(v)}`).join('&'); }

function page(req, { title, body, crumbs = [], active = '' }) {
  const lang = req.lang, tr = t(lang), u = req.user;
  const ws = req.ws || 'ALL';
  const here = req.originalUrl;
  const wsLink = (c) => {
    const m = here.match(/^\/c\/(EG|SA)(.*)$/);
    if (m) return c === 'ALL' ? '/dashboard?c=ALL' : `/c/${c}${m[2]}`;
    const url = new URL(here, 'http://x'); url.searchParams.set('c', c); return url.pathname + url.search;
  };
  const countries = u ? u.countries : [];
  const segs = ['ALL', 'EG', 'SA'].filter(c => c === 'ALL' || countries.includes(c))
    .map(c => `<a class="${ws === c ? 'on' : ''}" href="${esc(wsLink(c))}">${esc(c === 'ALL' ? tr('both') : tr(c))}</a>`).join('');
  const navCountry = ws === 'ALL' ? (countries[0] || 'EG') : ws;
  const { CLAUSES: CL, nodes: allNodes } = require('../content/nodes');
  const clauses = CL.map(c => ({ clause: c.n }));
  const nodesBy = {}; allNodes().forEach(n => (nodesBy[n.clause] = nodesBy[n.clause] || []).push({ code: n.code, clause: n.clause, title_en: n.en, title_ar: n.ar }));
  const clauseNav = clauses.map(({ clause }) => {
    const c = CL.find(x => x.n === clause);
    return `<details ${active === 'clause' + clause ? 'open' : ''}><summary><a style="display:inline;padding:0" href="/c/${navCountry}/clause/${clause}">${clause}. ${esc(lang === 'ar' ? c.ar : c.en)}</a></summary>${(nodesBy[clause] || []).map(n => `<a class="${active === 'node' + n.code ? 'on' : ''}" href="/c/${navCountry}/sub/${encodeURIComponent(n.code)}">${esc(n.code.replace(/[HE]$/, ''))} ${esc(lang === 'ar' ? n.title_ar : n.title_en)}</a>`).join('')}</details>`;
  }).join('');
  const link = (href, key, act) => `<a class="${active === act ? 'on' : ''}" href="${href}">${esc(tr(key))}</a>`;
  const wsq = ws === 'ALL' ? '' : `?c=${ws}`;
  const crumbHtml = `<div class="crumbs"><a class="backbtn" href="${esc(crumbs.length > 1 ? crumbs[crumbs.length - 2][1] : '/dashboard')}" onclick="if(history.length>1&&document.referrer.indexOf(location.host)>-1){history.back();return false;}">${lang === 'ar' ? '→' : '←'} ${esc(tr('back'))}</a>
    ${[[tr('dashboard'), '/dashboard' + wsq], ...crumbs].map(([l, h], i, a) => i === a.length - 1 ? `<span aria-current="page">${esc(l)}</span>` : `<a href="${esc(h)}">${esc(l)}</a> ›`).join(' ')}</div>`;
  return `<!doctype html><html lang="${lang}" dir="${lang === 'ar' ? 'rtl' : 'ltr'}"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>${esc(title)} — ${esc(tr('app'))}</title><link rel="stylesheet" href="/static/style.css"></head><body>
<header class="top"><a class="brand" href="/dashboard${wsq}"><span class="logo">E</span><span><b>${esc(tr('app'))}</b><small>${esc(tr('company'))} · ISO 45001:2018+A1:2024 · ISO 14001:2026</small></span></a>
${u ? `<span class="seg" aria-label="${esc(tr('workspace'))}">${segs}</span>
<form class="searchbox" action="/search" method="get"><input type="search" name="q" placeholder="${esc(tr('search'))}…" aria-label="${esc(tr('search'))}" value="${esc(req.query.q || '')}">${ws !== 'ALL' ? `<input type="hidden" name="c" value="${ws}">` : ''}</form>` : ''}
<a href="/lang/${lang === 'ar' ? 'en' : 'ar'}?next=${encodeURIComponent(here)}">${esc(tr('language'))}</a>
${u ? `<span class="muted" style="color:#ccc">${esc(u.name)} (${esc(u.role)})</span><form method="post" action="/logout"><button class="link" type="submit">${esc(tr('logout'))}</button></form>` : ''}
</header>
${u ? `<div class="layout"><nav class="side" aria-label="Main">
<div class="grp">${esc(tr('workspace'))}: ${esc(ws === 'ALL' ? tr('both') : tr(ws))}</div>
${link('/dashboard' + wsq, 'dashboard', 'dashboard')}
<div class="grp">${esc(tr('clauses'))} — ${esc(tr(navCountry))}</div>${clauseNav}
<div class="grp">${esc(tr('documents'))}</div>
${link('/documents' + wsq, 'documents', 'documents')}${link('/documents?' + qs({ c: ws === 'ALL' ? '' : ws, type: 'record' }), 'records', 'records')}
${link('/actions' + wsq, 'actions', 'actions')}${link('/confirmations' + wsq, 'confirmations', 'confirmations')}
${link('/matrix' + wsq, 'matrix', 'matrix')}${link('/sources' + wsq, 'sources', 'sources')}${link('/exports', 'exports', 'exports')}
${['admin', 'viewer', 'doc_controller'].includes(u.role) ? `<div class="grp">${esc(tr('admin'))}</div>${u.role === 'admin' ? link('/admin/users', 'users', 'users') : ''}${link('/admin/audit', 'audit', 'auditlog')}` : ''}
<div class="grp">${esc(tr('account'))}</div><a href="/account">${esc(tr('change_pw'))}</a>
</nav><main>${crumbHtml}${req.flash ? `<div class="flash ${req.flash.err ? 'err' : ''}">${esc(req.flash.msg)}</div>` : ''}${body}</main></div>` : `<main>${body}</main>`}
</body></html>`;
}

module.exports = { page, esc, pill, prio, qs, cname };

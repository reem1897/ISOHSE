'use strict';
const express = require('express');
const multer = require('multer');
const bcrypt = require('bcryptjs');
const crypto = require('crypto');
const path = require('path');
const fs = require('fs');
const { execFile } = require('child_process');
const { q, log, TMP_DIR } = require('./db');
const { saveVersion, latest, readBlob, ALLOWED } = require('./store');
const { page, esc, pill, prio, qs } = require('./web/layout');
const { t } = require('./web/i18n');
const { countryMetrics, readiness } = require('./web/metrics');
const EXP = require('./web/export');
const { ensureReady, regenerateRegister, regenerateImplementation } = require('./seed');
const { CLAUSES } = require('./content/nodes');
const { EDITIONS } = require('./content/standards');

const app = express();
// Express 4 does not catch rejected promises: wrap every handler so async errors reach the error middleware.
for (const m of ['get', 'post', 'use']) {
  const orig = app[m].bind(app);
  app[m] = (...args) => orig(...args.map(a => typeof a === 'function' && a.length < 4 ? ((req, res, next) => { try { const r = a(req, res, next); if (r && r.catch) r.catch(next); } catch (e) { next(e); } }) : a));
}
app.disable('x-powered-by');
app.set('trust proxy', 1);   // Vercel / reverse proxy terminates HTTPS
const ON_VERCEL = !!process.env.VERCEL;
const PDF_ENABLED = !ON_VERCEL || !!process.env.SOFFICE;
const MAX_UPLOAD_MB = ON_VERCEL ? 4 : 50;   // Vercel limits request bodies to 4.5 MB
const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: MAX_UPLOAD_MB * 1024 * 1024 } });
const CACHE = TMP_DIR;

// ---------------------------------------------------------------- security & session
const ROLES = { admin: 'Administrator', doc_controller: 'Document controller', contributor: 'Contributor', approver: 'Reviewer / approver', viewer: 'Viewer / auditor' };
const PERM = {
  edit: ['admin', 'doc_controller', 'contributor'], approve: ['admin', 'approver'], control: ['admin', 'doc_controller'],
  actions: ['admin', 'doc_controller', 'contributor', 'approver'], confirm: ['admin', 'doc_controller', 'approver', 'contributor'], users: ['admin'], auditlog: ['admin', 'doc_controller', 'viewer'],
};
const can = (u, p) => !!u && PERM[p].includes(u.role);
const COOKIE = 'ihse_sid';

function cookies(req) { return Object.fromEntries((req.headers.cookie || '').split(';').map(c => c.trim().split('=').map(decodeURIComponent)).filter(p => p[0])); }
app.use(async (req, res, next) => {
  await ensureReady();   // migrate + first-time seed (cold start)
  res.set({ 'X-Content-Type-Options': 'nosniff', 'Referrer-Policy': 'same-origin', 'X-Frame-Options': 'SAMEORIGIN',
    'Content-Security-Policy': "default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'; frame-src 'self'; img-src 'self' data:; frame-ancestors 'self'" });
  const ck = cookies(req);
  req.lang = ck.ihse_lang === 'ar' ? 'ar' : 'en';
  if (ck[COOKIE]) {
    const s = (await q.get("SELECT u.* FROM sessions s JOIN users u ON u.id=s.user_id WHERE s.token=? AND s.expires > datetime('now') AND u.active=1", crypto.createHash('sha256').update(ck[COOKIE]).digest('hex')));
    if (s) { req.user = { ...s, countries: s.countries.split(',').filter(Boolean) }; delete req.user.pw_hash; }
  }
  if (ck.ihse_flash) { try { req.flash = JSON.parse(ck.ihse_flash); } catch { /* ignore */ } res.append('Set-Cookie', 'ihse_flash=; Path=/; Max-Age=0'); }
  // CSRF: state-changing requests must come from this origin (cookie is SameSite=Strict as well).
  if (req.method === 'POST') {
    const origin = req.headers.origin || req.headers.referer || '';
    if (origin && !origin.startsWith(`${req.protocol}://${req.headers.host}`)) return res.status(403).send('Cross-site request refused');
  }
  next();
});
app.use(express.urlencoded({ extended: false, limit: '1mb' }));
app.use('/static', express.static(path.join(__dirname, '..', 'public'), { maxAge: '1h' }));

const flash = (res, msg, err) => res.append('Set-Cookie', `ihse_flash=${encodeURIComponent(JSON.stringify({ msg, err: !!err }))}; Path=/; HttpOnly; SameSite=Strict`);
const back = (req, fallback) => (req.headers.referer && new URL(req.headers.referer).host === req.headers.host) ? new URL(req.headers.referer).pathname + new URL(req.headers.referer).search : fallback;

function requireAuth(req, res, next) {
  if (!req.user) return res.redirect('/login?next=' + encodeURIComponent(req.originalUrl));
  const c = (req.query.c || '').toUpperCase();
  req.ws = ['EG', 'SA'].includes(c) && req.user.countries.includes(c) ? c : (req.user.countries.length === 1 ? req.user.countries[0] : 'ALL');
  next();
}
const need = (p) => (req, res, next) => can(req.user, p) ? next() : res.status(403).send(page(req, { title: 'Not permitted', body: `<h1>Not permitted</h1><p>Your role (${esc(ROLES[req.user.role])}) cannot perform this action.</p>` }));
const allowedCountry = (req, c) => c === 'GL' || req.user.countries.includes(c);
const wsCountries = (req) => req.ws === 'ALL' ? req.user.countries : [req.ws];
const inList = (arr) => arr.map(() => '?').join(',');
const label = (req, k) => t(req.lang)(k);
const statusPill = (req, s, origin) => pill(s, s === 'review' && origin === 'source' ? (req.lang === 'ar' ? 'الاعتماد غير مؤكد' : 'Approval not confirmed') : label(req, s));
const title = (req, n) => req.lang === 'ar' ? (n.title_ar || n.title_en) : n.title_en;

// ---------------------------------------------------------------- auth
app.get('/login', async (req, res) => res.send(page(req, { title: 'Sign in', body: `<div class="login card"><h1>${esc(label(req, 'app'))}</h1>
  <p class="sub">${esc(label(req, 'company'))}</p>${(await q.get('SELECT id FROM users LIMIT 1')) ? '' : '<div class="flash err">No administrator exists yet. Set the IHSE_ADMIN_PASSWORD environment variable and redeploy/restart.</div>'}${req.query.err ? '<div class="flash err">Wrong username or password.</div>' : ''}
  <form method="post" action="/login"><input type="hidden" name="next" value="${esc(req.query.next || '/dashboard')}">
  <p><label>${esc(label(req, 'username'))}<input name="username" autocomplete="username" required></label></p>
  <p><label>${esc(label(req, 'password'))}<input name="password" type="password" autocomplete="current-password" required></label></p>
  <button>${esc(label(req, 'login'))}</button></form></div>` })));
const attempts = new Map();
app.post('/login', async (req, res) => {
  const key = req.ip + ':' + (req.body.username || '');
  const a = attempts.get(key) || { n: 0, t: Date.now() };
  if (a.n >= 8 && Date.now() - a.t < 15 * 60e3) return res.status(429).send('Too many attempts — wait 15 minutes.');
  const u = (await q.get('SELECT * FROM users WHERE username=? AND active=1', String(req.body.username || '')));
  if (!u || !bcrypt.compareSync(String(req.body.password || ''), u.pw_hash)) {
    attempts.set(key, { n: a.n + 1, t: a.n ? a.t : Date.now() }); await log(null, 'login_failed', 'user', req.body.username); return res.redirect('/login?err=1');
  }
  attempts.delete(key);
  const token = crypto.randomBytes(32).toString('hex');
  (await q.run("INSERT INTO sessions VALUES (?,?,datetime('now','+12 hours'))", crypto.createHash('sha256').update(token).digest('hex'), u.id));
  await log(u, 'login', 'user', u.id);
  res.append('Set-Cookie', `${COOKIE}=${token}; Path=/; HttpOnly; SameSite=Strict${process.env.IHSE_SECURE_COOKIE === '1' || req.secure ? '; Secure' : ''}; Max-Age=43200`);
  const next = String(req.body.next || '/dashboard');
  res.redirect(next.startsWith('/') && !next.startsWith('//') ? next : '/dashboard');
});
app.post('/logout', async (req, res) => {
  const ck = cookies(req)[COOKIE];
  if (ck) (await q.run('DELETE FROM sessions WHERE token=?', crypto.createHash('sha256').update(ck).digest('hex')));
  res.append('Set-Cookie', `${COOKIE}=; Path=/; Max-Age=0`); res.redirect('/login');
});
app.get('/lang/:l', async (req, res) => {
  res.append('Set-Cookie', `ihse_lang=${req.params.l === 'ar' ? 'ar' : 'en'}; Path=/; SameSite=Lax; Max-Age=31536000`);
  const n = String(req.query.next || '/dashboard'); res.redirect(n.startsWith('/') && !n.startsWith('//') ? n : '/dashboard');
});
app.get('/', (req, res) => res.redirect('/dashboard'));
app.use(requireAuth);

app.get('/account', (req, res) => res.send(page(req, { title: 'Account', crumbs: [['Account', '/account']], body: `<h1>Change password</h1>
  <form method="post" action="/account" class="card" style="max-width:420px"><p><label>Current password<input type="password" name="old" required></label></p>
  <p><label>New password (min 10 characters)<input type="password" name="pw" minlength="10" required></label></p><button>${esc(label(req, 'save'))}</button></form>` })));
app.post('/account', async (req, res) => {
  const u = (await q.get('SELECT * FROM users WHERE id=?', req.user.id));
  if (!bcrypt.compareSync(String(req.body.old || ''), u.pw_hash) || String(req.body.pw || '').length < 10) { flash(res, 'Password not changed: check the current password and use at least 10 characters.', true); return res.redirect('/account'); }
  (await q.run('UPDATE users SET pw_hash=? WHERE id=?', bcrypt.hashSync(String(req.body.pw), 10), u.id)); await log(req.user, 'password_change', 'user', u.id);
  flash(res, 'Password changed.'); res.redirect('/dashboard');
});

// ---------------------------------------------------------------- dashboard
function metricCard(lbl, m, extra = '') {
  const pct = m.d ? Math.round(100 * m.n / m.d) : 0;
  return `<div class="card kpi"><div class="l">${esc(lbl)}</div><div class="n">${m.n} <span class="muted" style="font-size:15px">/ ${m.d}</span></div><div class="bar"><i style="width:${pct}%"></i></div><div class="d">${esc(m.def)}</div>${extra}</div>`;
}
async function countryBlock(req, c) {
  const m = await countryMetrics(c), r = readiness(m), tr = t(req.lang);
  const ds = ['draft', 'review', 'approved', 'obsolete'].map(s => `<tr><td>${statusPill(req, s, s === 'review' ? 'source' : '')}</td><td class="num">${m.docStatus[s] || 0}</td></tr>`).join('');
  const ns = ['implemented-evidence', 'confirmation-required', 'evidence-missing', 'draft'].map(s => `<tr><td>${pill(s, tr(s))}</td><td class="num">${m.nodeStatus[s] || 0}</td></tr>`).join('');
  const up = m.upcoming.length ? `<ul class="tight">${m.upcoming.map(u => `<li>${esc(u.d)} — ${esc(u.kind)}: ${esc(u.label)}</li>`).join('')}</ul>` : '<p class="note">No dated actions or document reviews due in the next 60 days. Undated items are not shown here (see actions without due date).</p>';
  return `<h2>${esc(tr(c))} — <a href="/c/${c}">${esc(req.lang === 'ar' ? 'فتح مساحة العمل' : 'open workspace')}</a></h2>
  <div class="card" style="border-color:${r.ready ? '#9cc59c' : '#e3a3a3'}"><b>${esc(r.text)}</b>${r.reasons.length ? `<ul class="tight">${r.reasons.map(x => `<li>${esc(x)}</li>`).join('')}</ul>` : ''}
  <p class="note">Readiness is based on approvals, evidence and open gaps — not on documents existing. Documentation completeness and implementation evidence are reported separately below.</p></div>
  <h3>Requirements coverage (denominator: applicable subclauses of both standards)</h3>
  <div class="grid">${metricCard('Mapped to a subclause page', m.cov.mapped)}${metricCard('Documentation completeness', m.cov.documented)}${metricCard('Approved documentation', m.cov.approvedDoc)}${metricCard('Implementation evidence located', m.cov.evidence)}</div>
  <h3>Status</h3><div class="grid">
   <div class="card"><div class="l note">Controlled documents (excl. records & sources)</div><table>${ds}</table></div>
   <div class="card"><div class="l note">Subclause pages by status (of ${m.nodesTotal})</div><table>${ns}</table></div>
   <div class="card kpi"><div class="l">Open confirmation items</div><div class="n">${m.confOpen}</div><div class="d">${prio('H')} ${m.confP.H || 0} ${prio('M')} ${m.confP.M || 0} ${prio('L')} ${m.confP.L || 0}</div><div class="d"><a href="/confirmations?c=${c}">Open register</a></div></div>
   <div class="card kpi"><div class="l">Actions</div><div class="n">${m.actionsOpen} <span class="muted" style="font-size:14px">open</span></div><div class="d"><span class="pill overdue">${m.overdue} overdue</span> · ${m.noDue} without due date</div><div class="d">Audit findings: ${m.auditClosed} closed of ${m.auditAll} raised in portal</div><div class="d"><a href="/actions?c=${c}">Action tracker</a></div></div>
   <div class="card kpi"><div class="l">Completed records registered</div><div class="n">${m.records}</div><div class="d">${m.uploadedRecords} uploaded to portal; others are linked company source records (content verification pending).</div></div>
  </div><h3>Upcoming (next 60 days, dated items only)</h3><div class="card">${up}</div>`;
}
app.get('/dashboard', async (req, res) => {
  const cs = wsCountries(req);
  const ed = `<p class="note">Editions: ${esc(EDITIONS.ISO45001.label)} — ${esc(EDITIONS.ISO45001.verified)} · ${esc(EDITIONS.ISO14001.label)} — ${esc(EDITIONS.ISO14001.verified)}</p>`;
  res.send(page(req, { title: label(req, 'dashboard'), active: 'dashboard', body: `<h1>${esc(label(req, 'dashboard'))} — ${esc(req.ws === 'ALL' ? label(req, 'both') : label(req, req.ws))}</h1>${ed}
   ${cs.length > 1 ? '<p class="sub">Consolidated view: each country is calculated separately; figures are not merged.</p>' : ''}${(await Promise.all(cs.map(c => countryBlock(req, c)))).join('')}` }));
});

// ---------------------------------------------------------------- country / clause / subclause
app.param('country', (req, res, next, c) => {
  c = c.toUpperCase(); if (!['EG', 'SA'].includes(c) || !req.user.countries.includes(c)) return res.status(404).send(page(req, { title: 'Not found', body: '<h1>Workspace not available</h1>' }));
  req.country = c; req.ws = c; next();
});
app.get('/c/:country', async (req, res) => {
  const c = req.country;
  const rows = (await Promise.all(CLAUSES.map(async cl => {
    const ns = (await q.all('SELECT n.*, nc.status FROM nodes n JOIN node_country nc ON nc.node_code=n.code AND nc.country=? WHERE n.clause=? ORDER BY sort', c, cl.n));
    return `<tr><td><a href="/c/${c}/clause/${cl.n}"><b>${cl.n}. ${esc(req.lang === 'ar' ? cl.ar : cl.en)}</b></a></td><td>${ns.map(n => `<a href="/c/${c}/sub/${encodeURIComponent(n.code)}">${esc(n.code.replace(/[HE]$/, ''))}</a> ${pill(n.status, label(req, n.status))}`).join('<br>')}</td></tr>`;
  }))).join('');
  res.send(page(req, { title: label(req, c), crumbs: [[label(req, c), `/c/${c}`]], body: `<h1>${esc(label(req, c))}</h1>
   <p class="sub">Country → Clause → Subclause → documents and evidence. <a class="btn secondary" href="/exports/${c}.zip">${esc(label(req, 'export_zip'))}</a></p>
   ${await countryBlock(req, c)}<h2>${esc(label(req, 'clauses'))}</h2><div class="tablewrap"><table><tr><th>${esc(label(req, 'clause'))}</th><th>${esc(label(req, 'subclause'))}</th></tr>${rows}</table></div>` }));
});
app.get('/c/:country/clause/:n', async (req, res) => {
  const c = req.country, cl = CLAUSES.find(x => String(x.n) === req.params.n);
  if (!cl) return res.status(404).send(page(req, { title: 'Not found', body: '<h1>Clause not found</h1>' }));
  const ns = (await q.all('SELECT n.*, nc.status, nc.impl FROM nodes n JOIN node_country nc ON nc.node_code=n.code AND nc.country=? WHERE n.clause=? ORDER BY sort', c, cl.n));
  const body = (await Promise.all(ns.map(async n => {
    const refs = (await q.all('SELECT r.* FROM requirements r JOIN node_reqs nr ON nr.req_id=r.id WHERE nr.node_code=? ORDER BY r.sort', n.code));
    const gaps = (await q.get("SELECT COUNT(*) n FROM confirmations WHERE node_code=? AND country=? AND status<>'resolved'", n.code, c)).n;
    return `<div class="card" style="margin-bottom:10px"><h3 style="margin-top:0"><a href="/c/${c}/sub/${encodeURIComponent(n.code)}">${esc(n.code.replace(/[HE]$/, ''))} ${esc(title(req, n))}</a> ${pill(n.status, label(req, n.status))}</h3>
     <div class="note">${refs.map(r => `${r.standard === 'ISO45001' ? 'ISO 45001' : 'ISO 14001'} ${esc(r.ref)}`).join(' · ')}${gaps ? ` · <span class="pill confirm">${gaps} confirmation item(s)</span>` : ''}</div>
     <p ${req.lang === 'ar' ? 'class="ar"' : ''}>${esc(req.lang === 'ar' ? n.summary_ar : n.summary_en)}</p></div>`;
  }))).join('');
  res.send(page(req, { title: `${cl.n}. ${cl.en}`, active: 'clause' + cl.n, crumbs: [[label(req, c), `/c/${c}`], [`${cl.n}. ${req.lang === 'ar' ? cl.ar : cl.en}`, req.originalUrl]],
    body: `<h1>${cl.n}. ${esc(req.lang === 'ar' ? cl.ar : cl.en)} — ${esc(label(req, c))}</h1><p class="sub">Folder: ${esc(c === 'EG' ? 'Egypt' : 'KSA')}/${esc(cl.folder)}/</p>${body}` }));
});

function docRow(req, d) {
  return `<tr><td><a href="/documents/${d.id}">${esc(d.code)}</a></td><td>${esc(d.title_en)}${d.relevance ? `<div class="note">Relevance here: ${esc(d.relevance)}</div>` : ''}</td><td>${esc(label(req, d.doc_type))}</td><td>${statusPill(req, d.status, d.origin)}</td><td>${esc(d.record_date || '')}</td></tr>`;
}
app.get('/c/:country/sub/:code', async (req, res) => {
  const c = req.country, n = (await q.get('SELECT * FROM nodes WHERE code=?', req.params.code));
  if (!n) return res.status(404).send(page(req, { title: 'Not found', body: '<h1>Subclause not found</h1>' }));
  const nc = (await q.get('SELECT * FROM node_country WHERE node_code=? AND country=?', n.code, c));
  const cl = CLAUSES.find(x => x.n === n.clause);
  const reqs = (await q.all('SELECT r.* FROM requirements r JOIN node_reqs nr ON nr.req_id=r.id WHERE nr.node_code=? ORDER BY r.sort', n.code));
  const docs = (await q.all('SELECT d.*, l.relevance FROM documents d JOIN doc_links l ON l.doc_id=d.id WHERE l.node_code=? AND d.country=? ORDER BY d.doc_type, d.code', n.code, c));
  const gaps = (await q.all('SELECT * FROM confirmations WHERE node_code=? AND country=? ORDER BY status, priority', n.code, c));
  const acts = (await q.all('SELECT * FROM actions WHERE node_code=? AND country=? ORDER BY status, due_date', n.code, c));
  const ar = req.lang === 'ar';
  const tbl = (list, empty) => list.length ? `<div class="tablewrap"><table><tr><th>${esc(label(req, 'code'))}</th><th>${esc(label(req, 'title'))}</th><th>${esc(label(req, 'type'))}</th><th>${esc(label(req, 'status'))}</th><th>${esc(label(req, 'date'))}</th></tr>${list.map(d => docRow(req, d)).join('')}</table></div>` : `<p class="note">${esc(empty)}</p>`;
  const codeIds = Object.fromEntries((await q.all('SELECT code, id FROM documents WHERE country=?', c)).map(r => [r.code, r.id]));
  const implText = esc(nc.impl).replace(/\[([A-Z0-9\-, ]+)\]/g, (m, ids) => '[' + ids.split(',').map(id => { const d = codeIds[id.trim()]; return d ? `<a href="/documents/${d}">${id.trim()}</a>` : `<a href="/sources?q=${encodeURIComponent(id.trim())}">${id.trim()}</a>`; }).join(', ') + ']');
  const body = `<h1>${esc(n.code.replace(/[HE]$/, ''))} ${esc(title(req, n))}</h1>
  <p class="sub">${esc(label(req, c))} · ${pill(nc.status, label(req, nc.status))} · ${reqs.map(r => `${r.standard === 'ISO45001' ? 'ISO 45001' : 'ISO 14001'} ${esc(r.ref)}`).join(' · ')} · <a href="/c/${c === 'EG' ? 'SA' : 'EG'}/sub/${encodeURIComponent(n.code)}">${esc(c === 'EG' ? label(req, 'SA') : label(req, 'EG'))} →</a></p>
  <h2>${esc(label(req, 'req_summary'))}</h2><p>${esc(n.summary_en)}</p><p class="ar">${esc(n.summary_ar)}</p>
  <div class="tablewrap"><table><tr><th>${esc(label(req, 'standard'))}</th><th>${esc(label(req, 'clause'))}</th><th>${esc(label(req, 'title'))}</th><th>Requirement (paraphrased — not the standard text)</th></tr>
  ${reqs.map(r => `<tr><td>${esc(EDITIONS[r.standard].label)}</td><td>${esc(r.ref)}</td><td>${esc(r.title)}</td><td>${esc(r.paraphrase)}</td></tr>`).join('')}</table></div>
  <h2>${esc(label(req, 'how'))}</h2><p><b>Integrated method:</b> ${esc(n.method)}</p><div class="card"><b>${esc(label(req, c))}:</b> ${implText}</div>
  <h2>${esc(label(req, 'resp'))}</h2><div class="row"><div><h3>Responsibilities</h3><ul class="tight">${JSON.parse(n.roles).map(x => `<li>${esc(x)}</li>`).join('')}</ul></div>
  <div><h3>Process steps</h3><ol class="tight">${JSON.parse(n.steps).map(x => `<li>${esc(x)}</li>`).join('')}</ol></div></div>
  <h2>${esc(label(req, 'procs'))}</h2>${tbl(docs.filter(d => ['procedure', 'policy', 'instruction', 'register'].includes(d.doc_type)), 'No procedures linked.')}
  <h2>${esc(label(req, 'forms'))}</h2>${tbl(docs.filter(d => d.doc_type === 'form'), 'No blank form applies to this subclause.')}
  <h2>${esc(label(req, 'evidence'))}</h2><p class="note">Completed records only. Blank templates and generated drafts are never shown here as evidence.</p>${tbl(docs.filter(d => d.doc_type === 'record'), 'No completed records located for this site.')}
  ${docs.filter(d => d.doc_type === 'source').length ? `<h3>Original supporting sources</h3>${tbl(docs.filter(d => d.doc_type === 'source'), '')}` : ''}
  ${can(req.user, 'edit') ? `<p><a class="btn secondary" href="/documents/new?c=${c}&node=${encodeURIComponent(n.code)}&type=record">Add completed record</a> <a class="btn secondary" href="/documents/new?c=${c}&node=${encodeURIComponent(n.code)}">Register document</a></p>` : ''}
  <h2>${esc(label(req, 'gaps'))}</h2>${gaps.length ? gaps.map(g => `<div class="${g.status === 'resolved' ? 'card' : 'confirmbox'}"><b>${esc(g.id)}</b> ${prio(g.priority)} ${pill(g.status, label(req, g.status))} — ${g.status === 'resolved' ? '' : '<b>CONFIRMATION REQUIRED:</b> '}${esc(g.missing)}<div class="note">Why: ${esc(g.why || '')}${g.proposed ? ` · Proposed draft: ${esc(g.proposed)}` : ''} · Source/person: ${esc(g.source_person || '')}${g.resolution ? ` · Resolution: ${esc(g.resolution)}` : ''}</div></div>`).join('') : '<p class="note">No confirmation items.</p>'}
  ${acts.length ? `<h3>Actions</h3><ul class="tight">${acts.map(a => `<li>#${a.id} ${pill(a.status, label(req, a.status))} ${esc(a.description)} — ${esc(a.owner || '')} ${a.due_date ? '· due ' + esc(a.due_date) : '· no due date'}</li>`).join('')}</ul>` : ''}
  <h2>${esc(label(req, 'auditchk'))}</h2><ul class="tight">${JSON.parse(n.audit).map(x => `<li>${esc(x)}</li>`).join('')}</ul>
  ${can(req.user, 'control') ? `<form method="post" action="/c/${c}/sub/${encodeURIComponent(n.code)}/status" class="inline card"><label>${esc(label(req, 'status'))}<select name="status">${['implemented-evidence', 'confirmation-required', 'evidence-missing', 'draft', 'na'].map(s => `<option value="${s}" ${s === nc.status ? 'selected' : ''}>${esc(label(req, s))}</option>`).join('')}</select></label>
   <label style="flex:1">Implementation text (site-specific)<textarea name="impl">${esc(nc.impl)}</textarea></label><button>${esc(label(req, 'save'))}</button></form>` : ''}`;
  res.send(page(req, { title: `${n.code} ${n.title_en}`, active: 'node' + n.code, crumbs: [[label(req, c), `/c/${c}`], [`${cl.n}. ${ar ? cl.ar : cl.en}`, `/c/${c}/clause/${cl.n}`], [`${n.code.replace(/[HE]$/, '')} ${title(req, n)}`, req.originalUrl]], body }));
});
app.post('/c/:country/sub/:code/status', need('control'), async (req, res) => {
  const c = req.country, code = req.params.code;
  const st = String(req.body.status); if (!['implemented-evidence', 'confirmation-required', 'evidence-missing', 'draft', 'na'].includes(st)) return res.status(400).send('Bad status');
  if (st === 'na' && String(req.body.impl || '').length < 20) { flash(res, 'Not applicable needs a written justification in the implementation text.', true); return res.redirect(back(req, '/')); }
  (await q.run("UPDATE node_country SET status=?, impl=?, updated_at=datetime('now') WHERE node_code=? AND country=?", st, String(req.body.impl || ''), code, c));
  await log(req.user, 'subclause_update', 'node', code, c, { status: st });
  await regenerateImplementation(c, code, req.user.id, 'Regenerated after subclause update');
  flash(res, 'Saved. Implementation document regenerated as a new draft version.'); res.redirect(`/c/${c}/sub/${encodeURIComponent(code)}`);
});

// ---------------------------------------------------------------- documents
function docFilters(req) {
  const cs = wsCountries(req); const w = [`d.country IN (${inList(cs)})`]; const p = [...cs];
  const f = req.query;
  if (f.type) { w.push('d.doc_type=?'); p.push(f.type); }
  if (f.status) { w.push('d.status=?'); p.push(f.status); }
  if (f.origin) { w.push('d.origin=?'); p.push(f.origin); }
  if (f.owner) { w.push('d.owner LIKE ?'); p.push('%' + f.owner + '%'); }
  if (f.node) { w.push('EXISTS (SELECT 1 FROM doc_links l WHERE l.doc_id=d.id AND l.node_code=?)'); p.push(f.node); }
  if (f.clause) { w.push('EXISTS (SELECT 1 FROM doc_links l JOIN nodes n ON n.code=l.node_code WHERE l.doc_id=d.id AND n.clause=?)'); p.push(Number(f.clause)); }
  if (f.standard) { w.push('EXISTS (SELECT 1 FROM doc_links l JOIN node_reqs nr ON nr.node_code=l.node_code WHERE l.doc_id=d.id AND nr.req_id LIKE ?)'); p.push(f.standard + ':%'); }
  if (f.from) { w.push('COALESCE(d.record_date, d.updated_at, d.created_at) >= ?'); p.push(f.from); }
  if (f.to) { w.push('COALESCE(d.record_date, d.updated_at, d.created_at) <= ?'); p.push(f.to + 'T99'); }
  if (f.q) { w.push('(d.code LIKE ? OR d.title_en LIKE ? OR d.title_ar LIKE ? OR d.description LIKE ? OR d.owner LIKE ?)'); const s = '%' + f.q + '%'; p.push(s, s, s, s, s); }
  return { where: w.join(' AND '), params: p };
}
function filterForm(req, action, extra = '') {
  const f = req.query, sel = (name, opts) => `<select name="${name}"><option value="">${esc(label(req, 'all'))}</option>${opts.map(([v, l]) => `<option value="${esc(v)}" ${String(f[name] || '') === String(v) ? 'selected' : ''}>${esc(l)}</option>`).join('')}</select>`;
  return `<form class="inline card" method="get" action="${action}">
  <label>${esc(label(req, 'country'))}${sel('c', req.user.countries.map(c => [c, label(req, c)]))}</label>
  <label>${esc(label(req, 'standard'))}${sel('standard', [['ISO45001', 'ISO 45001'], ['ISO14001', 'ISO 14001']])}</label>
  <label>${esc(label(req, 'clause'))}${sel('clause', CLAUSES.map(c => [c.n, `${c.n}. ${c.en}`]))}</label>${extra}
  <label>${esc(label(req, 'owner'))}<input name="owner" value="${esc(f.owner || '')}" size="12"></label>
  <label>From<input type="date" name="from" value="${esc(f.from || '')}"></label><label>To<input type="date" name="to" value="${esc(f.to || '')}"></label>
  <label>Text<input name="q" value="${esc(f.q || '')}" size="14"></label><button>${esc(label(req, 'filter'))}</button></form>`;
}
app.get('/documents', async (req, res) => {
  const { where, params } = docFilters(req);
  const rows = (await q.all(`SELECT d.*, (SELECT group_concat(node_code, ', ') FROM doc_links WHERE doc_id=d.id) nodes, (SELECT MAX(version) FROM doc_versions WHERE doc_id=d.id) ver FROM documents d WHERE ${where} ORDER BY d.country, d.doc_type, d.code LIMIT 1000`, ...params));
  const types = ['procedure', 'policy', 'form', 'register', 'record', 'instruction', 'source'];
  const extra = `<label>${esc(label(req, 'type'))}<select name="type"><option value="">${esc(label(req, 'all'))}</option>${types.map(x => `<option value="${x}" ${req.query.type === x ? 'selected' : ''}>${esc(label(req, x))}</option>`).join('')}</select></label>
   <label>${esc(label(req, 'status'))}<select name="status"><option value="">${esc(label(req, 'all'))}</option>${['draft', 'review', 'approved', 'obsolete'].map(x => `<option value="${x}" ${req.query.status === x ? 'selected' : ''}>${esc(label(req, x))}</option>`).join('')}</select></label>`;
  const isRec = req.query.type === 'record';
  res.send(page(req, { title: label(req, isRec ? 'records' : 'documents'), active: isRec ? 'records' : 'documents', crumbs: [[label(req, isRec ? 'records' : 'documents'), req.originalUrl]],
    body: `<h1>${esc(label(req, isRec ? 'records' : 'documents'))} <span class="muted">(${rows.length})</span></h1>
    <p class="sub">Controlled procedures and policies, blank master forms, live registers, completed records and original sources are separate types.</p>
    ${filterForm(req, '/documents', extra)}${can(req.user, 'edit') ? `<p><a class="btn" href="/documents/new${req.ws !== 'ALL' ? '?c=' + req.ws : ''}">${esc(label(req, 'new_doc'))}</a></p>` : ''}
    <div class="tablewrap"><table><tr><th>${esc(label(req, 'country'))}</th><th>${esc(label(req, 'code'))}</th><th>${esc(label(req, 'title'))}</th><th>${esc(label(req, 'type'))}</th><th>${esc(label(req, 'status'))}</th><th>Origin</th><th>Ver.</th><th>Subclauses</th><th>${esc(label(req, 'date'))}</th></tr>
    ${rows.map(d => `<tr><td>${esc(d.country)}</td><td><a href="/documents/${d.id}">${esc(d.code)}</a></td><td>${esc(d.title_en)}</td><td>${esc(label(req, d.doc_type))}</td><td>${statusPill(req, d.status, d.origin)}</td><td>${esc(d.origin)}</td><td class="num">${d.ver || '—'}</td><td>${esc(d.nodes || '')}</td><td>${esc(d.record_date || '')}</td></tr>`).join('')}</table></div>` }));
});
app.get('/documents/new', need('edit'), async (req, res) => {
  const c = req.query.c && req.user.countries.includes(req.query.c) ? req.query.c : req.user.countries[0];
  const forms = (await q.all("SELECT id, code, title_en, country FROM documents WHERE doc_type='form' AND country IN (" + inList(req.user.countries) + ') ORDER BY code', ...req.user.countries));
  const nodes = (await q.all('SELECT code, title_en FROM nodes ORDER BY sort'));
  res.send(page(req, { title: label(req, 'new_doc'), crumbs: [[label(req, 'documents'), '/documents'], [label(req, 'new_doc'), req.originalUrl]], body: `<h1>${esc(label(req, 'new_doc'))}</h1>
  <form method="post" action="/documents" enctype="multipart/form-data" class="card">
  <div class="row"><label>${esc(label(req, 'country'))}<select name="country">${req.user.countries.map(x => `<option value="${x}" ${x === c ? 'selected' : ''}>${esc(label(req, x))}</option>`).join('')}</select></label>
  <label>${esc(label(req, 'type'))}<select name="doc_type">${['record', 'procedure', 'policy', 'form', 'register', 'instruction', 'source'].map(x => `<option value="${x}" ${req.query.type === x ? 'selected' : ''}>${esc(label(req, x))}</option>`).join('')}</select></label>
  <label>${esc(label(req, 'code'))}<input name="code" required maxlength="60" placeholder="e.g. EG-REC-2026-014"></label></div>
  <div class="row"><label>${esc(label(req, 'title'))} (EN)<input name="title_en" required maxlength="200"></label><label>${esc(label(req, 'title'))} (AR)<input name="title_ar" dir="rtl" maxlength="200"></label></div>
  <div class="row"><label>${esc(label(req, 'owner'))}<input name="owner" maxlength="80"></label><label>Record / activity date<input type="date" name="record_date"></label><label>Next review due<input type="date" name="review_due"></label></div>
  <div class="row"><label>Subclause(s)<select name="nodes" multiple size="6">${nodes.map(n => `<option value="${esc(n.code)}" ${req.query.node === n.code ? 'selected' : ''}>${esc(n.code)} ${esc(n.title_en)}</option>`).join('')}</select></label>
  <label>Made from blank form (records only)<select name="form_doc_id"><option value="">—</option>${forms.map(f => `<option value="${f.id}">${esc(f.country)} ${esc(f.code)} ${esc(f.title_en)}</option>`).join('')}</select></label></div>
  <label>Relevance to the selected subclause(s)<input name="relevance" maxlength="300"></label>
  <label>Description<textarea name="description" maxlength="2000"></textarea></label>
  <label>File (docx, xlsx, pdf, pptx, png, jpg, txt, csv — max ${MAX_UPLOAD_MB} MB)<input type="file" name="file"></label>
  <p><button>${esc(label(req, 'save'))}</button></p></form>` }));
});
app.post('/documents', need('edit'), upload.single('file'), async (req, res) => {
  const b = req.body, c = String(b.country);
  if (!req.user.countries.includes(c)) return res.status(403).send('Country not permitted');
  if (!['procedure', 'policy', 'form', 'register', 'record', 'instruction', 'source'].includes(b.doc_type)) return res.status(400).send('Bad type');
  if (req.file && !ALLOWED.has(path.extname(req.file.originalname).toLowerCase())) { flash(res, 'File type not allowed.', true); return res.redirect(back(req, '/documents/new')); }
  if ((await q.get('SELECT id FROM documents WHERE country=? AND code=?', c, String(b.code).trim()))) { flash(res, 'That code already exists in this country.', true); return res.redirect(back(req, '/documents/new')); }
  const id = Number((await q.insert(`INSERT INTO documents (country,code,title_en,title_ar,doc_type,status,origin,owner,record_date,review_due,description,form_doc_id) VALUES (?,?,?,?,?,'draft','uploaded',?,?,?,?,?)`,
    c, String(b.code).trim(), b.title_en, b.title_ar || null, b.doc_type, b.owner || null, b.record_date || null, b.review_due || null, b.description || null, b.form_doc_id ? Number(b.form_doc_id) : null)));
  for (const nd of [].concat(b.nodes || [])) await q.run('INSERT OR IGNORE INTO doc_links VALUES (?,?,?)', id, nd, b.relevance || null);
  if (req.file) await saveVersion(id, req.file.buffer, req.file.originalname, 'Initial upload', req.user.id);
  await log(req.user, 'document_create', 'document', id, c, { code: b.code, type: b.doc_type });
  flash(res, 'Registered as draft.'); res.redirect('/documents/' + id);
});
async function getDoc(req, res) {
  const d = (await q.get('SELECT * FROM documents WHERE id=?', Number(req.params.id)));
  if (!d || !allowedCountry(req, d.country)) { res.status(404).send(page(req, { title: 'Not found', body: '<h1>Document not found</h1>' })); return null; }
  return d;
}
app.get('/documents/:id', async (req, res) => {
  const d = await getDoc(req, res); if (!d) return;
  req.ws = d.country;
  const vers = (await q.all('SELECT v.*, u.name uname FROM doc_versions v LEFT JOIN users u ON u.id=v.created_by WHERE doc_id=? ORDER BY version DESC', d.id));
  const links = (await q.all('SELECT l.*, n.title_en FROM doc_links l JOIN nodes n ON n.code=l.node_code WHERE doc_id=?', d.id));
  const src = d.source_id ? (await q.get('SELECT * FROM sources WHERE id=?', d.source_id)) : null;
  const form = d.form_doc_id ? (await q.get('SELECT id, code, title_en FROM documents WHERE id=?', d.form_doc_id)) : null;
  const madeFrom = d.doc_type === 'form' ? (await q.all('SELECT id, code, title_en, record_date FROM documents WHERE form_doc_id=? ORDER BY record_date DESC', d.id)) : [];
  const appr = d.approved_by ? (await q.get('SELECT name FROM users WHERE id=?', d.approved_by)) : null;
  const hist = (await q.all("SELECT * FROM audit_log WHERE entity='document' AND entity_id=? ORDER BY id DESC LIMIT 30", String(d.id)));
  const lv = vers[0];
  const canPreview = lv && (PDF_ENABLED ? /\.(pdf|png|jpe?g|docx|xlsx|pptx|txt)$/i : /\.(pdf|png|jpe?g|txt)$/i).test(lv.file_name);
  const wf = [];
  if (can(req.user, 'edit') && d.status === 'draft') wf.push(['submit', 'Submit for review']);
  if (can(req.user, 'approve') && d.status === 'review') wf.push(['approve', 'Approve'], ['reject', 'Return to draft']);
  if (can(req.user, 'control') && d.status === 'approved') wf.push(['obsolete', 'Mark obsolete']);
  const body = `<h1>${esc(d.code)} — ${esc(d.title_en)}</h1>${d.title_ar ? `<p class="ar">${esc(d.title_ar)}</p>` : ''}
  <p class="sub">${esc(label(req, d.country))} · ${esc(label(req, d.doc_type))} · ${statusPill(req, d.status, d.origin)} · origin: ${esc(d.origin)}${d.approved_version ? ` · approved version v${d.approved_version}${appr ? ' by ' + esc(appr.name) : ''} on ${esc(d.approved_at)}` : ''}</p>
  ${d.status !== 'approved' ? `<div class="confirmbox"><b>${d.origin === 'source' ? 'Approval in the company system not confirmed' : 'Not approved'}</b> — do not present this as approved evidence.${d.status_note ? ' Note: ' + esc(d.status_note) : ''}</div>` : ''}
  <div class="row"><div class="card"><h3 style="margin-top:0">Details</h3><table>
   <tr><th>${esc(label(req, 'owner'))}</th><td>${esc(d.owner || '—')}</td></tr><tr><th>Record / file date</th><td>${esc(d.record_date || '—')}</td></tr>
   <tr><th>Review due</th><td>${esc(d.review_due || '—')}</td></tr><tr><th>Description</th><td>${esc(d.description || '')}</td></tr>
   ${src ? `<tr><th>Original source</th><td>${esc(src.id)} · ${esc(src.location)}${src.url ? `<br><a href="${esc(src.url)}" target="_blank" rel="noopener noreferrer">Open in SharePoint</a>` : ''}<div class="note">Access: ${esc(src.access)}. ${esc(src.note || '')}</div></td></tr>` : ''}
   ${form ? `<tr><th>Made from form</th><td><a href="/documents/${form.id}">${esc(form.code)} ${esc(form.title_en)}</a></td></tr>` : ''}
   <tr><th>Subclauses</th><td>${links.map(l => `<a href="/c/${d.country}/sub/${encodeURIComponent(l.node_code)}">${esc(l.node_code)} ${esc(l.title_en)}</a>${l.relevance ? `<div class="note">${esc(l.relevance)}</div>` : ''}`).join('<br>') || '—'}</td></tr></table>
   ${lv ? `<p><a class="btn" href="/documents/${d.id}/download">${esc(label(req, 'download'))} (v${lv.version})</a> ${canPreview ? `<a class="btn secondary" href="/documents/${d.id}/preview">${esc(label(req, 'preview'))}</a>` : ''} ${PDF_ENABLED && /\.(docx|xlsx|pptx)$/i.test(lv.file_name) ? `<a class="btn secondary" href="/documents/${d.id}/pdf">PDF</a>` : ''}</p>` : '<p class="note">No file stored in the portal' + (src ? ' — the original stays in SharePoint.' : '.') + '</p>'}
   ${wf.length ? `<form method="post" action="/documents/${d.id}/workflow" class="inline"><label>Comment<input name="note" maxlength="300"></label>${wf.map(([a, l]) => `<button name="action" value="${a}" ${a === 'reject' || a === 'obsolete' ? 'class="secondary"' : ''}>${esc(l)}</button>`).join('')}</form>` : ''}
   ${d.gen_key && can(req.user, 'control') ? `<form method="post" action="/documents/${d.id}/regenerate"><button class="secondary">Regenerate from portal data (new version)</button></form>` : ''}
  </div>
  <div class="card"><h3 style="margin-top:0">${esc(label(req, 'versions'))}</h3><table><tr><th>Ver</th><th>File</th><th>Size</th><th>SHA-256</th><th>By / date</th><th>Note</th></tr>
   ${vers.map(v => `<tr><td><a href="/documents/${d.id}/download?v=${v.version}">v${v.version}</a>${v.version === d.approved_version ? ' ' + pill('approved', 'approved') : ''}</td><td>${esc(v.file_name)}</td><td class="num">${v.size}</td><td><code title="${esc(v.sha256)}">${esc(v.sha256.slice(0, 10))}…</code></td><td>${esc(v.uname || 'system')}<br>${esc(v.created_at)}</td><td>${esc(v.change_note || '')}</td></tr>`).join('') || '<tr><td colspan="6">No versions</td></tr>'}</table>
   ${can(req.user, 'edit') && d.status !== 'obsolete' ? `<form method="post" action="/documents/${d.id}/version" enctype="multipart/form-data" class="inline"><label>New version<input type="file" name="file" required></label><label>Change note<input name="note" required maxlength="300"></label><button>${esc(label(req, 'upload'))}</button></form><p class="note">Uploading a new version of an approved document returns it to Draft; the approved version stays in history.</p>` : ''}</div></div>
  ${madeFrom.length || d.doc_type === 'form' ? `<h2>Completed records made from this form</h2>${madeFrom.length ? `<ul class="tight">${madeFrom.map(r => `<li><a href="/documents/${r.id}">${esc(r.code)}</a> ${esc(r.title_en)} ${esc(r.record_date || '')}</li>`).join('')}</ul>` : '<p class="note">None registered yet.</p>'}` : ''}
  ${can(req.user, 'edit') ? `<h2>Edit metadata</h2><form method="post" action="/documents/${d.id}/meta" class="card"><div class="row"><label>${esc(label(req, 'title'))} (EN)<input name="title_en" value="${esc(d.title_en)}" required></label><label>${esc(label(req, 'title'))} (AR)<input name="title_ar" dir="rtl" value="${esc(d.title_ar || '')}"></label></div>
   <div class="row"><label>${esc(label(req, 'owner'))}<input name="owner" value="${esc(d.owner || '')}"></label><label>Record / activity date<input type="date" name="record_date" value="${esc((d.record_date || '').slice(0, 10))}"></label><label>Review due<input type="date" name="review_due" value="${esc(d.review_due || '')}"></label></div>
   <label>Description<textarea name="description">${esc(d.description || '')}</textarea></label>
   <div class="row"><label>Link to subclause<select name="add_node"><option value="">—</option>${(await q.all('SELECT code,title_en FROM nodes ORDER BY sort')).map(n => `<option value="${esc(n.code)}">${esc(n.code)} ${esc(n.title_en)}</option>`).join('')}</select></label><label>Relevance for that subclause<input name="relevance"></label></div>
   <button>${esc(label(req, 'save'))}</button></form>` : ''}
  <h2>Change history</h2><div class="tablewrap"><table><tr><th>When</th><th>Who</th><th>Action</th><th>Detail</th></tr>${hist.map(h => `<tr><td>${esc(h.ts)}</td><td>${esc(h.username)}</td><td>${esc(h.action)}</td><td>${esc(h.detail || '')}</td></tr>`).join('')}</table></div>`;
  res.send(page(req, { title: d.code, crumbs: [[label(req, 'documents'), '/documents?c=' + d.country], [d.code, req.originalUrl]], body }));
});
app.post('/documents/:id/version', need('edit'), upload.single('file'), async (req, res) => {
  const d = await getDoc(req, res); if (!d) return;
  if (!req.file || !ALLOWED.has(path.extname(req.file.originalname).toLowerCase())) { flash(res, 'Choose an allowed file type.', true); return res.redirect('/documents/' + d.id); }
  const v = await saveVersion(d.id, req.file.buffer, req.file.originalname, String(req.body.note || ''), req.user.id);
  if (d.status !== 'draft') (await q.run("UPDATE documents SET status='draft', status_note=? WHERE id=?", `New version v${v} uploaded`, d.id));
  await log(req.user, 'version_upload', 'document', d.id, d.country, { version: v, file: req.file.originalname, previous_status: d.status });
  flash(res, `Version v${v} stored; document is now Draft.`); res.redirect('/documents/' + d.id);
});
app.post('/documents/:id/meta', need('edit'), async (req, res) => {
  const d = await getDoc(req, res); if (!d) return; const b = req.body;
  (await q.run("UPDATE documents SET title_en=?, title_ar=?, owner=?, record_date=?, review_due=?, description=?, updated_at=datetime('now') WHERE id=?", b.title_en || d.title_en, b.title_ar || null, b.owner || null, b.record_date || d.record_date, b.review_due || null, b.description || null, d.id));
  if (b.add_node) (await q.run('INSERT OR REPLACE INTO doc_links VALUES (?,?,?)', d.id, b.add_node, b.relevance || null));
  await log(req.user, 'metadata_edit', 'document', d.id, d.country, { owner: b.owner, review_due: b.review_due, add_node: b.add_node || undefined });
  flash(res, 'Metadata saved.'); res.redirect('/documents/' + d.id);
});
app.post('/documents/:id/workflow', async (req, res) => {
  const d = await getDoc(req, res); if (!d) return; const a = req.body.action, note = String(req.body.note || '').slice(0, 300);
  const lv = await latest(d.id);
  const T = { submit: ['edit', 'draft', 'review'], approve: ['approve', 'review', 'approved'], reject: ['approve', 'review', 'draft'], obsolete: ['control', 'approved', 'obsolete'] }[a];
  if (!T || !can(req.user, T[0]) || d.status !== T[1]) return res.status(403).send(page(req, { title: 'Not permitted', body: '<h1>Not permitted</h1><p>This transition is not allowed for your role or the current status.</p>' }));
  if (a === 'approve') {
    if (!lv) { flash(res, 'Nothing to approve: no file version stored.', true); return res.redirect('/documents/' + d.id); }
    if (lv.created_by === req.user.id) { flash(res, 'You uploaded this version — another approver must approve it.', true); return res.redirect('/documents/' + d.id); }
    (await q.run("UPDATE documents SET status='approved', approved_by=?, approved_at=datetime('now'), approved_version=?, status_note=? WHERE id=?", req.user.id, lv.version, note || null, d.id));
  } else (await q.run('UPDATE documents SET status=?, status_note=? WHERE id=?', T[2], note || null, d.id));
  await log(req.user, 'workflow_' + a, 'document', d.id, d.country, { from: d.status, to: T[2], version: lv && lv.version, note });
  flash(res, `Status: ${T[2]}.`); res.redirect('/documents/' + d.id);
});
app.post('/documents/:id/regenerate', need('control'), async (req, res) => {
  const d = await getDoc(req, res); if (!d || !d.gen_key) return;
  if (d.gen_key.startsWith('IMPL:')) await regenerateImplementation(d.country, d.gen_key.slice(5), req.user.id);
  else if (d.gen_key.startsWith('R-')) { await regenerateRegister(d.country, d.gen_key); const lv = await latest(d.id); (await q.run('UPDATE doc_versions SET created_by=? WHERE id=?', req.user.id, lv.id)); }
  else { flash(res, 'Blank forms are fixed masters; upload a revised file instead.', true); return res.redirect('/documents/' + d.id); }
  if (d.status !== 'draft') (await q.run("UPDATE documents SET status='draft', status_note='Regenerated' WHERE id=?", d.id));
  await log(req.user, 'regenerate', 'document', d.id, d.country); flash(res, 'Regenerated as a new draft version.'); res.redirect('/documents/' + d.id);
});
async function sendVersion(req, res) {
  const d = await getDoc(req, res); if (!d) return null;
  const v = req.query.v ? (await q.get('SELECT * FROM doc_versions WHERE doc_id=? AND version=?', d.id, Number(req.query.v))) : await latest(d.id);
  const buf = v ? await readBlob(v) : null;
  if (!v || !buf) { res.status(404).send('No file'); return null; }
  return { d, v, buf };
}
app.get('/documents/:id/download', async (req, res) => {
  const r = await sendVersion(req, res); if (!r) return;
  await log(req.user, 'download', 'document', r.d.id, r.d.country, { version: r.v.version });
  const suffix = r.d.status === 'approved' && r.v.version === r.d.approved_version ? '' : '_' + (r.d.status === 'approved' ? 'NOT-APPROVED-VERSION' : r.d.status.toUpperCase());
  res.attachment(r.v.file_name.replace(/(\.[^.]+)$/, `${suffix}_v${r.v.version}$1`)); res.type(r.v.mime); res.send(r.buf);
});
function toPdf(v, buf) {
  return new Promise((resolve, reject) => {
    fs.mkdirSync(CACHE, { recursive: true });
    const out = path.join(CACHE, v.sha256 + '.pdf');
    if (fs.existsSync(out)) return resolve(out);
    const tmp = fs.mkdtempSync(path.join(CACHE, 'conv-')); const src = path.join(tmp, 'in' + path.extname(v.file_name).toLowerCase());
    fs.writeFileSync(src, buf);
    execFile(process.env.SOFFICE || 'soffice', ['--headless', '--norestore', `-env:UserInstallation=file://${tmp}/profile`, '--convert-to', 'pdf', '--outdir', tmp, src], { timeout: 120000 }, (err) => {
      const pdf = path.join(tmp, 'in.pdf');
      if (err || !fs.existsSync(pdf)) { fs.rmSync(tmp, { recursive: true, force: true }); return reject(new Error('PDF conversion unavailable (LibreOffice not installed or failed)')); }
      fs.renameSync(pdf, out); fs.rmSync(tmp, { recursive: true, force: true }); resolve(out);
    });
  });
}
app.get('/documents/:id/pdf', async (req, res) => {
  const r = await sendVersion(req, res); if (!r) return;
  try {
    const pdf = /\.pdf$/i.test(r.v.file_name) ? r.buf : fs.readFileSync(await toPdf(r.v, r.buf));
    res.set('Content-Type', 'application/pdf');
    res.set('Content-Disposition', `${req.query.inline ? 'inline' : 'attachment'}; filename="${r.d.code.replace(/[^\w.-]/g, '_')}_v${r.v.version}.pdf"`);
    res.send(pdf);
  } catch (e) { res.status(503).send(esc(e.message)); }
});
app.get('/documents/:id/preview', async (req, res) => {
  const r = await sendVersion(req, res); if (!r) return;
  const { d, v } = r; req.ws = d.country;
  let inner;
  if (/^image\//.test(v.mime)) inner = `<img src="/documents/${d.id}/raw?v=${v.version}" alt="${esc(d.title_en)}" style="max-width:100%">`;
  else if (/\.txt$/i.test(v.file_name)) inner = `<pre class="card" style="white-space:pre-wrap">${esc(r.buf.toString('utf8').slice(0, 200000))}</pre>`;
  else inner = `<iframe class="preview" src="/documents/${d.id}/pdf?inline=1&v=${v.version}" title="Preview"></iframe><p class="note">Office files are converted to PDF with LibreOffice for preview; download the original for editing.</p>`;
  res.send(page(req, { title: 'Preview ' + d.code, crumbs: [[label(req, 'documents'), '/documents'], [d.code, '/documents/' + d.id], [label(req, 'preview'), req.originalUrl]], body: `<h1>${esc(d.code)} v${v.version}</h1>${inner}` }));
});
app.get('/documents/:id/raw', async (req, res) => {
  const r = await sendVersion(req, res); if (!r) return;
  if (!/^image\//.test(r.v.mime)) return res.status(400).send('Not an image');
  res.set('Content-Type', r.v.mime); res.send(r.buf);
});

// ---------------------------------------------------------------- actions
app.get('/actions', async (req, res) => {
  const cs = wsCountries(req), f = req.query; const w = [`a.country IN (${inList(cs)})`], p = [...cs];
  if (f.status) { w.push('a.status=?'); p.push(f.status); } if (f.owner) { w.push('a.owner LIKE ?'); p.push('%' + f.owner + '%'); }
  if (f.clause) { w.push('n.clause=?'); p.push(Number(f.clause)); } if (f.q) { w.push('a.description LIKE ?'); p.push('%' + f.q + '%'); }
  if (f.standard) { w.push('EXISTS (SELECT 1 FROM node_reqs nr WHERE nr.node_code=a.node_code AND nr.req_id LIKE ?)'); p.push(f.standard + ':%'); }
  if (f.from) { w.push('a.due_date>=?'); p.push(f.from); } if (f.to) { w.push('a.due_date<=?'); p.push(f.to); }
  if (f.overdue) { w.push("a.due_date < date('now') AND a.status IN ('open','in_progress')"); }
  const rows = (await q.all(`SELECT a.*, d.code ev_code FROM actions a LEFT JOIN nodes n ON n.code=a.node_code LEFT JOIN documents d ON d.id=a.evidence_doc_id WHERE ${w.join(' AND ')} ORDER BY a.status IN ('done','verified','cancelled'), a.due_date IS NULL, a.due_date`, ...p));
  const today = new Date().toISOString().slice(0, 10);
  const nodes = (await q.all('SELECT code,title_en FROM nodes ORDER BY sort'));
  const editable = can(req.user, 'actions');
  res.send(page(req, { title: label(req, 'actions'), active: 'actions', crumbs: [[label(req, 'actions'), req.originalUrl]], body: `<h1>${esc(label(req, 'actions'))} <span class="muted">(${rows.length})</span></h1>
  <p class="sub">Corrective actions, audit findings, MR and meeting actions, and portal-review findings. Overdue = past due date and not done.</p>
  ${filterForm(req, '/actions', `<label>${esc(label(req, 'status'))}<select name="status"><option value="">${esc(label(req, 'all'))}</option>${['open', 'in_progress', 'done', 'verified', 'cancelled'].map(s => `<option value="${s}" ${f.status === s ? 'selected' : ''}>${esc(label(req, s))}</option>`).join('')}</select></label><label>Overdue only<input type="checkbox" name="overdue" value="1" ${f.overdue ? 'checked' : ''}></label>`)}
  <div class="tablewrap"><table><tr><th>#</th><th>${esc(label(req, 'country'))}</th><th>Source</th><th>Subclause</th><th>Action</th><th>${esc(label(req, 'owner'))}</th><th>${esc(label(req, 'due'))}</th><th>${esc(label(req, 'status'))}</th><th>Evidence / effectiveness</th>${editable ? '<th>Update</th>' : ''}</tr>
  ${rows.map(a => { const od = a.due_date && a.due_date < today && ['open', 'in_progress'].includes(a.status);
    return `<tr><td>${a.id}</td><td>${esc(a.country)}</td><td>${esc(a.source)}${a.origin === 'portal-review' ? '<div class="note">portal review</div>' : ''}</td><td>${a.node_code ? `<a href="/c/${a.country}/sub/${encodeURIComponent(a.node_code)}">${esc(a.node_code)}</a>` : ''}</td><td>${esc(a.description)}</td><td>${esc(a.owner || '')}</td>
    <td>${a.due_date ? esc(a.due_date) : '<span class="pill confirm">no due date</span>'}${od ? ' <span class="pill overdue">overdue</span>' : ''}</td><td>${pill(a.status, label(req, a.status))}</td><td>${a.ev_code ? `<a href="/documents/${a.evidence_doc_id}">${esc(a.ev_code)}</a>` : ''} ${esc(a.effectiveness || '')}</td>
    ${editable ? `<td><form method="post" action="/actions/${a.id}" class="inline" style="margin:0"><select name="status" aria-label="status">${['open', 'in_progress', 'done', 'verified', 'cancelled'].map(s => `<option value="${s}" ${a.status === s ? 'selected' : ''}>${esc(label(req, s))}</option>`).join('')}</select><input type="date" name="due_date" value="${esc(a.due_date || '')}" aria-label="due"><input name="owner" value="${esc(a.owner || '')}" size="10" aria-label="owner"><input name="evidence_code" placeholder="evidence doc code" size="10" aria-label="evidence"><input name="effectiveness" placeholder="effectiveness check" size="12" aria-label="effectiveness"><button class="secondary">${esc(label(req, 'save'))}</button></form></td>` : ''}</tr>`; }).join('')}</table></div>
  ${editable ? `<h2>${esc(label(req, 'new_action'))}</h2><form method="post" action="/actions" class="card"><div class="row"><label>${esc(label(req, 'country'))}<select name="country">${req.user.countries.map(c => `<option value="${c}" ${req.ws === c ? 'selected' : ''}>${esc(label(req, c))}</option>`).join('')}</select></label>
   <label>Source<select name="source">${['Internal audit', 'External audit', 'Incident', 'Inspection', 'Management review', 'Meeting', 'Legal evaluation', 'Risk assessment', 'Improvement', 'Other'].map(s => `<option>${s}</option>`).join('')}</select></label>
   <label>Subclause<select name="node_code"><option value="">—</option>${nodes.map(n => `<option value="${esc(n.code)}">${esc(n.code)} ${esc(n.title_en)}</option>`).join('')}</select></label><label>Reference (e.g. audit finding no.)<input name="ref"></label></div>
   <label>Action<textarea name="description" required maxlength="1000"></textarea></label><div class="row"><label>${esc(label(req, 'owner'))}<input name="owner" required></label><label>${esc(label(req, 'due'))}<input type="date" name="due_date"></label></div><p><button>${esc(label(req, 'save'))}</button></p></form>` : ''}` }));
});
app.post('/actions', need('actions'), async (req, res) => {
  const b = req.body; if (!req.user.countries.includes(b.country) || !String(b.description || '').trim()) return res.status(400).send('Invalid');
  const id = (await q.insert('INSERT INTO actions (country,node_code,source,ref,description,owner,due_date,created_by) VALUES (?,?,?,?,?,?,?,?)', b.country, b.node_code || null, b.source, b.ref || null, b.description, b.owner, b.due_date || null, req.user.id));
  await log(req.user, 'action_create', 'action', id, b.country, { source: b.source }); flash(res, 'Action #' + id + ' created.'); res.redirect('/actions?c=' + b.country);
});
app.post('/actions/:id', need('actions'), async (req, res) => {
  const a = (await q.get('SELECT * FROM actions WHERE id=?', Number(req.params.id))); if (!a || !allowedCountry(req, a.country)) return res.status(404).send('Not found');
  const b = req.body; if (!['open', 'in_progress', 'done', 'verified', 'cancelled'].includes(b.status)) return res.status(400).send('Bad status');
  let ev = a.evidence_doc_id;
  if (b.evidence_code) { const d = (await q.get('SELECT id FROM documents WHERE country=? AND code=?', a.country, String(b.evidence_code).trim())); if (!d) { flash(res, 'Evidence document code not found in this country.', true); return res.redirect(back(req, '/actions')); } ev = d.id; }
  if (b.status === 'verified' && !ev && !b.effectiveness && !a.effectiveness) { flash(res, 'Verified effective needs evidence or an effectiveness note.', true); return res.redirect(back(req, '/actions')); }
  (await q.run("UPDATE actions SET status=?, due_date=?, owner=?, evidence_doc_id=?, effectiveness=COALESCE(NULLIF(?, ''), effectiveness), updated_at=datetime('now') WHERE id=?", b.status, b.due_date || null, b.owner || a.owner, ev, b.effectiveness || '', a.id));
  await log(req.user, 'action_update', 'action', a.id, a.country, { from: a.status, to: b.status, due: b.due_date }); flash(res, 'Action #' + a.id + ' updated.'); res.redirect(back(req, '/actions'));
});

// ---------------------------------------------------------------- confirmations
app.get('/confirmations', async (req, res) => {
  const cs = [...wsCountries(req), 'GL']; const f = req.query; const w = [`country IN (${inList(cs)})`], p = [...cs];
  if (f.status) { w.push('status=?'); p.push(f.status); } if (f.priority) { w.push('priority=?'); p.push(f.priority); } if (f.q) { w.push('(missing LIKE ? OR id LIKE ?)'); p.push('%' + f.q + '%', '%' + f.q + '%'); }
  if (f.clause) { w.push("node_code IN (SELECT code FROM nodes WHERE clause=?)"); p.push(Number(f.clause)); }
  const rows = (await q.all(`SELECT * FROM confirmations WHERE ${w.join(' AND ')} ORDER BY status='resolved', CASE priority WHEN 'H' THEN 0 WHEN 'M' THEN 1 ELSE 2 END, id`, ...p));
  res.send(page(req, { title: label(req, 'confirmations'), active: 'confirmations', crumbs: [[label(req, 'confirmations'), req.originalUrl]], body: `<h1>${esc(label(req, 'confirmations'))} <span class="muted">(${rows.length})</span></h1>
  <p class="sub">Missing information and confirmation register. Every open item is highlighted in yellow and labelled. <a href="/exports/confirmations.xlsx?c=${req.ws}">Export (xlsx)</a></p>
  <form class="inline card" method="get"><label>${esc(label(req, 'country'))}<select name="c"><option value="">${esc(label(req, 'all'))}</option>${req.user.countries.map(c => `<option value="${c}" ${req.ws === c ? 'selected' : ''}>${esc(label(req, c))}</option>`).join('')}</select></label>
  <label>${esc(label(req, 'clause'))}<select name="clause"><option value="">${esc(label(req, 'all'))}</option>${CLAUSES.map(c => `<option value="${c.n}" ${String(f.clause) === String(c.n) ? 'selected' : ''}>${c.n}. ${esc(c.en)}</option>`).join('')}</select></label>
  <label>${esc(label(req, 'priority'))}<select name="priority"><option value="">${esc(label(req, 'all'))}</option>${['H', 'M', 'L'].map(x => `<option ${f.priority === x ? 'selected' : ''}>${x}</option>`).join('')}</select></label>
  <label>${esc(label(req, 'status'))}<select name="status"><option value="">${esc(label(req, 'all'))}</option>${['open', 'resolved'].map(x => `<option value="${x}" ${f.status === x ? 'selected' : ''}>${esc(label(req, x))}</option>`).join('')}</select></label><label>Text<input name="q" value="${esc(f.q || '')}"></label><button>${esc(label(req, 'filter'))}</button></form>
  <div class="tablewrap"><table><tr><th>ID</th><th>${esc(label(req, 'country'))}</th><th>Clause / item</th><th>Exact missing information</th><th>Why needed</th><th>Proposed draft</th><th>Source / person</th><th>${esc(label(req, 'owner'))}</th><th>${esc(label(req, 'priority'))}</th><th>${esc(label(req, 'status'))}</th>${can(req.user, 'confirm') ? '<th>Resolve</th>' : ''}</tr>
  ${rows.map(r => `<tr ${r.status !== 'resolved' ? 'style="background:#fffbd0"' : ''}><td>${esc(r.id)}</td><td>${esc(r.country)}</td><td>${r.node_code ? `<a href="/c/${r.country === 'GL' ? 'EG' : r.country}/sub/${encodeURIComponent(r.node_code)}">${esc(r.node_code)}</a>` : 'Global'}</td><td>${r.status !== 'resolved' ? '<b>CONFIRMATION REQUIRED:</b> ' : ''}${esc(r.missing)}</td><td>${esc(r.why || '')}</td><td>${esc(r.proposed || '')}</td><td>${esc(r.source_person || '')}</td><td>${esc(r.owner || '')}</td><td>${prio(r.priority)}</td><td>${pill(r.status, label(req, r.status))}${r.resolution ? `<div class="note">${esc(r.resolution)}</div>` : ''}</td>
  ${can(req.user, 'confirm') ? `<td><form method="post" action="/confirmations/${encodeURIComponent(r.id)}" class="inline" style="margin:0"><input name="resolution" placeholder="answer / evidence ref" size="16" aria-label="resolution" ${r.status === 'resolved' ? '' : 'required'}><input name="owner" value="${esc(r.owner || '')}" size="10" aria-label="owner"><select name="status" aria-label="status"><option value="resolved">resolve</option><option value="open">re-open</option></select><button class="secondary">${esc(label(req, 'save'))}</button></form></td>` : ''}</tr>`).join('')}</table></div>` }));
});
app.post('/confirmations/:id', need('confirm'), async (req, res) => {
  const r = (await q.get('SELECT * FROM confirmations WHERE id=?', req.params.id)); if (!r || !allowedCountry(req, r.country)) return res.status(404).send('Not found');
  const st = req.body.status === 'open' ? 'open' : 'resolved';
  if (st === 'resolved' && !String(req.body.resolution || '').trim()) { flash(res, 'Give the answer or evidence reference to resolve.', true); return res.redirect(back(req, '/confirmations')); }
  (await q.run("UPDATE confirmations SET status=?, resolution=COALESCE(NULLIF(?,''), resolution), owner=?, updated_at=datetime('now') WHERE id=?", st, String(req.body.resolution || ''), req.body.owner || r.owner, r.id));
  await log(req.user, 'confirmation_' + st, 'confirmation', r.id, r.country, { resolution: req.body.resolution }); flash(res, `${r.id} ${st}.`); res.redirect(back(req, '/confirmations'));
});

// ---------------------------------------------------------------- matrix, sources, search
app.get('/matrix', async (req, res) => {
  const cs = wsCountries(req); const f = req.query;
  const reqs = (await q.all(`SELECT * FROM requirements ${f.standard ? 'WHERE standard=?' : ''} ORDER BY sort`, ...(f.standard ? [f.standard] : [])));
  const nodeOf = {}; (await q.all('SELECT nr.req_id, n.code, n.title_en FROM node_reqs nr JOIN nodes n ON n.code=nr.node_code')).forEach(r => (nodeOf[r.req_id] = nodeOf[r.req_id] || []).push(r));
  const st = {}; (await q.all('SELECT * FROM node_country')).forEach(r => st[r.node_code + r.country] = r.status);
  const dc = {}; (await q.all('SELECT l.node_code, d.country, d.doc_type, COUNT(*) n FROM doc_links l JOIN documents d ON d.id=l.doc_id GROUP BY 1,2,3')).forEach(r => dc[r.node_code + r.country + r.doc_type] = r.n);
  const gp = {}; (await q.all("SELECT node_code, country, COUNT(*) n FROM confirmations WHERE status<>'resolved' GROUP BY 1,2")).forEach(r => gp[r.node_code + r.country] = r.n);
  const rows = reqs.map(r => {
    const ns = nodeOf[r.id] || [];
    const cells = cs.map(c => r.applicability === 'R' ? '<td class="note">Reference clause</td>' : `<td>${ns.map(n => `<a href="/c/${c}/sub/${encodeURIComponent(n.code)}">${esc(n.code)}</a> ${pill(st[n.code + c], label(req, st[n.code + c]))}<div class="note">proc/reg ${(dc[n.code + c + 'procedure'] || 0) + (dc[n.code + c + 'register'] || 0) + (dc[n.code + c + 'policy'] || 0)} · forms ${dc[n.code + c + 'form'] || 0} · records ${dc[n.code + c + 'record'] || 0}${gp[n.code + c] ? ` · <span class="pill confirm">${gp[n.code + c]} gaps</span>` : ''}</div>`).join('')}</td>`).join('');
    return `<tr><td>${esc(EDITIONS[r.standard].label)}</td><td>${esc(r.ref)}</td><td>${esc(r.title)}</td><td class="note">${esc(r.paraphrase)}</td>${cells}</tr>`;
  }).join('');
  res.send(page(req, { title: label(req, 'matrix'), active: 'matrix', crumbs: [[label(req, 'matrix'), req.originalUrl]], body: `<h1>${esc(label(req, 'matrix'))}</h1>
  <p class="sub">${reqs.length} standard subclauses (including reference clauses 1–3). Full matrix with responsible roles, documents and evidence codes: ${cs.map(c => `<a href="/exports/matrix.xlsx?c=${c}">${esc(label(req, c))} (xlsx)</a>`).join(' · ')}</p>
  <form class="inline card" method="get"><label>${esc(label(req, 'standard'))}<select name="standard"><option value="">${esc(label(req, 'all'))}</option><option value="ISO45001" ${f.standard === 'ISO45001' ? 'selected' : ''}>ISO 45001</option><option value="ISO14001" ${f.standard === 'ISO14001' ? 'selected' : ''}>ISO 14001</option></select></label>${req.ws !== 'ALL' ? `<input type="hidden" name="c" value="${req.ws}">` : ''}<button>${esc(label(req, 'filter'))}</button></form>
  <div class="tablewrap"><table><tr><th>${esc(label(req, 'standard'))}</th><th>${esc(label(req, 'clause'))}</th><th>${esc(label(req, 'title'))}</th><th>Requirement (paraphrase)</th>${cs.map(c => `<th>${esc(label(req, c))}</th>`).join('')}</tr>${rows}</table></div>` }));
});
app.get('/sources', async (req, res) => {
  const cs = [...wsCountries(req), 'GL']; const f = req.query;
  const rows = (await q.all(`SELECT * FROM sources WHERE country IN (${inList(cs)}) ${f.q ? 'AND (id LIKE ? OR filename LIKE ? OR intended_use LIKE ? OR note LIKE ?)' : ''} ORDER BY country, id`, ...cs, ...(f.q ? Array(4).fill('%' + f.q + '%') : [])));
  res.send(page(req, { title: label(req, 'sources'), active: 'sources', crumbs: [[label(req, 'sources'), req.originalUrl]], body: `<h1>${esc(label(req, 'sources'))} <span class="muted">(${rows.length})</span></h1>
  <p class="sub">Inventory captured 01/11/2026 through the Microsoft 365 connector (read-only). access: <b>read</b> = content opened and used · <b>listed</b> = filename/metadata only · <b>empty</b> = empty folder · <b>excluded</b> = out of scope by user instruction. Originals stay in SharePoint.</p>
  <form class="inline card" method="get"><label>Text<input name="q" value="${esc(f.q || '')}"></label>${req.ws !== 'ALL' ? `<input type="hidden" name="c" value="${req.ws}">` : ''}<button>${esc(label(req, 'filter'))}</button></form>
  <div class="tablewrap"><table><tr><th>ID</th><th>${esc(label(req, 'country'))}</th><th>File / folder</th><th>${esc(label(req, 'type'))}</th><th>Subclause</th><th>${esc(label(req, 'date'))}</th><th>Access</th><th>Intended use</th><th>Note</th></tr>
  ${rows.map(s => `<tr><td>${esc(s.id)}</td><td>${esc(s.country)}</td><td>${s.url ? `<a href="${esc(s.url)}" target="_blank" rel="noopener noreferrer">${esc(s.filename)}</a>` : esc(s.filename)}<div class="note">${esc(s.location)}</div></td><td>${esc(s.kind)}</td><td>${esc(s.node_code || '')}</td><td>${esc(s.modified || '')}</td><td>${pill(s.access === 'excluded' ? 'excluded' : s.access === 'empty' ? 'evidence-missing' : 'approved', s.access)}</td><td>${esc(s.intended_use)}</td><td>${esc(s.note || '')}</td></tr>`).join('')}</table></div>` }));
});
app.get('/search', async (req, res) => {
  const s = String(req.query.q || '').trim(); const cs = wsCountries(req); const like = '%' + s + '%';
  let body = `<h1>${esc(label(req, 'search'))}: “${esc(s)}”</h1>${filterForm(req, '/search')}`;
  if (s.length >= 2) {
    const { where, params } = docFilters(req);
    const docs = (await q.all(`SELECT d.* FROM documents d WHERE ${where} LIMIT 200`, ...params));
    const nodes = (await q.all(`SELECT n.*, nc.country, nc.status FROM nodes n JOIN node_country nc ON nc.node_code=n.code WHERE nc.country IN (${inList(cs)}) AND (n.code LIKE ? OR n.title_en LIKE ? OR n.title_ar LIKE ? OR n.summary_en LIKE ? OR nc.impl LIKE ?) ${req.query.clause ? 'AND n.clause=?' : ''}`, ...cs, like, like, like, like, like, ...(req.query.clause ? [Number(req.query.clause)] : [])));
    const reqs = (await q.all(`SELECT * FROM requirements WHERE (ref LIKE ? OR title LIKE ? OR paraphrase LIKE ?) ${req.query.standard ? 'AND standard=?' : ''} LIMIT 100`, like, like, like, ...(req.query.standard ? [req.query.standard] : [])));
    const acts = (await q.all(`SELECT * FROM actions WHERE country IN (${inList(cs)}) AND (description LIKE ? OR owner LIKE ? OR ref LIKE ?) LIMIT 100`, ...cs, like, like, like));
    const conf = (await q.all(`SELECT * FROM confirmations WHERE country IN (${inList([...cs, 'GL'])}) AND (missing LIKE ? OR id LIKE ? OR owner LIKE ?) LIMIT 100`, ...cs, 'GL', like, like, like));
    const srcs = (await q.all(`SELECT * FROM sources WHERE country IN (${inList([...cs, 'GL'])}) AND (filename LIKE ? OR intended_use LIKE ? OR id LIKE ?) LIMIT 100`, ...cs, 'GL', like, like, like));
    const sec = (h, items, f) => `<h2>${esc(h)} (${items.length})</h2>${items.length ? `<ul class="tight">${items.map(f).join('')}</ul>` : '<p class="note">No matches.</p>'}`;
    body += sec('Subclause pages', nodes, n => `<li><a href="/c/${n.country}/sub/${encodeURIComponent(n.code)}">${esc(n.country)} ${esc(n.code)} ${esc(title(req, n))}</a> ${pill(n.status, label(req, n.status))}</li>`)
      + sec(label(req, 'documents'), docs, d => `<li><a href="/documents/${d.id}">${esc(d.country)} ${esc(d.code)}</a> ${esc(d.title_en)} — ${esc(label(req, d.doc_type))} ${statusPill(req, d.status, d.origin)}</li>`)
      + sec('Standard requirements', reqs, r => `<li>${esc(EDITIONS[r.standard].label)} ${esc(r.ref)} ${esc(r.title)}</li>`)
      + sec(label(req, 'actions'), acts, a => `<li><a href="/actions?c=${a.country}">#${a.id}</a> ${esc(a.description)}</li>`)
      + sec(label(req, 'confirmations'), conf, r => `<li><a href="/confirmations?q=${encodeURIComponent(r.id)}">${esc(r.id)}</a> ${esc(r.missing)}</li>`)
      + sec(label(req, 'sources'), srcs, r => `<li><a href="/sources?q=${encodeURIComponent(r.id)}">${esc(r.id)}</a> ${esc(r.filename)}</li>`);
  } else body += '<p class="note">Type at least 2 characters.</p>';
  res.send(page(req, { title: label(req, 'search'), crumbs: [[label(req, 'search'), req.originalUrl]], body }));
});

// ---------------------------------------------------------------- exports
app.get('/exports', (req, res) => res.send(page(req, { title: label(req, 'exports'), active: 'exports', crumbs: [[label(req, 'exports'), '/exports']], body: `<h1>${esc(label(req, 'exports'))}</h1>
  <div class="grid">${req.user.countries.map(c => `<div class="card"><h3 style="margin-top:0">${esc(label(req, c))}</h3><p><a class="btn" href="/exports/${c}.zip">${esc(label(req, 'export_zip'))}</a></p>
  <ul class="tight"><li><a href="/exports/matrix.xlsx?c=${c}">Clause coverage matrix (xlsx)</a></li><li><a href="/exports/confirmations.xlsx?c=${c}">Confirmation register (xlsx)</a></li><li><a href="/exports/docindex.xlsx?c=${c}">Document & record index (xlsx)</a></li></ul>
  <p class="note">The ZIP holds ${c === 'EG' ? 'Egypt' : 'KSA'}/00_Index plus one folder per clause and subclause, split into procedures, blank forms, live registers, completed records and original sources (.url shortcuts to SharePoint).</p></div>`).join('')}
  ${req.user.countries.length > 1 ? `<div class="card"><h3 style="margin-top:0">Consolidated</h3><a href="/exports/confirmations.xlsx?c=ALL">Confirmation register — both countries (xlsx)</a></div>` : ''}</div>` })));
app.get('/exports/:country.zip', async (req, res) => {
  const c = req.params.country.toUpperCase(); if (!['EG', 'SA'].includes(c) || !req.user.countries.includes(c)) return res.status(404).send('Not found');
  await log(req.user, 'export_zip', 'country', c, c);
  res.set({ 'Content-Type': 'application/zip', 'Content-Disposition': `attachment; filename="SEDCO_IHSE_${c === 'EG' ? 'Egypt' : 'KSA'}_${new Date().toISOString().slice(0, 10)}.zip"` });
  EXP.countryZip(c, res).catch(e => { console.error(e); res.destroy(e); });
});
app.get('/exports/:kind.xlsx', async (req, res) => {
  const c = String(req.query.c || '').toUpperCase(); const k = req.params.kind;
  if (k === 'confirmations' && c === 'ALL' && req.user.countries.length < 2) return res.status(403).send('Not permitted');
  if (c !== 'ALL' && !req.user.countries.includes(c)) return res.status(404).send('Choose a permitted country');
  let buf;
  if (k === 'matrix' && c !== 'ALL') buf = await EXP.matrixWorkbook(c);
  else if (k === 'confirmations') buf = await EXP.confirmationsWorkbook(c);
  else if (k === 'docindex' && c !== 'ALL') buf = (await EXP.indexWorkbooks(c)).docIndex;
  else return res.status(404).send('Unknown export');
  await log(req.user, 'export_xlsx', k, c, c);
  res.set({ 'Content-Type': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', 'Content-Disposition': `attachment; filename="SEDCO_IHSE_${k}_${c}.xlsx"` });
  res.send(Buffer.from(buf));
});

// ---------------------------------------------------------------- admin
app.get('/admin/users', need('users'), async (req, res) => {
  const users = (await q.all('SELECT * FROM users ORDER BY username'));
  const roleSel = (cur) => `<select name="role">${Object.entries(ROLES).map(([k, v]) => `<option value="${k}" ${k === cur ? 'selected' : ''}>${esc(v)}</option>`).join('')}</select>`;
  res.send(page(req, { title: label(req, 'users'), active: 'users', crumbs: [[label(req, 'users'), '/admin/users']], body: `<h1>${esc(label(req, 'users'))}</h1>
  <p class="sub">Roles: administrator (everything), document controller (register, edit, regenerate, obsolete), contributor (register and upload, submit for review), reviewer/approver (approve or return; cannot approve own upload), viewer/auditor (read-only, audit log). Country access limits what a user can see.</p>
  <div class="tablewrap"><table><tr><th>Username</th><th>Name</th><th>Role</th><th>Countries</th><th>Active</th><th>Update</th></tr>${users.map(u => `<tr><td>${esc(u.username)}</td><td>${esc(u.name)}</td><td>${esc(ROLES[u.role])}</td><td>${esc(u.countries)}</td><td>${u.active ? 'yes' : 'no'}</td>
  <td><form method="post" action="/admin/users/${u.id}" class="inline" style="margin:0">${roleSel(u.role)}<label><input type="checkbox" name="EG" ${u.countries.includes('EG') ? 'checked' : ''}>EG</label><label><input type="checkbox" name="SA" ${u.countries.includes('SA') ? 'checked' : ''}>SA</label><label><input type="checkbox" name="active" ${u.active ? 'checked' : ''}>active</label><input name="pw" type="password" placeholder="reset password" minlength="10" size="12" aria-label="reset password"><button class="secondary">${esc(label(req, 'save'))}</button></form></td></tr>`).join('')}</table></div>
  <h2>Add user</h2><form method="post" action="/admin/users" class="card"><div class="row"><label>Username<input name="username" required pattern="[A-Za-z0-9._-]{3,40}"></label><label>Name<input name="name" required></label><label>Role${roleSel('viewer')}</label></div>
  <div class="row"><label><span><input type="checkbox" name="EG" checked> Egypt</span></label><label><span><input type="checkbox" name="SA"> KSA</span></label><label>Initial password (min 10)<input name="pw" type="password" minlength="10" required></label></div><button>${esc(label(req, 'save'))}</button></form>` }));
});
const countriesFrom = (b) => ['EG', 'SA'].filter(c => b[c]).join(',');
app.post('/admin/users', need('users'), async (req, res) => {
  const b = req.body; if (!ROLES[b.role] || !/^[A-Za-z0-9._-]{3,40}$/.test(b.username || '') || String(b.pw || '').length < 10 || !countriesFrom(b)) { flash(res, 'Check username, role, at least one country and a 10+ character password.', true); return res.redirect('/admin/users'); }
  try { const id = (await q.insert('INSERT INTO users (username,name,pw_hash,role,countries) VALUES (?,?,?,?,?)', b.username, b.name, bcrypt.hashSync(b.pw, 10), b.role, countriesFrom(b))); await log(req.user, 'user_create', 'user', id, null, { username: b.username, role: b.role, countries: countriesFrom(b) }); flash(res, 'User created.'); }
  catch { flash(res, 'Username already exists.', true); }
  res.redirect('/admin/users');
});
app.post('/admin/users/:id', need('users'), async (req, res) => {
  const u = (await q.get('SELECT * FROM users WHERE id=?', Number(req.params.id))); const b = req.body; if (!u || !ROLES[b.role] || !countriesFrom(b)) { flash(res, 'Invalid update (at least one country).', true); return res.redirect('/admin/users'); }
  if (u.id === req.user.id && (b.role !== 'admin' || !b.active)) { flash(res, 'You cannot remove your own administrator access.', true); return res.redirect('/admin/users'); }
  (await q.run('UPDATE users SET role=?, countries=?, active=? WHERE id=?', b.role, countriesFrom(b), b.active ? 1 : 0, u.id));
  if (b.pw) { if (String(b.pw).length < 10) { flash(res, 'Password must have 10+ characters.', true); return res.redirect('/admin/users'); } (await q.run('UPDATE users SET pw_hash=? WHERE id=?', bcrypt.hashSync(b.pw, 10), u.id)); (await q.run('DELETE FROM sessions WHERE user_id=?', u.id)); }
  if (!b.active) (await q.run('DELETE FROM sessions WHERE user_id=?', u.id));
  await log(req.user, 'user_update', 'user', u.id, null, { role: b.role, countries: countriesFrom(b), active: !!b.active, pw_reset: !!b.pw }); flash(res, 'User updated.'); res.redirect('/admin/users');
});
app.get('/admin/audit', need('auditlog'), async (req, res) => {
  const cs = req.user.countries; const rows = (await q.all(`SELECT * FROM audit_log WHERE country IS NULL OR country IN (${inList(cs)}) ORDER BY id DESC LIMIT 500`, ...cs));
  res.send(page(req, { title: label(req, 'audit'), active: 'auditlog', crumbs: [[label(req, 'audit'), '/admin/audit']], body: `<h1>${esc(label(req, 'audit'))}</h1><p class="sub">Last 500 material changes, logins and downloads (append-only).</p>
  <div class="tablewrap"><table><tr><th>When (UTC)</th><th>User</th><th>Action</th><th>Entity</th><th>Country</th><th>Detail</th></tr>${rows.map(r => `<tr><td>${esc(r.ts)}</td><td>${esc(r.username)}</td><td>${esc(r.action)}</td><td>${esc(r.entity || '')} ${esc(r.entity_id || '')}</td><td>${esc(r.country || '')}</td><td>${esc(r.detail || '')}</td></tr>`).join('')}</table></div>` }));
});

app.use((err, req, res, next) => { console.error(err); if (err.code === 'LIMIT_FILE_SIZE') return res.status(413).send(`File too large (max ${MAX_UPLOAD_MB} MB)`); res.status(500).send('Internal error'); });
app.use((req, res) => res.status(404).send(page(req, { title: 'Not found', body: '<h1>Page not found</h1><p><a href="/dashboard">Dashboard</a></p>' })));

module.exports = app;
if (require.main === module) {
  const port = Number(process.env.PORT || 8080), host = process.env.HOST || '127.0.0.1';
  ensureReady().then(() => app.listen(port, host, () => console.log(`IHSE portal on http://${host}:${port}`))).catch(e => { console.error(e); process.exit(1); });
}

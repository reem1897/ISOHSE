# Completion report: SEDCO Integrated HSE Portal (01/11/2026)

## 1. What was delivered

A working self-hosted web application. Installation is covered in `README.md`; the main features are:

- **Workspaces and navigation**: Egypt and KSA workspaces; Country → Clause → Subclause hierarchy; Arabic (RTL) and English (LTR) switching; breadcrumbs, a Back button and real URLs, so browser back/forward and direct links work.
- **Dashboards**: consolidated and per-country.
- **Documents**: registration, upload, preview (with PDF conversion), download, metadata editing, revision history with checksums, and a draft → review → approved → obsolete workflow with segregation of duties.
- **Records and evidence**: links from records to the forms they were made from; links from subclauses to documents and from documents to their sources.
- **Tracking**: an action tracker (owners, due dates, evidence, effectiveness) and a confirmation register.
- **Search and filters**: by country, standard, clause, document type, owner, status and date.
- **Access and logging**: five roles, per-country access control and an audit log.
- **Exports**: Excel exports and a structured ZIP per country.
- **Operations**: backup and restore scripts, schema migrations and an end-to-end test suite.

## 2. Standards (verified)

- **ISO 14001:2026**, 4th edition (2026-04). Verified against the licensed copy you uploaded. Its new or strengthened points are covered by their own pages: 4.1 environmental conditions, 6.1.4 risks and opportunities, 6.1.5 planning action, and **6.3 planning of changes**.
- **ISO 45001:2018 + Amd 1:2024** is the current edition; certification bodies expect a new edition around 2027.
  - **Caution:** the uploaded `ISO_45001_2018.pdf` body uses **pre-publication draft numbering** (8.2 MOC, 8.3 Outsourcing, 10.1 Incident). Published numbering was used instead, and it matches your own SharePoint folders (8.1.3 MOC, 8.1.4.2 contractors). This is logged as CR-GL-0001.
- **Clause matrix**: 75 applicable subclauses (45001: 40, 14001: 35), plus clauses 1–3 of each standard as reference rows. Every applicable subclause maps to one of 31 integrated subclause pages (automated test). Requirements are paraphrased; no standard text is reproduced.

## 3. Sources actually used

The inventory has 138 entries, accessed read-only through Microsoft 365.

| Access | Egypt | KSA | Meaning |
|---|---|---|---|
| read | 5 | 4 | Content opened and used (policy 2026, SWOT 2026, aspects register FP-103-05 in full, legal list FP-103-04, HSE manual p.1–8; KSA SWOT 2024, fiber poles risk and environment assessments, KSA legal register) |
| listed | 111 | 13 | Filename, size and date only. Linked as evidence with "content verification pending" |
| empty | 2 | 1 | Empty folders, recorded as gaps |
| excluded | – | 2 | ISKRA KSA documents (smart meters), excluded on your instruction |

### Main findings from the sources

- **The KSA 2026 tree is largely an empty or copied skeleton of the Egypt tree.** Procedures, planning registers and the aspects register have identical byte sizes to the Egypt files. They are re-filed as "original sources (unadapted Egypt copy)" and are not counted as KSA evidence.
- **Real KSA evidence:**
  - the 2024 SWOT for Elsewedy Industrial Limited;
  - the fiber poles risk assessment (12 rows) and environmental assessment (5 rows), both imported;
  - lifting-equipment certificates;
  - the 2025 KSA set, which is listed but not yet itemised.
- **Egypt legal list FP-103-04** still includes superseded laws (137/1981, 79/1975), duplicates, non-HSE laws and COVID-19 decrees. This is raised as an action.
- **Egypt has two coexisting versions** each of HSE-OP-107, HSE-OP-120 and the policy. This is raised as a document-control action.

## 4. Document and record index

| | Egypt | KSA |
|---|---|---|
| Portal-generated subclause implementation documents (DOCX, Draft) | 31 | 31 |
| Blank bilingual master forms (DOCX) | 9 | 9 |
| Live registers (XLSX) | 10 | 10 |
| Company procedures/instructions linked | 28 | 1 (KSA context procedure, 2025) |
| Company forms / registers linked | 10 / 25 | 0 / 3 |
| Completed records linked (company sources) | 50 | 3 |

Register content:
- **Egypt aspects register**: 223 rows imported from FP-103-05 with English and Arabic text and formulas.
- **Egypt legal register**: 36 rows from FP-103-04, with review notes.
- **KSA fiber-poles registers**: 12 hazard rows and 5 aspect rows from the source files.
- **KSA legal register**: 6 candidate Saudi instruments, all marked CONFIRMATION REQUIRED. No Egyptian law was carried over.

The full lists are in `deliverables/Document_Record_Index_*.xlsx`.

## 5. Dashboard state (computed from stored data)

| Metric (out of 75 applicable subclauses) | Egypt | KSA |
|---|---|---|
| Mapped to a subclause page | 75 | 75 |
| Documentation completeness (company or approved documents) | 65 | 11 |
| Approved documentation in the portal | 0 | 0 |
| Implementation evidence located | 55 | 0 |
| Readiness | **Not audit-ready** | **Not audit-ready** |

"Approved = 0" is accurate: no document has yet been approved by a named approver in the portal, and the approval status of company files could not be confirmed from metadata.

## 6. Gaps and confirmation register

There are 59 items: Egypt 24, KSA 31, global 4. **30 are high priority.**

**KSA (high priority)**
- Approved scope (legal entity, address, product lines including fiber poles)
- A signed KSA policy
- Saudi legal register
- KSA HIRA and aspects for the cable-accessories departments
- Role holders
- 2026 records for committee, training, drills, PTW, monitoring, audit and management review

**Egypt (high priority)**
- Certificate scope wording
- Scope and MOC for the factory relocation
- Updated evacuation plan (the file on record is dated 10-2020)
- Legal register clean-up
- 2026 compliance evaluation results

The full register is in `deliverables/Confirmation_Register_both_countries.xlsx` and on the `/confirmations` page. Open items are yellow and always labelled "CONFIRMATION REQUIRED".

## 7. Tests (`npm test`): 17 of 17 passed

1. Authentication and redirect for unauthenticated users.
2. The two workspaces are distinct; no Egyptian law appears on KSA pages.
3. Full subclause mapping (40 + 35).
4. All 8 sections present on subclause pages; method text is unique per subclause.
5. Forms and records are kept separate; templates are never shown as evidence.
6. Role restrictions; approval sets the approved version; a new upload returns the document to Draft; revision history kept.
7. Country isolation for pages, downloads, ZIP and search.
8. Action overdue detection and the rule for "verified effective".
9. Dashboard numbers match the database.
10. A confirmation item cannot be resolved without an answer.
11. Search and filters work.
12. Breadcrumbs and RTL/LTR rendering.
13. Every generated DOCX/XLSX is a valid Office package (formulas, freeze panes and filters checked).
14. ZIP folder structure and indexes.
15. Data persists after a restart.
16. Self-approval is refused.
17. PDF conversion works.

Further checks:
- Representative Word, Excel and PDF outputs were rendered with LibreOffice and inspected visually.
- Browser back/forward was checked with Chromium.
- Backup and restore were round-trip tested (236 documents and 100 files restored).

## 8. Known limitations

- 111 Egypt and 13 KSA sources are **listed, not content-verified**. They are linked with that label, and records are shown with their file date, not a confirmed activity date.
- The SharePoint originals are not copied into the portal or the ZIPs (`.url` shortcuts only). Opening them requires company SharePoint access.
- Large registers were not imported: the CAR Log (22 MB), objectives action plan 2026, JHA and risk register. They are linked, and import requests are in the confirmation register.
- The approved company template files and Excel styles 07–10 were not found as design files, so the document design is **provisional**.
- Long implementation texts are in English with an Arabic summary on each page; the interface, titles and summaries are fully bilingual.
- PDF preview needs LibreOffice on the server.
- SSO, email and live SharePoint sync are not configured (see the README migration path).

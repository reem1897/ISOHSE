'use strict';
// End-to-end tests: spawn the real server on a fresh data directory and exercise it over HTTP.
const { test, before, after } = require('node:test');
const assert = require('node:assert');
const { spawn, execFileSync } = require('node:child_process');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const ExcelJS = require('exceljs');

const ROOT = path.join(__dirname, '..');
const DATA = fs.mkdtempSync(path.join(os.tmpdir(), 'ihse-test-'));
process.env.IHSE_DATA_DIR = DATA;
process.env.IHSE_ADMIN_PASSWORD = 'Admin-Test-Pass-1';
delete process.env.DATABASE_URL;
const { q, close } = require('../src/db');
const { ensureReady } = require('../src/seed');
const app = require('../src/server');
let server, BASE;
const ADMIN_PW = 'Admin-Test-Pass-1';

async function start() { await ensureReady(); await new Promise(r => { server = app.listen(0, '127.0.0.1', r); }); BASE = `http://127.0.0.1:${server.address().port}`; }
async function stop() { await new Promise(r => server.close(r)); await close(); }

class Client {
  constructor() { this.cookie = ''; }
  async req(method, url, body, headers = {}) {
    const h = { Cookie: this.cookie, Origin: BASE, ...headers };
    let payload = body;
    if (body && !(body instanceof FormData)) { payload = new URLSearchParams(body).toString(); h['Content-Type'] = 'application/x-www-form-urlencoded'; }
    const res = await fetch(BASE + url, { method, headers: h, body: payload, redirect: 'manual' });
    const sc = res.headers.getSetCookie ? res.headers.getSetCookie() : [];
    sc.forEach(c => { const [kv] = c.split(';'); const [k, v] = kv.split('='); if (k === 'ihse_sid') this.cookie = v ? `ihse_sid=${v}` : ''; });
    return res;
  }
  get(u) { return this.req('GET', u); }
  post(u, b, h) { return this.req('POST', u, b, h); }
  async login(u, p) { const r = await this.post('/login', { username: u, password: p, next: '/dashboard' }); assert.equal(r.status, 302); assert.equal(r.headers.get('location'), '/dashboard'); return this; }
}
const admin = new Client();

before(async () => { await start(); await admin.login('admin', ADMIN_PW); });
after(async () => { await stop(); fs.rmSync(DATA, { recursive: true, force: true }); });

test('unauthenticated users are redirected to login; wrong password refused', async () => {
  const anon = new Client();
  const r = await anon.get('/dashboard'); assert.equal(r.status, 302); assert.match(r.headers.get('location'), /^\/login/);
  const bad = await anon.post('/login', { username: 'admin', password: 'wrong' }); assert.match(bad.headers.get('location'), /err=1/);
});

test('both country workspaces exist, are distinct and every node has country content', async () => {
  const eg = await (await admin.get('/c/EG/sub/6.1.3')).text();
  const sa = await (await admin.get('/c/SA/sub/6.1.3')).text();
  assert.match(eg, /FP-103-04/); assert.match(sa, /header-only copy/);
  assert.doesNotMatch(sa, /Law 14\/2025/, 'Egyptian legislation must not appear on KSA page');
  const n = (await q.get('SELECT COUNT(*) c FROM node_country')).c; const nodes = (await q.get('SELECT COUNT(*) c FROM nodes')).c;
  assert.equal(n, nodes * 2);
});

test('every applicable standard subclause of both standards maps to a subclause page', async () => {
  const unmapped = (await q.all("SELECT id FROM requirements WHERE applicability='A' AND id NOT IN (SELECT req_id FROM node_reqs)"));
  const counts = (await q.all("SELECT standard, COUNT(*) c FROM requirements WHERE applicability='A' GROUP BY standard"));
  assert.deepEqual(unmapped, []);
  assert.deepEqual(Object.fromEntries(counts.map(r => [r.standard, r.c])), { ISO45001: 40, ISO14001: 35 });
});

test('subclause pages carry all 8 sections and requirement-specific (non-duplicated) text', async () => {
  const nodes = (await q.all('SELECT code, method FROM nodes'));
  assert.equal(new Set(nodes.map(n => n.method)).size, nodes.length, 'methods must be unique per subclause');
  const html = await (await admin.get('/c/EG/sub/8.2')).text();
  for (const h of ['1. Requirement summary', '2. How SEDCO implements it', '3. Responsibilities', '4. Procedures', '5. Blank forms', '6. Completed records', '7. Gaps', '8. Relevant audit checks']) assert.ok(html.includes(h), h);
  assert.match(html, /FP-106-02/);
});

test('blank forms and completed records are separated; templates never listed as evidence', async () => {
  const bad = (await q.get("SELECT COUNT(*) c FROM documents WHERE doc_type='record' AND origin='generated'")).c;
  const recWithForm = (await q.get("SELECT COUNT(*) c FROM documents r JOIN documents f ON f.id=r.form_doc_id WHERE r.doc_type='record' AND f.doc_type='form'")).c;
  assert.equal(bad, 0); assert.ok(recWithForm > 0, 'records are linked to the form they were made from');
  const html = await (await admin.get('/c/EG/sub/5.4')).text();
  const evid = html.split('6. Completed records')[1].split('7. Gaps')[0];
  assert.doesNotMatch(evid, /IHSE-EG-F-MOM/);
});

test('roles: viewer is read-only; contributor cannot approve; approver cannot approve own upload', async () => {
  for (const [u, role, c] of [['viewer1', 'viewer', 'EG'], ['contrib1', 'contributor', 'EG'], ['approver1', 'approver', 'EG'], ['ksaonly', 'contributor', 'SA']]) {
    const r = await admin.post('/admin/users', { username: u, name: u, role, [c]: 'on', pw: 'Password-123!' }); assert.equal(r.status, 302);
  }
  const viewer = await new Client().login('viewer1', 'Password-123!');
  assert.equal((await viewer.post('/actions', { country: 'EG', source: 'Other', description: 'x', owner: 'y' })).status, 403);
  assert.equal((await viewer.get('/documents/new')).status, 403);
  assert.equal((await viewer.get('/admin/users')).status, 403);

  const contrib = await new Client().login('contrib1', 'Password-123!');
  const fd = new FormData();
  Object.entries({ country: 'EG', doc_type: 'record', code: 'EG-TEST-REC-1', title_en: 'Test drill record', owner: 'HSE', record_date: '2026-10-20', nodes: '8.2', relevance: 'Drill evidence' }).forEach(([k, v]) => fd.append(k, v));
  fd.append('file', new Blob(['drill record text']), 'drill.txt');
  const cr = await contrib.post('/documents', fd); assert.equal(cr.status, 302);
  const id = cr.headers.get('location').split('/').pop();
  assert.equal((await contrib.post(`/documents/${id}/workflow`, { action: 'submit' })).status, 302);
  assert.equal((await contrib.post(`/documents/${id}/workflow`, { action: 'approve' })).status, 403);

  const appr = await new Client().login('approver1', 'Password-123!');
  assert.equal((await appr.post(`/documents/${id}/workflow`, { action: 'approve', note: 'ok' })).status, 302);
  let doc = (await q.get('SELECT * FROM documents WHERE id=?', Number(id)));
  assert.equal(doc.status, 'approved'); assert.equal(doc.approved_version, 1);

  // new version returns to draft; approved version kept in history
  const fd2 = new FormData(); fd2.append('note', 'rev 2'); fd2.append('file', new Blob(['drill record text v2']), 'drill.txt');
  assert.equal((await contrib.post(`/documents/${id}/version`, fd2)).status, 302);
  doc = (await q.get('SELECT * FROM documents WHERE id=?', Number(id))); const vs = (await q.get('SELECT COUNT(*) c FROM doc_versions WHERE doc_id=?', Number(id))).c;
  assert.equal(doc.status, 'draft'); assert.equal(doc.approved_version, 1); assert.equal(vs, 2);
  const v1 = await (await contrib.get(`/documents/${id}/download?v=1`)).text(); assert.equal(v1, 'drill record text');

  // approver uploading then approving own version is refused
  const fd3 = new FormData(); fd3.append('note', 'approver upload'); fd3.append('file', new Blob(['v3']), 'drill.txt');
  assert.equal((await appr.post(`/documents/${id}/version`, fd3)).status, 403, 'approver role cannot upload');
  // audit log has entries
  const logs = (await q.all("SELECT action FROM audit_log WHERE entity='document' AND entity_id=?", String(id))).map(r => r.action);
  for (const a of ['document_create', 'workflow_submit', 'workflow_approve', 'version_upload']) assert.ok(logs.includes(a), a);

  // disallowed file type
  const fd4 = new FormData(); fd4.append('note', 'x'); fd4.append('file', new Blob(['MZ']), 'evil.exe');
  await contrib.post(`/documents/${id}/version`, fd4);
  assert.equal((await q.get('SELECT COUNT(*) c FROM doc_versions WHERE doc_id=?', Number(id))).c, 2);
});

test('country access control prevents disclosure across workspaces', async () => {
  const ksa = await new Client().login('ksaonly', 'Password-123!');
  assert.equal((await ksa.get('/c/EG')).status, 404);
  assert.equal((await ksa.get('/c/EG/sub/4.1')).status, 404);
  const egDoc = (await q.get("SELECT id FROM documents WHERE country='EG' LIMIT 1")).id;
  assert.equal((await ksa.get('/documents/' + egDoc)).status, 404);
  assert.equal((await ksa.get('/documents/' + egDoc + '/download')).status, 404);
  assert.equal((await ksa.get('/exports/EG.zip')).status, 404);
  const list = await (await ksa.get('/documents')).text(); assert.doesNotMatch(list, />EG-P-1\d\d</);
  const s = await (await ksa.get('/search?q=wastewater')).text(); assert.doesNotMatch(s, /\/c\/EG\//);
});

test('action tracking: create, overdue detection, evidence link, verification rule', async () => {
  const r = await admin.post('/actions', { country: 'SA', source: 'Internal audit', node_code: '9.2', description: 'Test overdue audit finding', owner: 'KSA HSE lead', due_date: '2026-01-15' });
  assert.equal(r.status, 302);
  const a = (await q.get("SELECT * FROM actions WHERE description='Test overdue audit finding'"));
  const html = await (await admin.get('/actions?c=SA&overdue=1')).text(); assert.match(html, /Test overdue audit finding/); assert.match(html, /overdue/);
  const v = await admin.post('/actions/' + a.id, { status: 'verified', due_date: a.due_date, owner: a.owner }); assert.equal(v.status, 302);
  assert.equal((await q.get('SELECT status FROM actions WHERE id=?', a.id)).status, 'open', 'verified needs evidence or effectiveness');
  await admin.post('/actions/' + a.id, { status: 'verified', due_date: a.due_date, owner: a.owner, effectiveness: 'Re-audit 2026-10 showed closure' });
  assert.equal((await q.get('SELECT status FROM actions WHERE id=?', a.id)).status, 'verified');
});

test('dashboard values match source data', async () => {
  const html = await (await admin.get('/dashboard?c=SA')).text();
  const open = (await q.get("SELECT COUNT(*) c FROM confirmations WHERE country='SA' AND status<>'resolved'")).c;
  const act = (await q.get("SELECT COUNT(*) c FROM actions WHERE country='SA' AND status IN ('open','in_progress')")).c;
  assert.match(html, new RegExp(`Open confirmation items</div><div class="n">${open}<`));
  assert.match(html, new RegExp(`<div class="n">${act} <span class="muted" style="font-size:14px">open`));
  assert.match(html, /Not audit-ready/);
  assert.match(html, /Approved documentation<\/div><div class="n">0 /, 'no approved KSA procedures yet');
});

test('confirmation register: open items are labelled, resolving requires an answer', async () => {
  const html = await (await admin.get('/confirmations?c=SA')).text();
  assert.match(html, /CONFIRMATION REQUIRED:/); assert.match(html, /CR-SA-0001/); assert.match(html, /CR-GL-0001/);
  await admin.post('/confirmations/CR-SA-0001', { status: 'resolved', resolution: '' });
  assert.equal((await q.get("SELECT status FROM confirmations WHERE id='CR-SA-0001'")).status, 'open');
  await admin.post('/confirmations/CR-SA-0001', { status: 'resolved', resolution: 'Context review held, see EG-TEST' });
  assert.equal((await q.get("SELECT status FROM confirmations WHERE id='CR-SA-0001'")).status, 'resolved');
});

test('search and filters by country, standard, clause, type, status, owner and date', async () => {
  const s = await (await admin.get('/search?q=electroplating')).text(); assert.match(s, /6\.1\.2/);
  const f = await (await admin.get('/documents?c=EG&type=form&status=draft&standard=ISO45001&clause=10')).text();
  assert.match(f, /IHSE-EG-F-INC/); assert.doesNotMatch(f, /IHSE-SA-/);
  const dt = await (await admin.get('/documents?c=EG&type=record&from=2026-10-01&to=2026-10-31')).text(); assert.match(dt, /EG-TEST-REC-1/);
  const own = await (await admin.get('/documents?owner=HSE%20Senior')).text(); assert.match(own, /IHSE-EG-PR-4\.1/);
});

test('browser navigation: breadcrumbs, back button and direct links; RTL for Arabic', async () => {
  const html = await (await admin.get('/c/SA/sub/8.1.4')).text();
  assert.match(html, /class="crumbs"/); assert.match(html, /href="\/c\/SA\/clause\/8"/); assert.match(html, /backbtn/);
  await admin.get('/lang/ar?next=/c/SA/sub/8.1.4');
  admin.cookie += '; ihse_lang=ar';
  const ar = await (await admin.get('/c/SA/sub/8.1.4')).text(); assert.match(ar, /<html lang="ar" dir="rtl">/); assert.match(ar, /الإجراءات والوثائق الداعمة/);
  admin.cookie = admin.cookie.replace('; ihse_lang=ar', '');
  const en = await (await admin.get('/c/SA/sub/8.1.4')).text(); assert.match(en, /<html lang="en" dir="ltr">/);
});

test('generated DOCX/XLSX are valid Office files with expected content', async () => {
  const docs = (await q.all("SELECT d.id, d.code, d.gen_key FROM documents d WHERE d.gen_key IS NOT NULL"));
  assert.ok(docs.length >= 100);
  for (const doc of docs) {
    const r = await admin.get(`/documents/${doc.id}/download`); assert.equal(r.status, 200, doc.code);
    const buf = Buffer.from(await r.arrayBuffer()); assert.equal(buf.subarray(0, 2).toString(), 'PK', doc.code + ' is a zip container');
    const f = path.join(DATA, 'chk' + (doc.gen_key.startsWith('R-') ? '.xlsx' : '.docx')); fs.writeFileSync(f, buf);
    const list = execFileSync('unzip', ['-l', f]).toString();
    if (doc.gen_key.startsWith('R-')) { assert.match(list, /xl\/workbook\.xml/); const wb = new ExcelJS.Workbook(); await wb.xlsx.load(buf); assert.ok(wb.worksheets.length >= 2); assert.match(wb.worksheets[0].name, /Instructions/); }
    else { assert.match(list, /word\/document\.xml/); }
  }
  const asp = docs.find(x => x.code === 'IHSE-EG-R-ASPECTS'); const wb = new ExcelJS.Workbook(); await wb.xlsx.load(Buffer.from(await (await admin.get(`/documents/${asp.id}/download`)).arrayBuffer()));
  const ws = wb.worksheets[1]; assert.ok(ws.rowCount > 200); assert.ok(ws.autoFilter); assert.equal(ws.views[0].state, 'frozen');
  assert.match(String(ws.getCell('G2').value.formula), /E2\*F2/);
});

test('country ZIP export preserves folder structure and includes indexes', async () => {
  const r = await admin.get('/exports/SA.zip'); assert.equal(r.status, 200);
  const f = path.join(DATA, 'sa.zip'); fs.writeFileSync(f, Buffer.from(await r.arrayBuffer()));
  const list = execFileSync('unzip', ['-l', f]).toString();
  for (const p of ['KSA/00_Index/Document_and_Record_Index.xlsx', 'KSA/00_Index/Clause_Coverage_Matrix.xlsx', 'KSA/00_Index/Missing_Information_and_Confirmation_Register.xlsx',
    'KSA/04_Context/4.1_Organization_Context/', 'KSA/06_Planning/6.1.2_Hazard_Identification_OHS_Risk/03_Live_Registers/IHSE-SA-R-HIRA_DRAFT.xlsx',
    'KSA/10_Improvement/10.2_Incident_NC_Corrective_Action/02_Blank_Forms/IHSE-SA-F-CAR_DRAFT.docx']) assert.ok(list.includes(p), p);
  assert.doesNotMatch(list, /Egypt\//);
});

test('data persists after restart', async () => {
  await stop(); await start();
  const c = await new Client().login('contrib1', 'Password-123!');
  const html = await (await c.get('/documents?q=EG-TEST-REC-1')).text(); assert.match(html, /EG-TEST-REC-1/);
});

test('segregation of duties: an admin cannot approve a version they uploaded', async () => {
  const fd = new FormData();
  Object.entries({ country: 'EG', doc_type: 'procedure', code: 'EG-TEST-PROC-1', title_en: 'Self approval test', nodes: '7.5' }).forEach(([k, v]) => fd.append(k, v));
  fd.append('file', new Blob(['proc']), 'proc.txt');
  const id = (await admin.post('/documents', fd)).headers.get('location').split('/').pop();
  await admin.post(`/documents/${id}/workflow`, { action: 'submit' });
  await admin.post(`/documents/${id}/workflow`, { action: 'approve' });
  assert.equal((await q.get('SELECT status FROM documents WHERE id=?', Number(id))).status, 'review');
});

test('PDF conversion of a generated Word document works (LibreOffice)', async () => {
  const id = (await q.get("SELECT id FROM documents WHERE code='IHSE-SA-F-MOM'")).id;
  const r = await admin.get(`/documents/${id}/pdf`);
  if (r.status === 503) return; // LibreOffice not installed on this host: endpoint degrades with a clear message
  assert.equal(r.status, 200); const b = Buffer.from(await r.arrayBuffer()); assert.equal(b.subarray(0, 4).toString(), '%PDF');
});

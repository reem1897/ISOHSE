'use strict';
// Logical backup / restore of every portal table (including stored files) as one gzipped JSON file.
// Works against Supabase (DATABASE_URL set) or the local embedded database.
//   npm run backup [-- <outdir>]          -> ihse-backup-<timestamp>.json.gz
//   npm run restore -- <file.json.gz>     -> loads into an EMPTY database (run against a new Supabase project or a fresh local data dir)
const fs = require('node:fs');
const path = require('node:path');
const zlib = require('node:zlib');
const { q, tx, migrate, close } = require('../src/db');

// Dependency order (parents first).
const TABLES = ['users', 'requirements', 'nodes', 'node_reqs', 'node_country', 'sources', 'blobs', 'documents', 'doc_versions', 'doc_links',
  'confirmations', 'actions', 'aspects', 'hira', 'legal', 'audit_log', 'schema_migrations'];
const IDENTITY = ['users', 'documents', 'doc_versions', 'actions', 'aspects', 'hira', 'legal', 'audit_log'];

async function backup(outDir) {
  await migrate();
  const dump = { format: 'sedco-ihse-backup', version: 1, created: new Date().toISOString(), tables: {} };
  for (const t of TABLES) {
    const rows = await q.all(`SELECT * FROM ${t}`);
    dump.tables[t] = t === 'blobs' ? rows.map(r => ({ sha256: r.sha256, data: Buffer.from(r.data).toString('base64') })) : rows;
  }
  fs.mkdirSync(outDir, { recursive: true });
  const file = path.join(outDir, `ihse-backup-${dump.created.replace(/[:.]/g, '-').slice(0, 19)}.json.gz`);
  fs.writeFileSync(file, zlib.gzipSync(JSON.stringify(dump)));
  console.log('Backup written:', file, Object.entries(dump.tables).map(([k, v]) => `${k}=${v.length}`).join(' '));
}

async function restore(file) {
  const dump = JSON.parse(zlib.gunzipSync(fs.readFileSync(file)));
  if (dump.format !== 'sedco-ihse-backup') throw new Error('Not a portal backup file');
  await migrate();
  if ((await q.get('SELECT COUNT(*) c FROM documents')).c > 0) throw new Error('Target database is not empty — restore only into a new, empty database.');
  await tx(async () => {
    await q.run('DELETE FROM schema_migrations');
    for (const t of TABLES) {
      const rows = dump.tables[t] || [];
      for (const r of rows) {
        const cols = Object.keys(r);
        const vals = cols.map(c => (t === 'blobs' && c === 'data') ? Buffer.from(r[c], 'base64') : r[c]);
        await q.run(`INSERT INTO ${t} (${cols.join(',')}) ${IDENTITY.includes(t) ? 'OVERRIDING SYSTEM VALUE ' : ''}VALUES (${cols.map(() => '?').join(',')})`, ...vals);
      }
    }
    for (const t of IDENTITY) await q.get(`SELECT setval(pg_get_serial_sequence('${t}','id'), COALESCE((SELECT MAX(id) FROM ${t}), 0) + 1, false)`);
  });
  console.log('Restored', file);
}

const [, , cmd, arg] = process.argv;
(cmd === 'backup' ? backup(path.resolve(arg || 'backups')) : cmd === 'restore' && arg ? restore(path.resolve(arg)) : Promise.reject(new Error('Usage: backup [outdir] | restore <file>')))
  .then(() => close()).catch(async e => { console.error(e.message); await close(); process.exit(1); });
